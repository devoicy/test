<?php
declare(strict_types=1);

use PDO;
use PDOException;
use Throwable;
use WeakMap;
use Swoole\Database\PDOPool;
use Swoole\Database\PDOConfig;
use Swoole\Database\PDOProxy;
use Swoole\Coroutine;
use Swoole\Coroutine\System;
use Webtoon\Config;

final class Database
{
    private PDOPool $pool;
    private WeakMap $txLevel;

    public function __construct(Config $config, int $poolSize = 10)
    {
        $db = $config->get('db');

        $pdoConfig = (new PDOConfig())
            ->withHost($db['host'])
            ->withPort($db['port'])
            ->withDbName($db['name'])
            ->withUsername($db['username'])
            ->withPassword($db['password'])
            ->withCharset('utf8mb4')
            ->withOptions([
                PDO::ATTR_EMULATE_PREPARES   => true,
                PDO::ATTR_TIMEOUT => 5,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+00:00'"
            ]);

        $this->pool    = new PDOPool($pdoConfig, $poolSize);

        $this->txLevel = new WeakMap();
    }

    /* ================= CONNECTION ================= */

    public function getConnection(): PDO|PDOProxy
    {
        $pdo = $this->pool->get(3.0);

        if ($pdo === null || $pdo === false) {
            throw new RuntimeException('DB pool exhausted (timeout 3s)');
        }

        return $pdo;
    }

    public function releaseConnection(PDO|PDOProxy $pdo): void
    {
        unset($this->txLevel[$pdo]);
        $this->pool->put($pdo);
    }

    /* ================= TRANSACTION ================= */

    public function transaction(callable $callback, int $maxRetries = 1): mixed
    {
        $attempt = 0;

        while ($attempt <= $maxRetries) {
            $pdo = $this->getConnection();

            try {
                $this->begin($pdo);

                $result = $callback($pdo, $this);

                if ($result === false) {
                    $this->rollback($pdo);
                    return false;
                }

                $this->commit($pdo);
                return $result;

            } catch (PDOException $e) {
                $this->rollback($pdo);

                if ($this->isRetryable($e) && $attempt < $maxRetries) {
                    $attempt++;
                    Coroutine::sleep(0.01 * $attempt);
                    continue;
                }

                $this->logError($e, "TX FAILED");
                return false;

            } catch (Throwable $e) {
                $this->rollback($pdo);
                $this->logError($e);
                throw $e;

            } finally {
                $this->releaseConnection($pdo);
            }
        }

        return false;
    }

    /* ================= SAVEPOINT CORE ================= */

    private function begin(PDO|PDOProxy $pdo): void
    {
        $level = $this->txLevel[$pdo] ?? 0;

        if ($level === 0) {
            $pdo->beginTransaction();
        } else {
            $pdo->exec("SAVEPOINT sp_{$level}");
        }

        $this->txLevel[$pdo] = $level + 1;
    }

    private function commit(PDO|PDOProxy $pdo): void
    {
        $level = ($this->txLevel[$pdo] ?? 1) - 1;

        if ($level === 0) {
            $pdo->commit();
            unset($this->txLevel[$pdo]);
        } else {
            $pdo->exec("RELEASE SAVEPOINT sp_{$level}");
            $this->txLevel[$pdo] = $level;
        }
    }

    private function rollback(PDO|PDOProxy $pdo): void
    {
        $level = ($this->txLevel[$pdo] ?? 1) - 1;

        if ($level <= 0) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            unset($this->txLevel[$pdo]);
        } else {
            $pdo->exec("ROLLBACK TO SAVEPOINT sp_{$level}");
            $this->txLevel[$pdo] = $level;
        }
    }

    /* ================= HELPERS ================= */

    private function isRetryable(PDOException $e): bool
    {
        $msg = strtolower($e->getMessage());

        return (
            str_contains($msg, 'deadlock') ||
            str_contains($msg, 'gone away') ||
            str_contains($msg, 'lost connection') ||
            (int)$e->getCode() === 1213
        );
    }

    public function logError(Throwable $e, ?string $ctx = null): void
    {
        $dir = __DIR__ . '/cache/db';
        @mkdir($dir, 0755, true);

        $msg = sprintf(
            "[%s] %s\n%s:%d\n%s\n\n",
            date('Y-m-d H:i:s'),
            $ctx ?? 'ERROR',
            $e->getFile(),
            $e->getLine(),
            $e->getMessage()
        );

        System::writeFile($dir . '/db_error.log', $msg, FILE_APPEND);
    }
}
