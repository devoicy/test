<?php

/**
 * Dapatkan folder cache dan pastikan sudah ada.
 * * @param string $folder Sub-folder di dalam direktori cache (misal: 'bin', 'related').
 * @return string Path folder cache yang terjamin sudah ada.
 * @throws RuntimeException Jika gagal membuat direktori.
 */
function cacheDir(string $folder): string
{
    // 1. Tentukan Base Dir. realpath() penting untuk path yang bersih.
    $baseDir = realpath(__DIR__ . '/../cache');
    
    // Fallback jika realpath gagal (walaupun jarang)
    if (!$baseDir) {
        $baseDir = __DIR__ . '/../cache';
    }

    // Pastikan $folder tidak memiliki leading/trailing slash yang mengacaukan path
    $subFolder = trim($folder, '/');
    $dir = $baseDir . '/' . $subFolder;

    // 2. Buat folder jika belum ada (Safe check untuk Race Condition)
    if (!is_dir($dir)) {
        // Coba buat direktori secara rekursif
        if (!mkdir($dir, 0755, true)) {
            // Jika mkdir gagal, cek lagi: mungkin Worker lain yang berhasil membuatnya
            if (!is_dir($dir)) {
                throw new RuntimeException("Failed to create cache directory: {$dir}");
            }
        }
    }

    return $dir;
}

function error($string) {

    return "<html><head><meta name=viewport content=width=device-width,initial-scale=1.0></head><body style=margin:0;display:flex;justify-content:center;align-items:center;height:100vh;><h1 style=font-family:'system-ui',sans-serif;>{$string}</h1></body></html>";

}