<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class eJWT
{
    private string $secretKey;
    private int $accessExpire = 3600;       // 1 jam
    private int $refreshExpire = 60 * 60 * 24 * 7;    // 7 hari

    public function __construct() {
        $this->secretKey = '!expTambah99%!'; // bisa diganti lebih random
    }

    /**
     * Buat access token
     * @param int $userId
     * @param string $role
     * @return string JWT
     */
    public function createAccessToken(array $array): string {
        $iat = time();
        $payload = [
            'iat' => $iat,
            'exp' => $iat + $this->accessExpire,
            'jti' => bin2hex(random_bytes(16))  // JWT ID unik
        ];
        $data = array_merge($payload, $array);
        return JWT::encode($data, $this->secretKey, 'HS256');
    }

    /**
     * Verifikasi access token
     * @param string $token
     * @return object|null
     */
    public function verifyAccessToken(string $token): ?object {
        try {
            return JWT::decode($token, new Key($this->secretKey, 'HS256'));
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Buat refresh token
     * @param int $length panjang token
     * @return string
     */
    public function createRefreshToken(): array {
        return [
        	'token' => bin2hex(random_bytes(32)),
        	'expires' => date('Y-m-d H:i:s', strtotime('+7 days'))
        ];
    }
}
