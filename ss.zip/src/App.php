<?php
// App.php

class App {

    public static bool $debug = true;

    // ✅ BENAR - Configuration
    public static bool $isCacheEnabled = false;
    public static string $cacheDriver = 'swoole';
    
    // ✅ BENAR - Shared Resources
    public static ?\Swoole\Table $cacheTable = null; // Shared memory
    public static ?\Swoole\Table $spamTable = null;  // Shared memory
    public static ?\Swoole\Table $viewBuffer = null;  // Shared memory
    
    // ✅ BENAR - Service Container
    public static ?\DI\Container $container = null;
    public static ?Router $router;

    // ❌ KURANG TEPAT - Business Logic Object
    //public static $router = null; // Sebaiknya di container
    
    // ❌ KURANG TEPAT - Template Engine
    public static ?\Twig\Environment $twig = null; // Sebaiknya di container
}