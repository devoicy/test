<?php

declare(strict_types=1);

use Swoole\Coroutine\System;
use Swoole\Coroutine\Lock;

class Bin
{
    private static array $cache = [];
    private static array $locks = [];
    private const int MAX_CACHE = 500;
    private const int MAX_LOCKS = 1000;

    public function readMsgPack(string $file): mixed
    {
        // 1. Fast Path
        if (isset(self::$cache[$file])) {
            return self::$cache[$file];
        }
        
        // 2. Setup lock
        if (!isset(self::$locks[$file])) {
            self::$locks[$file] = new Lock();
        }
        
        $lock = self::$locks[$file];
        $lock->lock();
        
        try {
            // 3. Double-check
            if (isset(self::$cache[$file])) {
                return self::$cache[$file];
            }
            
            // 4. Read file
            $raw = System::readFile($file);
            if ($raw === false || $raw === "") {
                self::$cache[$file] = false; // Cache negative
                return false;
            }

            // 5. Unpack (NO @!)
            $data = msgpack_unpack($raw);
            if ($data === null) {
                self::$cache[$file] = false; // Cache invalid
                return false;
            }
            
            // 6. LRU Eviction
            if (count(self::$cache) >= self::MAX_CACHE) {
                reset(self::$cache);
                $oldestFile = key(self::$cache);
                unset(self::$cache[$oldestFile]);
                
                // Cleanup old locks (SAFE version)
                $this->cleanupOldLocks();
            }
            
            self::$cache[$file] = $data;
            return $data;
            
        } finally {
            $lock->unlock();
        }
    }

    public function saveMsgPack(string $file, array $array): bool
    {
        // Lock untuk concurrent writes ke file yang sama
        if (!isset(self::$locks[$file])) {
            self::$locks[$file] = new Lock();
        }
        
        $lock = self::$locks[$file];
        $lock->lock();
        
        try {
            $tmpFile = $file . '.tmp';
            
            // Create directory
            $dir = dirname($file);
            if (!is_dir($dir)) {
                if (!mkdir($dir, 0755, true) && !is_dir($dir)) {
                    return false;
                }
            }
            
            // Pack data (gunakan msgpack_pack langsung untuk performa)
            $packed = msgpack_pack($array);
            
            // Write temp file
            if (!System::writeFile($tmpFile, $packed)) {
                return false;
            }
            
            // Atomic rename
            if (!rename($tmpFile, $file)) {
                System::unlink($tmpFile);
                return false;
            }
            
            // Invalidate cache
            unset(self::$cache[$file]);
            
            return true;
            
        } catch (\Throwable $e) {
            return false;
        } finally {
            $lock->unlock();
        }
    }
    
    /**
     * SAFE lock cleanup - hanya hapus locks yang tidak dipakai
     */
    private function cleanupOldLocks(): void
    {
        // Hanya cleanup jika terlalu banyak locks
        if (count(self::$locks) <= self::MAX_LOCKS) {
            return;
        }
        
        // Hapus locks untuk files yang tidak ada di cache
        // DAN tidak sedang locked (approximation)
        foreach (self::$locks as $file => $lock) {
            if (!isset(self::$cache[$file])) {
                // Coba lock dengan timeout 0 (non-blocking)
                // Jika berhasil berarti lock tidak dipakai
                if ($lock->trylock()) {
                    $lock->unlock();
                    unset(self::$locks[$file]);
                }
                // Jika gagal, berarti lock sedang dipakai, biarkan
            }
        }
    }
    
    /**
     * Clear semua cache (untuk testing/maintenance)
     */
    public function clearCache(): void
    {
        self::$cache = [];
        // Jangan hapus locks! Biarkan mereka expire naturally
    }
}