
#ifndef MSGPACK_CLASS_H
#define MSGPACK_CLASS_H

#define MSGPACK_CLASS_OPT_PHPONLY -1001
#define MSGPACK_CLASS_OPT_ASSOC -1002

void msgpack_init_class();

#endif
