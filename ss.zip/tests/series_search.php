<?php
// Tentukan path ke autoloader Composer
require __DIR__ . '/../vendor/autoload.php';

use Webtoon\Models\Auth\UserCreate;
use Webtoon\Config; // Asumsi Class Config ada
use Database; 
use Webtoon\Models\Series\SeriesSearch;
use Swoole\Runtime;
use Swoole\Coroutine;

// 🔥🔥🔥 WAJIB: Aktifkan Hook Coroutine Swoole 🔥🔥🔥
// Ini memastikan I/O functions (seperti PDO Pool) bekerja di coroutine.
Runtime::enableCoroutine();

echo "========================================\n";
echo "  [Swoole INTEGRATION TEST] SeriesCreate  \n";
echo "========================================\n";

// Jalankan tes dalam Coroutine agar Pool bisa bekerja
Coroutine::create(function () {

    // --- 1. Inisialisasi Dependensi ---
    try {
        $config = new \Webtoon\Config(); 
        $config->load(__DIR__ . '/../config.php'); 

        // Ambil kredensial DB yang sudah di-load
        $dbConfig = $config->get('db'); 

        // ✅ DEBUGGING KRUSIAL: PASTIKAN KREDENSIAL TIDAK KOSONG
        if (empty($dbConfig['host']) || empty($dbConfig['name']) || empty($dbConfig['username'])) {
            die("❌ FATAL: Konfigurasi Database (host/name/user) kosong atau gagal dimuat dari config.php.\n");
        }
        
        // Inisiasi Database Pool Anda
        $dbPool = new Database($config, 5); 
        echo "Status: Database Pool 5 Koneksi Siap (Kredensial OK).\n";

    } catch (\Throwable $e) {
        die("Koneksi DB Gagal: " . $e->getMessage() . "\n");
    }

    $series = new SeriesSearch($dbPool);

    var_dump($series->execute('nar'));

});