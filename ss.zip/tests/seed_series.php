<?php
// Tentukan path ke autoloader Composer
require __DIR__ . '/../vendor/autoload.php';

use Webtoon\Models\Series\SeriesCreate;
use Webtoon\Service\Slugify;
use Webtoon\Config; // Asumsi Class Config ada
use Database; 
use Swoole\Runtime;
use Swoole\Coroutine;

// Folder cache
$cacheDir = __DIR__ . '/../cache/jikan';
if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

// Waktu kedaluwarsa cache (detik)
define('CACHE_EXPIRE', 60 * 60 * 99924); // 24 jam

/**
 * Ambil data manga dari Jikan atau cache lokal.
 */
function fetchMangaList(int $page, int $limit = 25): array
{
    global $cacheDir;

    $cacheFile = "{$cacheDir}/manga_page_{$page}.json";

    // Gunakan cache jika ada dan belum kedaluwarsa
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < CACHE_EXPIRE) {
        $json = file_get_contents($cacheFile);
        $data = json_decode($json, true);
        echo "💾 Cache digunakan untuk page {$page}\n";
        return $data['data'] ?? [];
    }

    // Kalau tidak ada cache, ambil dari API
    $url = "https://api.jikan.moe/v4/manga?page={$page}&limit={$limit}";
    echo "🌐 Ambil dari API: {$url}\n";
    $json = @file_get_contents($url);

    if (!$json) {
        echo "⚠️  Gagal ambil data dari Jikan (page {$page})\n";
        return [];
    }

    // Simpan ke cache
    file_put_contents($cacheFile, $json);
    $data = json_decode($json, true);
    return $data['data'] ?? [];
}

/**
 * Bandingkan entitas.
 */
function compareEntities(array $entitiesA, array $entitiesB): bool
{
    $flatten = function (array $entities): array {
        $flat = [];
        foreach ($entities as $arr) {
            if (isset($arr['type'], $arr['slug'])) {
                $flat[] = $arr['type'] . '::' . $arr['slug'];
            } elseif (is_array($arr)) {
                foreach ($arr as $e) {
                    if (isset($e['type'], $e['slug'])) {
                        $flat[] = $e['type'] . '::' . $e['slug'];
                    }
                }
            }
        }
        sort($flat);
        return $flat;
    };

    return $flatten($entitiesA) === $flatten($entitiesB);
}


// 🔥🔥🔥 WAJIB: Aktifkan Hook Coroutine Swoole 🔥🔥🔥
// Ini memastikan I/O functions (seperti PDO Pool) bekerja di coroutine.
Runtime::enableCoroutine();

echo "========================================\n";
echo "  [Swoole INTEGRATION TEST] SeriesCreate  \n";
echo "========================================\n";

// Jalankan tes dalam Coroutine agar Pool bisa bekerja
Coroutine::create(function () {

    // --- 1. Inisialisasi Dependensi ---
try {
    $config = new \Webtoon\Config(); 
    $config->load(__DIR__ . '/../config.php'); 

    // Ambil kredensial DB yang sudah di-load
    $dbConfig = $config->get('db'); 

    // ✅ DEBUGGING KRUSIAL: PASTIKAN KREDENSIAL TIDAK KOSONG
    if (empty($dbConfig['host']) || empty($dbConfig['name']) || empty($dbConfig['username'])) {
        die("❌ FATAL: Konfigurasi Database (host/name/user) kosong atau gagal dimuat dari config.php.\n");
    }
    
    // Inisiasi Database Pool Anda
    $dbPool = new Database($config, 2); 
    echo "Status: Database Pool 5 Koneksi Siap (Kredensial OK).\n";

} catch (\Throwable $e) {
    die("Koneksi DB Gagal: " . $e->getMessage() . "\n");
}


// Loop sampai habis
    Coroutine\go(function() use ($dbPool) {
        $page = 300;
        $limit = 25;
        $slug = new Slugify();
        while (true) {
            $mangaList = fetchMangaList($page, $limit);
            if (empty($mangaList)) {
                echo "✅ Selesai, tidak ada data lagi di page {$page}\n";
                break;
            }
            foreach ($mangaList as $manga) {
                //echo $data['title']."\n";
                $data = [];
                $data['cover_url'] = $manga['images']['webp']['large_image_url'] ?? '';
                $data['name'] = (string)($manga['title'] ?? time());
                $data['slug'] = $slug->execute($data['name']);
                $data['description'] = $manga['synopsis'] ?? '';

                // Authors
                $data['entities']['author'] = [];
                foreach ($manga['authors'] ?? [] as $author) {
                    $data['entities']['author'][] = [
                        'type' => 'author',
                        'name' => $author['name'],
                        'slug' => $slug->execute($author['name'])
                    ];
                }

                // Genres
                $data['entities']['genre'] = [];
                foreach ($manga['genres'] ?? [] as $genre) {
                    $data['entities']['genre'][] = [
                        'type' => 'genre',
                        'name' => $genre['name'],
                        'slug' => $slug->execute($genre['name'])
                    ];
                }

                // theme
                $data['entities']['theme'] = [];
                foreach ($manga['themes'] ?? [] as $theme) {

                    if($theme['name']) {
                    $data['entities']['theme'][] = [
                        'type' => 'theme',
                        'name' => $theme['name'],
                        'slug' => $slug->execute($theme['name'])
                    ];
                    }
                }

                $data['is_published'] = 1;
                $data['entities']['type'] = [];
                $data['entities']['status'] = [];

                if($manga['type']) array_push($data['entities']['type'], [
                    'type' => 'type',
                    'name' => $manga['type'],
                    'slug' => $slug->execute($manga['type'])
                ]);
                if($manga['status']) array_push($data['entities']['status'],[
                    'type' => 'status',
                    'name' => $manga['status'],
                    'slug' => $slug->execute($manga['status'])
                ]);
                $data['entities'] = array_filter($data['entities']);

                // ------------------------------------------------------------------
                // --- 3. TEST SCENARIO A: INSERT (CREATE) ---
                // ------------------------------------------------------------------
                echo "\n--- [A] TEST CREATE NEW SERIES ---\n";
                try {
                    $seriesCreator = new SeriesCreate($dbPool);
                    // Panggil execute() tanpa seriesId (melakukan INSERT di dalam transaksi)
                    $newId = $seriesCreator->execute($data, null);
                    if ($newId > 0) {
                        echo "✅ SUCCESS: Series baru berhasil di-insert.\n";
                        echo "   -> ID Baru (lastInsertId): $newId\n";
                        $testNewId = $newId; 
                    } else {
                        echo "❌ FAILURE: INSERT gagal. ID yang dikembalikan: $newId\n";
                    }

                } catch (\Throwable $e) {
                    echo "❌ ERROR: Terjadi Exception saat INSERT.\n";
                    echo "   -> Pesan: " . $e->getMessage() . "\n";
                }

            }
            $page++;

        }
    });

    /*Coroutine\go(function() use ($dbPool) {
        $page = 400;
        $limit = 25;

        while (true) {
            $mangaList = fetchMangaList($page, $limit);
            if (empty($mangaList) || $page > 400) {
                echo "✅ Selesai, tidak ada data lagi di page {$page}\n";
                break;
            }
            foreach ($mangaList as $manga) {
                //echo $data['title']."\n";
                $data = [];
                $data['cover_url'] = $manga['images']['webp']['large_image_url'] ?? '';
                $data['name'] = (string)($manga['title'] ?? time());
                $data['slug'] = $slug->execute($data['name']);
                $data['description'] = $manga['synopsis'] ?? '';

                // Authors
                $data['entities']['author'] = [];
                foreach ($manga['authors'] ?? [] as $author) {
                    $data['entities']['author'][] = [
                        'type' => 'author',
                        'name' => $author['name'],
                        'slug' => $slug->execute($author['name'])
                    ];
                }

                // Genres
                $data['entities']['genre'] = [];
                foreach ($manga['genres'] ?? [] as $genre) {
                    $data['entities']['genre'][] = [
                        'type' => 'genre',
                        'name' => $genre['name'],
                        'slug' => $slug->execute($genre['name'])
                    ];
                }

                // theme
                $data['entities']['theme'] = [];
                foreach ($manga['themes'] ?? [] as $theme) {

                    if($theme['name']) {
                    $data['entities']['theme'][] = [
                        'type' => 'theme',
                        'name' => $theme['name'],
                        'slug' => $slug->execute($theme['name'])
                    ];
                    }
                }

                $data['is_published'] = 1;
                $data['entities']['type'] = [];
                $data['entities']['status'] = [];

                if($manga['type']) array_push($data['entities']['type'], [
                    'type' => 'type',
                    'name' => $manga['type'],
                    'slug' => $slug->execute($manga['type'])
                ]);
                if($manga['status']) array_push($data['entities']['status'],[
                    'type' => 'status',
                    'name' => $manga['status'],
                    'slug' => $slug->execute($manga['status'])
                ]);
                $data['entities'] = array_filter($data['entities']);

                // ------------------------------------------------------------------
                // --- 3. TEST SCENARIO A: INSERT (CREATE) ---
                // ------------------------------------------------------------------
                echo "\n--- [B] TEST CREATE NEW SERIES ---\n";
                $test = new Packer(PackOptions::DETECT_STR_BIN | PackOptions::FORCE_FLOAT32);
                try {
                    $seriesCreator = new SeriesCreate($dbPool, $test);
                    // Panggil execute() tanpa seriesId (melakukan INSERT di dalam transaksi)
                    $newId = $seriesCreator->execute($data, null);
                    if ($newId > 0) {
                        echo "✅ SUCCESS: Series baru berhasil di-insert.\n";
                        echo "   -> ID Baru (lastInsertId): $newId\n";
                        $testNewId = $newId; 
                    } else {
                        echo "❌ FAILURE: INSERT gagal. ID yang dikembalikan: $newId\n";
                    }

                } catch (\Throwable $e) {
                    echo "❌ ERROR: Terjadi Exception saat INSERT.\n";
                    echo "   -> Pesan: " . $e->getMessage() . "\n";
                }

            }
            $page++;

        }
    });*/

});


