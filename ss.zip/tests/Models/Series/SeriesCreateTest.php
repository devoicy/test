<?php
namespace Tests\Models\Series;

use PHPUnit\Framework\TestCase;
use Webtoon\Models\Series\SeriesCreate;
use Database; 
use PDO;
use PDOStatement;
use PHPUnit\Framework\MockObject\Stub\ReturnCallback; 

class SeriesCreateTest extends TestCase
{
    private const TEST_EXISTING_ID = 42;
    private const PLACEHOLDER_ID = 'DYNAMIC_ID_PLACEHOLDER'; // Definisikan placeholder statis
    
    // 🔥 Properti non-statis untuk menyimpan ID baru yang di-generate
    protected int $dynamicNewId; 

    protected function setUp(): void
    {
        // 🔥 ID di-generate sebelum setiap tes
        $this->dynamicNewId = rand(1000, 9999);
    }
    
    /**
     * Helper untuk Mock Database Pool.
     * Tugasnya: Mensimulasikan Transaction Helper (begin/commit/rollback).
     */
    private function createMockDbPool($pdoMock)
    {
        $dbPoolMock = $this->createMock(Database::class);
        $dbPoolMock->method('getConnection')->willReturn($pdoMock);

        // Mensimulasikan bahwa ketika 'transaction' dipanggil, ia akan menjalankan callback
        // dan memaksa beginTransaction/commit pada objek PDO Mock kita.
        $dbPoolMock->expects($this->once())
            ->method('transaction')
            ->will(new ReturnCallback(function ($callback) use ($dbPoolMock, $pdoMock) { 
                $pdoMock->beginTransaction(); 
                $result = $callback($dbPoolMock); 
                $pdoMock->commit(); 
                return $result;
            }));
        
        $dbPoolMock->expects($this->never())->method('logError');
        
        return $dbPoolMock;
    }

    /**
     * Data Provider HARUS static (PHPUnit Requirement)
     */
    public static function seriesDataServiceProvider() 
    {
        $defaultData = [
            'slug' => 'test-series-slug',
            'name' => 'Test Series Name',
            'updated_by' => 10,
            'entities' => [
                'genre' => [['slug' => 'fantasy', 'name' => 'Fantasy']],
            ]
        ];

        return [
            'create_new_series' => [
                'data' => $defaultData,
                'seriesId' => null, 
                'expectedIdPlaceholder' => self::PLACEHOLDER_ID, // <-- Gunakan PLACEHOLDER statis
                'isUpdate' => false,
                'expectedQueryCount' => 7
            ],
            'update_existing_series' => [
                'data' => $defaultData,
                'seriesId' => self::TEST_EXISTING_ID, 
                'expectedIdPlaceholder' => self::TEST_EXISTING_ID,
                'isUpdate' => true,
                'expectedQueryCount' => 9
            ]
        ];
    }

    /**
     * @dataProvider seriesDataServiceProvider
     */
    public function testExecuteHandlesInsertAndUpdateFlows(
        array $data, 
        ?int $seriesId, 
        int|string $expectedIdPlaceholder, 
        bool $isUpdate, 
        int $expectedQueryCount
    ) {
        // 🔥 INI BARIS KRUSIAL: Menukar placeholder dengan ID acak yang sudah di-generate di setUp()
        $expectedId = $expectedIdPlaceholder === self::PLACEHOLDER_ID
                      ? $this->dynamicNewId 
                      : (int)$expectedIdPlaceholder; 

        $pdoMock = $this->createMock(PDO::class);

        // --- 1. Pengaturan lastInsertId() ---
        if (!$isUpdate) {
            $pdoMock->expects($this->once())
                ->method('lastInsertId')
                ->willReturn((string)$expectedId);
        } else {
            $pdoMock->method('lastInsertId')->willReturn('0'); 
        }

        // --- 2. Definisi Urutan Kueri (Sama seperti sebelumnya) ---
        if ($isUpdate) {
            $querySequence = [
                'UPDATE series SET is_published=?', 
                'SELECT entity_id FROM series_entities', 
                'UPDATE entity_summary SET series_count = series_count - 1', 
                'DELETE FROM series_entities', 
                'INSERT INTO entities (type, name, slug)', 
                'SELECT id FROM entities WHERE type=? AND slug=?', 
                'INSERT INTO entity_summary (entity_id, type, slug, name, last_used_at)', 
                'UPDATE entity_summary SET series_count = series_count + 1 WHERE entity_id IN',
                'INSERT INTO series_summary', 
            ];
            $acquireOldIdsIndex = 1;
            $selectNewEntityIdIndex = 5;
        } else {
            $querySequence = [
                'INSERT INTO series', 
                'INSERT INTO entities (type, name, slug)', 
                'SELECT id FROM entities WHERE type=? AND slug=?', 
                'INSERT INTO entity_summary (entity_id, type, slug, name, last_used_at)', 
                'UPDATE entity_summary SET series_count = series_count + 1 WHERE entity_id IN',
                'INSERT INTO series_summary', 
            ];
            $acquireOldIdsIndex = -1; 
            $selectNewEntityIdIndex = 2;
        }

        // --- 3. Implementasi Mocking Sequence (Core Logic) ---
        $callIndex = -1;
        
        $pdoMock->expects($this->exactly($expectedQueryCount))
            ->method('prepare')
            ->will(new ReturnCallback(function ($sql) use (&$callIndex, $querySequence, $acquireOldIdsIndex, $selectNewEntityIdIndex) {
                $callIndex++;
                
                $this->assertStringContainsString($querySequence[$callIndex], $sql, 
                    "SQL Query mismatch at index $callIndex.");
                
                $currentStmtMock = $this->createMock(PDOStatement::class);
                $currentStmtMock->method('execute')->willReturn(true);

                if ($callIndex === $acquireOldIdsIndex) { 
                     $currentStmtMock->method('fetchAll')->with(PDO::FETCH_COLUMN)->willReturn([50, 51]); 
                } elseif ($callIndex === $selectNewEntityIdIndex) { 
                     $currentStmtMock->method('fetchColumn')->willReturn(99); 
                }
                
                return $currentStmtMock;
            }));

        // 4. Verifikasi exec() untuk Batch Insert Pivot Table
        $pdoMock->expects($this->once())
            ->method('exec')
            ->with($this->stringContains('INSERT INTO series_entities'))
            ->willReturn(1);

        // 5. Eksekusi dan Assertion Akhir
        $dbPoolMock = $this->createMockDbPool($pdoMock);
        $seriesCreator = new SeriesCreate($dbPoolMock);
        
        $resultId = $seriesCreator->execute($data, $seriesId);

        $this->assertEquals($expectedId, $resultId); 
    }
}