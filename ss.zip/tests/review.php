<?php
// Tentukan path ke autoloader Composer
require __DIR__ . '/../vendor/autoload.php';

use Webtoon\Models\Review\ReviewAction;
use Webtoon\Config; // Asumsi Class Config ada
use Database; 
use Swoole\Runtime;
use Swoole\Coroutine;

// 🔥🔥🔥 WAJIB: Aktifkan Hook Coroutine Swoole 🔥🔥🔥
// Ini memastikan I/O functions (seperti PDO Pool) bekerja di coroutine.
Runtime::enableCoroutine();

// Jalankan tes dalam Coroutine agar Pool bisa bekerja
Coroutine::create(function () {

    // --- 1. Inisialisasi Dependensi ---
    try {
        $config = new \Webtoon\Config(); 
        $config->load(__DIR__ . '/../config.php'); 

        // Ambil kredensial DB yang sudah di-load
        $dbConfig = $config->get('db'); 

        // ✅ DEBUGGING KRUSIAL: PASTIKAN KREDENSIAL TIDAK KOSONG
        if (empty($dbConfig['host']) || empty($dbConfig['name']) || empty($dbConfig['username'])) {
            die("❌ FATAL: Konfigurasi Database (host/name/user) kosong atau gagal dimuat dari config.php.\n");
        }
        
        // Inisiasi Database Pool Anda
        $dbPool = new Database($config, 5); 
        echo "Status: Database Pool 5 Koneksi Siap (Kredensial OK).\n";

    } catch (\Throwable $e) {
        die("Koneksi DB Gagal: " . $e->getMessage() . "\n");
    }

	$pdo = $dbPool->getConnection();
	$review = new ReviewAction($dbPool);
	
	try {
		$stmt = $pdo->prepare(
			"SELECT id FROM users ORDER BY id DESC"
		);
		$stmt->execute();

		$users = $stmt->fetchAll(PDO::FETCH_COLUMN);
		foreach ($users as $key) {

		    $data = [
		        'series_id'	=> 1,                // 0=draft, 1=published
		        'user_id'	=> $key,      // URL unik
		        'rating'	=> rand(1, 5),      // Judul series
		        'comment'	=> randomSentence()
		    ];

		    // Insert baru
		    

			$action = $review->execute([
			    	'user_id' => $key, // mecoba user id yg tidak ada
			    	'series_id' => 1,
			    	'rating' => rand(1, 5),
			    	'comment' => randomSentence()
			]);

		}
    } catch (\Throwable $e) {
        error_log($e->getMessage());
    } finally {
        $dbPool->releaseConnection($pdo); 
    }



});

function randomSentence() {
    $subjects = ["Aku", "Kamu", "Dia", "Mereka", "Kita", "Seseorang"];
    $verbs = ["menyukai", "membenci", "melihat", "menulis", "mencoba", "menggunakan"];
    $objects = ["aplikasi ini", "fitur baru", "cerita itu", "hal tersebut", "sistemnya", "review ini"];
    $extras = ["setiap hari", "kadang-kadang", "tanpa alasan", "dengan cepat", "secara diam-diam", "dengan penuh semangat"];

    $s = $subjects[array_rand($subjects)];
    $v = $verbs[array_rand($verbs)];
    $o = $objects[array_rand($objects)];
    $e = $extras[array_rand($extras)];

    return "$s $v $o $e.";
}