<?php
// Tentukan path ke autoloader Composer
require __DIR__ . '/../vendor/autoload.php';

use Webtoon\Models\Chapter\ChapterAction;
use Webtoon\Config; // Asumsi Class Config ada
use Webtoon\Service\Logger; // Asumsi Class Config ada
use Database; 
use Swoole\Runtime;
use Swoole\Coroutine;
use function Swoole\Coroutine\go;

// 🔥🔥🔥 WAJIB: Aktifkan Hook Coroutine Swoole 🔥🔥🔥
// Ini memastikan I/O functions (seperti PDO Pool) bekerja di coroutine.
Runtime::enableCoroutine();

// Jalankan tes dalam Coroutine agar Pool bisa bekerja
Coroutine::create(function () {

    // --- 1. Inisialisasi Dependensi ---
    try {
        $config = new \Webtoon\Config(); 
        $config->load(__DIR__ . '/../config.php'); 

        // Ambil kredensial DB yang sudah di-load
        $dbConfig = $config->get('db'); 

        // ✅ DEBUGGING KRUSIAL: PASTIKAN KREDENSIAL TIDAK KOSONG
        if (empty($dbConfig['host']) || empty($dbConfig['name']) || empty($dbConfig['username'])) {
            die("❌ FATAL: Konfigurasi Database (host/name/user) kosong atau gagal dimuat dari config.php.\n");
        }
        
        // Inisiasi Database Pool Anda
        $dbPool = new Database($config, 5); 
        echo "Status: Database Pool 5 Koneksi Siap (Kredensial OK).\n";
	    $logger = new Logger();
	    
	    // Set workerId supaya nama file log-nya unik per worker (_w0, _w1, dst)
	    $logger->workerId = 1;
	    $logger->enableDebug = $config->get('logger.debug');
	    $logger->enableInfo  = $config->get('logger.info');
	    $logger->enableError = $config->get('logger.error');

    } catch (\Throwable $e) {
        die("Koneksi DB Gagal: " . $e->getMessage() . "\n");
    }

	$chapter = new ChapterAction($dbPool, $logger);

	go(function() use (&$chapter) {
	for ($i = 1; $i <= 4; $i++) {
	        $name = "Chapter $i";
	        $cover = 'https://ccdn.lezhin.com/v2/comics/7011758181739780/episodes/7021759279999448/images/cover.webp?updated=1759280016580&width=164';
	        $array = [
	            'series_id' => 4,
	            'number' => $i,
	            'name' => $name,
	            'created_by' => 1,
	            'content' =>  msgpack_pack(json_decode('{"url":"https:\/\/img.tonjit.workers.dev","dir":"2025-november","files":["60b2345bac0b206562a99c6f3b7dc38b.webp","dac321ea387b836629134aa4ad3068b6.webp","f1547269f6cae369a53503e3d05d9645.webp","58caa4edcc416be679d71caf47eca857.webp","bf0bdb19e7fb965ddadaf58693c80111.webp","a84a7ffb26668873a899c3ff0ec6ed33.webp","d348d37fdd34c425980ec02895a3b159.webp","964e417280c949edbe8d8b990ad64d62.webp","4acc9a87f7f9b742aa12da893c5c4276.webp","7abd0e8b5f26a074fca299787d8f31e5.webp","9707a575ba5ffc55736206cdaec37677.webp","7b14efd15f1ad4d547082d6391349280.webp","bcd63302e09d847f70eeeb1f895a7dbf.webp","5bc20e260faa802737a793f76fcf4d81.webp","e4bd38d960429f8c6c2a2d9fcd6d72fe.webp","444623728c0090d02b37b2cf16487337.webp","1e6ae44db8e80276e7b42ac3c2a4d8ca.webp","4affc0d8ed5ebff5a00a88c404ce3dbb.webp","59da78b67529ddcc9a7e7084262b4af3.webp","42f482bfa0964d1ea0f0cbb98e292774.webp","841d15b1060be57a34e133d0fdd1700a.webp","44ae14987a861a835131a7c3759deda9.webp","ea7a4318f13cdffee3748f2a5530ffdd.webp","ca32f57e1ff0410de8205de40b3707c9.webp","e5022e3d797dbf35d4e82c262888d992.webp","1381850c66d6339a3138fa2d0fd7e92a.webp","640a238c92d05ff8a708c7140b827b99.webp","137715e52e4010f81c586baac88668fa.webp","28d7e0f4322ef43e7dab8d8cad67ef33.webp","1b2464f7a0d1514af026f5aead36e408.webp","2b644c8e6c078894ca83747ee8f8f395.webp","426959fe2f20e5a2745306f87827170f.webp","f5e738469992fe4cfe3462ff1cf53b44.webp","e581f5f7813f9ffa1d2eb423498b73f8.webp","b567c4be815208b7e6bcd466dbe3f3d0.webp","2f7044fe1134de6d7d07640c5c2e49b9.webp","84a004ca38bfa948b261a9f83d457d34.webp","03d414d6a8c2fd47774affe2a2481a4c.webp","b11685438248215507c018d865474be9.webp","e725cdea19b9d50420ac5d08e500c654.webp","367ed81cb8dee06fdff2398350471b26.webp","fbe581820bd4c92d69a76815f327f389.webp","e0b04592069dd3c8225b943187e3c18c.webp","34081274f3fa89db80b2fbde5e882427.webp","4528fb954c648f5f1b891d6de2ec617f.webp","4b5e98c5f43a993a77e6985819539837.webp","0a43ea02cb00b493fd8bb5211a99600a.webp","6bf3d00b72f68dbb4c3c9bf8655ed185.webp","aaaec3654484cc692310302ba3646227.webp","dac93665969fb6eea5a79075553dce15.webp","98dd2b64654476d075f152a1f540274d.webp","74f550cdae59610f92267bf323f29479.webp","5bda8a4cd0ea0d03658bc4411ebb32bf.webp","8302937fc0e715ea08924c9af79df81e.webp","4a121694d6d993543a8c101a177d64d6.webp"]}', true)),
	            'cover_url' => $cover,
	            'is_published' => 1,
	        ];
	        $x = $chapter->execute($array);
			if ($x) {
				var_dump($x);
				//echo "Done: Chapter {$i} stored with ID: {$x}\n";
			}
		}
	});
	/*go(function() use (&$chapter) {
		for ($i = 1; $i <= 20; $i++) {
	        $name = "updated $i";
	        $cover = 'https://ccdn.lezhin.com/v2/comics/7011758181739780/episodes/7021759279999448/images/cover.webp?updated=1759280016580&width=164';
	        $array = [
	            'series_id' => 1,
	            'number' => $i,
	            'name' => $name,
	            'created_by' => 1,
	            'content' =>  msgpack_pack(json_decode('{"url":"https:\/\/img.tonjit.workers.dev","dir":"2025-november","files":["60b2345bac0b206562a99c6f3b7dc38b.webp","dac321ea387b836629134aa4ad3068b6.webp"]}', true)),
	            'cover_url' => $cover,
	            'is_published' => 1,
	        ];
	        $x = $chapter->execute($array, $i);
			if ($x) {
				echo "updated: Chapter {$i} stored with ID: {$x}\n";
			}
		}
	});*/


});