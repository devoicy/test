<?php
// config.php
return [
    'site' => [
        'cache' => true,
        'system' => 'swoole',
        'url' => 'http://localhost:8022',
        'title' => 'ohmycomics.com',
        'description' => 'Explore 3D Western doujinshi and hentai manga with thousands of galleries ready to read and download.'
    ],
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'web',
        'username' => 'root',
        'password' => 'LanaAnakSoleh123'
    ],
    'jwt' => [
        'secret' => 'Google_Service_AdExchangeBuyer_EditAllOrderDealsRequest',
        'access_expire' => 3600, // 1 jam
        'refresh_expire' => 604800, // 7 hari (60*60*24*7)
    ],
    'logger' => [
        'debug' => true,
        'info' => true,
        'error' => true 
    ]
];