<?php
require_once __DIR__ . '/../vendor/autoload.php';

$config = new \Webtoon\Config(); 
$config->load(__DIR__ . '/../config.php'); 

var_dump($config->get('db'));
try {
    // Data Source Name (DSN) specifies the database type, host, and name
    $db = new PDO("mysql:host={$config->get('db')['host']};dbname={$config->get('db')['name']}", $config->get('db')['username'], $config->get('db')['password']);
    
    // Set the PDO error mode to exception for robust error reporting
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected successfully";
} catch(PDOException $e) {
    // Catch and display error message
    echo "Connection failed: " . $e->getMessage();
}


/**
 * Write cache atomic dengan logging lengkap
 *
 * @param Packer $packer
 * @param string $dir
 * @param array $data
 * @param string $title
 * @param int $perPage jumlah series per page
 * @param int $pagesPerFile jumlah page per file batch
 */
function writeCacheAtomic(string $dir, array $data, string $title, int $perPage = 25, int $pagesPerFile = 100) {
    if (!$data) return;

    $totalSeries = count($data);

    // Simpan total count
    $totalFile = $dir . '/count.bin';
    file_put_contents($totalFile.'.tmp', msgpack_pack(['title'=>$title,'total'=>$totalSeries]));
    rename($totalFile.'.tmp', $totalFile);

    // Pecah per page
    $chunks = array_chunk($data, $perPage);
    $fileIndex = 1;
    $fileData = [];

    foreach ($chunks as $i => $ids) {
        $pageNumber = ($i % $pagesPerFile) + 1;
        $fileData[$pageNumber] = $ids;

        // Simpan batch per file
        if ($pageNumber === $pagesPerFile || $i === count($chunks) - 1) {
            $filename = $dir.'/'.$fileIndex.'.bin';
            file_put_contents($filename.'.tmp', msgpack_pack($fileData));
            rename($filename.'.tmp', $filename);

            // Logging detail
            echo "===============================\n";
            echo "File: {$fileIndex}.bin\n";
            echo "Pages in file: " . count($fileData) . "\n";
            foreach ($fileData as $page => $seriesInPage) {
                echo "  Page {$page}: " . count($seriesInPage) . " series\n";
            }
            $seriesInFile = array_sum(array_map('count', $fileData));
            echo "Total series in this file: {$seriesInFile}\n";
            echo "===============================\n\n";

            $fileIndex++;
            $fileData = [];
        }
    }

    echo "===== Summary for '{$title}' =====\n";
    echo "Total series cached: {$totalSeries}\n";
    echo "Cache folder: {$dir}\n";
    echo "=================================\n\n";
}

// ---------------------------------------------------------------------
// Cache series per entity
// ---------------------------------------------------------------------
$stmt = $db->prepare("SELECT id,type,slug,name FROM entities ORDER BY id DESC");
$stmt->execute();
$entities = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach($entities as $entity){
    $stmt = $db->prepare("SELECT DISTINCT series_id FROM series_entities WHERE entity_id=? ORDER BY series_id DESC");
    $stmt->execute([$entity['id']]);
    $seriesIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if($seriesIds){
        $dir = cacheDir("bin/{$entity['type']}/{$entity['slug']}");
        writeCacheAtomic($dir, $seriesIds, $entity['name']);
        echo "Cached series for entity {$entity['type']}/{$entity['slug']}.\n\n";
    }
}
