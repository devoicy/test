<?php
declare(strict_types=1);

require_once __DIR__ . '/cache_helpers.php';

/**
 * Write entity cache (INDEX + DATA)
 */
function writeEntityCache(
    string $baseDir,
    int $entityId,
    string $type,
    string $slug,
    string $title,
    array $seriesIds,
    int $perPage = 25,
    int $pagesPerFile = 100
): void {
    if (!$seriesIds) {
        return;
    }

    $slugShard   = slugShard($slug);
    $entityShard = entityShard($entityId);

    // ===============================
    // DATA
    // ===============================
    $dataDir = "{$baseDir}/data/{$type}/{$entityShard}/{$slug}";


    // paging
    $chunks = array_chunk($seriesIds, $perPage);
    $fileNo = 1;
    $buffer = [];
    $meta = [
        'id' => $entityId,
        'type' => $type,
        'slug' => $slug,
        'title' => $title,
        'total' => count($seriesIds),
    ];

    foreach ($chunks as $i => $ids) {
        $page = ($i % $pagesPerFile) + 1;
        $buffer[$page] = array_map('intval', $ids);


        if ($page === $pagesPerFile || $i === count($chunks) - 1) {
            $data = [
                'meta' => $meta,
                'data' => $buffer
            ];
            atomicWrite(
                "{$dataDir}/{$fileNo}.bin",
                msgpack_pack($data)
            );
            $buffer = [];
            $fileNo++;
        }
    }
}
