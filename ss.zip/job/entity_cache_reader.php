<?php
declare(strict_types=1);

/**
 * Load entity cache TANPA filesystem scan
 */
function loadEntityCache(
    string $baseDir,
    string $type,
    string $slug
): ?array {
    $indexFile = "{$baseDir}/{$type}/index.bin";

    if (!is_file($indexFile)) {
        return null;
    }

    $index = msgpack_unpack(file_get_contents($indexFile));

    if (!isset($index[$slug])) {
        return null;
    }

    $shard = $index[$slug];
    $file  = "{$baseDir}/{$type}/shards/{$shard}/{$slug}.bin";

    if (!is_file($file)) {
        return null;
    }

    return msgpack_unpack(file_get_contents($file));
}
