<?php
declare(strict_types=1);

/**
 * Base cache directory
 */
function cacheBase(): string
{
    return realpath(__DIR__ . '/../cache') ?: (__DIR__ . '/../cache');
}

/**
 * Join cache path safely
 */
function cachePath(string $path): string
{
    return rtrim(cacheBase(), '/') . '/' . ltrim($path, '/');
}

/**
 * INDEX shard → berdasarkan slug
 * md5 → distribusi merata (500k slug AMAN)
 */
function slugShard(string $slug): string
{
    return substr(md5($slug), 0, 2);
}

/**
 * DATA shard → berdasarkan entityId
 * FAST & deterministic
 */
function entityShard(int $entityId): string
{
    return sprintf('%02x', $entityId & 0xff);
}

/**
 * Atomic write (tmp + rename)
 * Aman untuk concurrent reader
 */
function atomicWrite(string $file, string $data): void
{
    $dir = dirname($file);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    $tmp = $file . '.tmp';
    file_put_contents($tmp, $data, LOCK_EX);
    rename($tmp, $file);
}
