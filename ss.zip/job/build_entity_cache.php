<?php
declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/cache_helpers.php';
require __DIR__ . '/entity_cache_writer.php';

use Webtoon\Config;
use PDO;

// ===============================
// Load config
// ===============================
$config = new Config();
$config->load(__DIR__ . '/../config.php');

$db = $config->get('db');

// ===============================
// PDO
// ===============================
$pdo = new PDO(
    "mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4",
    $db['username'],
    $db['password'],
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
);

// ===============================
// Base dir
// ===============================
$baseDir = cachePath('bin/entity');

// ===============================
// Fetch entities
// ===============================
$stmt = $pdo->query(
    "SELECT id, type, slug, name
     FROM entities
     ORDER BY id DESC"
);

foreach ($stmt as $entity) {

    $q = $pdo->prepare(
        "SELECT DISTINCT series_id
         FROM series_entities
         WHERE entity_id = ?
         ORDER BY series_id DESC"
    );
    $q->execute([$entity['id']]);
    $seriesIds = $q->fetchAll(PDO::FETCH_COLUMN);

    writeEntityCache(
        $baseDir,
        (int)$entity['id'],
        $entity['type'],
        $entity['slug'],
        $entity['name'],
        $seriesIds
    );

    echo sprintf(
        "✔ %-8s %-30s (%d)\n",
        $entity['type'],
        $entity['slug'],
        count($seriesIds)
    );
}

echo "\nDONE. Entity cache generated.\n";
