<?php

require_once __DIR__ . '/../vendor/autoload.php';

$db  = Database::getInstance();
$pdo = $db->getConnection();

$dir   = cacheDir('viewCount');
$files = glob($dir . '/*.txt');

foreach ($files as $file) {

    // --- Open file ---
    $fp = fopen($file, 'c+'); // pake c+ biar tetap aman
    if (!$fp) continue;

    // --- Lock file ---
    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        continue;
    }

    $success = false;

    try {
        // --- Baca isi file ---
        $contents = stream_get_contents($fp);
        $views    = (int)$contents;

        if ($views <= 0) {
            throw new RuntimeException("Views <= 0");
        }

        // --- Ambil slug dan chapter ---
        $info = pathinfo($file);
        [$slug, $chapterNum] = array_pad(explode('|', $info['filename']), 2, null);

        if (!$slug || !$chapterNum) {
            throw new RuntimeException("Slug atau chapter tidak valid");
        }

        $chapterNum = (float)$chapterNum;

        // --- Ambil series_id ---
        $stmt = $pdo->prepare('SELECT series_id FROM series_summary WHERE slug = ? LIMIT 1');
        $stmt->execute([$slug]);
        $seriesId = $stmt->fetchColumn();

        if (!$seriesId) {
            throw new RuntimeException("Series tidak ditemukan");
        }

        // --- Ambil chapter_id ---
        $stmt = $pdo->prepare(
            'SELECT id 
             FROM chapters 
             WHERE series_id = ? AND number = ? 
             LIMIT 1'
        );
        $stmt->execute([$seriesId, $chapterNum]);
        $chapterId = $stmt->fetchColumn();

        if (!$chapterId) {
            throw new RuntimeException("Chapter tidak ditemukan");
        }

        // --- Mulai transaksi ---
        $pdo->beginTransaction();

        // Update chapter_summary
        $pdo->prepare(
            'UPDATE chapter_summary 
             SET views_count = views_count + ? 
             WHERE chapter_id = ?'
        )->execute([$views, $chapterId]);

        // Update series_summary
        $pdo->prepare(
            'UPDATE series_summary 
             SET views_count = views_count + ? 
             WHERE series_id = ?'
        )->execute([$views, $seriesId]);

        $pdo->commit();
        $success = true;

    } catch (\Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // error_log($e->getMessage()); // boleh aktifkan kalau perlu
    }

    fclose($fp); // release lock

    if ($success) {
        unlink($file);
    }
}
