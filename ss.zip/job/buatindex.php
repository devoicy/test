<?php

require_once __DIR__ . '/../vendor/autoload.php';

use MessagePack\Packer;
use MessagePack\PackOptions;

// --------------------------------------
// Setup
// --------------------------------------
$connect = Database::getInstance();
$db = $connect->getConnection();

$packer = new Packer(PackOptions::DETECT_STR_BIN | PackOptions::FORCE_FLOAT32);

/**
 * Ambil semua series_id dari DB (opsional filter entity)
 */
function getSeriesIds(PDO $db, ?int $entityId = null): array
{
    if ($entityId) {
        $stmt = $db->prepare("
            SELECT DISTINCT series_id 
            FROM series_entities 
            WHERE entity_id = ? 
            ORDER BY series_id DESC
        ");
        $stmt->execute([$entityId]);
    } else {
        $stmt = $db->prepare("
            SELECT series_id 
            FROM series_summary 
            ORDER BY series_id DESC
        ");
        $stmt->execute();
    }

    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Generate cache multi-page secara atomic
 */
function generateCacheAtomic(
    PDO $db,
    Packer $packer,
    string $folder,
    ?array $entity = null,
    int $perPage = 25,
    int $pagesPerFile = 100
): void {

    $dir = cacheDir($folder, $entity);
    $entityId = $entity['id'] ?? null;
    $entityTitle = $entity['name'] ?? null;

    $seriesIds = getSeriesIds($db, $entityId);
    $seriesCount = count($seriesIds);

    // --------------------------------------
    // Simpan total count atomik
    // --------------------------------------
    $totalFile = $dir . '/count.bin';
    $tmpTotal = $totalFile . '.tmp';
    file_put_contents($tmpTotal, $packer->pack(['title' => $entityTitle, 'total' => $seriesCount]));
    rename($tmpTotal, $totalFile);

    // --------------------------------------
    // Pecah series per page dan simpan batch
    // --------------------------------------
    $chunks = array_chunk($seriesIds, $perPage);
    $fileIndex = 1;
    $fileData = [];

    foreach ($chunks as $i => $ids) {
        $pageNumber = ($i % $pagesPerFile) + 1;
        $fileData[$pageNumber] = $ids;

        if ($pageNumber === $pagesPerFile || $i === count($chunks) - 1) {
            $filename = $dir . '/' . $fileIndex . '.bin';
            $tmpFile = $filename . '.tmp';

            file_put_contents($tmpFile, $packer->pack($fileData));
            rename($tmpFile, $filename);

            $fileIndex++;
            $fileData = [];
        }
    }

    echo "Cached " . ($entityId ? "{$entity['type']}/{$entity['slug']}" : 'series') . " ({$seriesCount} items)" . PHP_EOL;
}

// --------------------------------------
// Generate cache untuk semua series
// --------------------------------------
echo "Generating cache for all series..." . PHP_EOL;
generateCacheAtomic(db:$db, packer:$packer, folder:'bin');

// --------------------------------------
// Generate cache untuk semua entities
// --------------------------------------
$stmt = $db->prepare("
    SELECT id, type, name, slug 
    FROM entities 
    ORDER BY id DESC
");
$stmt->execute();
$entities = $stmt->fetchAll();

echo "Generating cache for entities..." . PHP_EOL;
foreach ($entities as $entity) {
    generateCacheAtomic(db:$db, packer:$packer, folder:'bin', entity:$entity);
}

echo "Cache generation completed!" . PHP_EOL;
