<?php
require_once __DIR__ . '/../vendor/autoload.php';

$config = new \Webtoon\Config(); 
$config->load(__DIR__ . '/../config.php'); 

var_dump($config->get('db'));
try {
    // Data Source Name (DSN) specifies the database type, host, and name
    $db = new PDO("mysql:host={$config->get('db')['host']};dbname={$config->get('db')['name']}", $config->get('db')['username'], $config->get('db')['password']);
    
    // Set the PDO error mode to exception for robust error reporting
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected successfully";
} catch(PDOException $e) {
    // Catch and display error message
    echo "Connection failed: " . $e->getMessage();
}

/**
 * Write cache atomic dengan logging lengkap
 *
 * @param string $dir
 * @param array $data
 * @param string $title
 * @param int $perPage jumlah entity per page
 * @param int $pagesPerFile jumlah page per file batch
 */
function writeCacheAtomic(string $dir, array $data, string $title, int $perPage = 100, int $pagesPerFile = 100) {
    if (!$data) return;

    $totalEntities = count($data);

    // Pecah per page
    $chunks = array_chunk($data, $perPage);
    $fileIndex = 1;
    $fileData = [
        'meta' => [
            'title' => $title,
            'total' => $totalEntities
        ],
        'data' => []
    ];

    foreach ($chunks as $i => $ids) {
        $pageNumber = ($i % $pagesPerFile) + 1;
        $fileData['data'][$pageNumber] = $ids;

        // Simpan batch per file
        if ($pageNumber === $pagesPerFile || $i === count($chunks) - 1) {
            $filename = $dir.'/'.$fileIndex.'.bin';
            file_put_contents($filename.'.tmp', msgpack_pack($fileData));
            rename($filename.'.tmp', $filename);

            // Logging detail
            echo "===============================\n";
            echo "File: {$fileIndex}.bin\n";
            echo "Pages in file: " . count($fileData) . "\n";
            foreach ($fileData as $page => $entitiesInPage) {
                echo "  Page {$page}: " . count($entitiesInPage) . " entity(s)\n";
            }
            $entitiesInFile = array_sum(array_map('count', $fileData));
            echo "Total entities in this file: {$entitiesInFile}\n";
            echo "===============================\n\n";

            $fileIndex++;
            $fileData = [];
        }
    }

    echo "===== Summary for '{$title}' =====\n";
    echo "Total entities cached: {$totalEntities}\n";
    echo "Cache folder: {$dir}\n";
    echo "=================================\n\n";
}

// ---------------------------------------------------------------------
// Cache entity IDs per type
// ---------------------------------------------------------------------
$entityTypes = [
    "alternative-title","artist","author","character","demographic",
    "end-date","genre","group","language","parody","publisher",
    "release-date","serialization-site","status","tag","theme","translation","type"
];

foreach($entityTypes as $type){
    $stmt = $db->prepare("SELECT id FROM entities WHERE type=? ORDER BY id DESC");
    $stmt->execute([$type]);
    $entityIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if ($entityIds) {
        $dir = cacheDir('bin/entity/list/'.$type);
        writeCacheAtomic($dir, $entityIds, "Entities {$type}");
        echo "Cached entity IDs for type {$type}.\n\n";
    }
}
