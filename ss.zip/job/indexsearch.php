<?php

require_once __DIR__ . '/../vendor/autoload.php';
use MessagePack\Packer;
use MessagePack\PackOptions;
use Webtoon\Config; // Asumsi Class Config ada
use Database; 
use Swoole\Runtime;
use Swoole\Coroutine;
Runtime::enableCoroutine();

Coroutine::create(function () {
    $packer = new Packer(PackOptions::DETECT_STR_BIN | PackOptions::FORCE_FLOAT32);

    // --- 1. Inisialisasi Dependensi ---
    try {
        $config = new \Webtoon\Config(); 
        $config->load(__DIR__ . '/../config.php'); 

        // Ambil kredensial DB yang sudah di-load
        $dbConfig = $config->get('db'); 

        // ✅ DEBUGGING KRUSIAL: PASTIKAN KREDENSIAL TIDAK KOSONG
        if (empty($dbConfig['host']) || empty($dbConfig['name']) || empty($dbConfig['username'])) {
            die("❌ FATAL: Konfigurasi Database (host/name/user) kosong atau gagal dimuat dari config.php.\n");
        }
        
        // Inisiasi Database Pool Anda
        $dbPool = new Database($config, 2); 
        echo "Status: Database Pool 5 Koneksi Siap (Kredensial OK).\n";

    } catch (\Throwable $e) {
        die("Koneksi DB Gagal: " . $e->getMessage() . "\n");
    }

    $dir = cacheDir('search') . '/search.bin';
    $stmt = null;
    try {

        $pdo = $dbPool->getConnection();
        $stmt = $pdo->prepare(
            "SELECT series_id, name, slug, cover_url, updated_at
            FROM series_summary 
            ORDER BY series_id DESC"
        );
        $stmt->execute();
        $x = $stmt->fetchAll();
        file_put_contents($dir, gzencode($packer->pack($x), 9));

    } finally {
        if($stmt) {
            $stmt->closeCursor();
        }
        $dbPool->releaseConnection($pdo);
    
    }

});