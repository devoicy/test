<?php
declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/cache_helpers.php';
require __DIR__ . '/entity_cache_reader.php';

$data = loadEntityCache(
    cacheDir('bin/entity'),
    'genre',
    'action'
);

$page1 = $data['pages'][0] ?? [];

$c = msgpack_unpack(file_get_contents('/home/lana/Documents/last/cache/bin/entity/data/status/70/finished/1.bin'));
var_dump($c);