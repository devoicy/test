class Related {
    constructor(containerId = "related") {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.warn("Related container not found");
            return;
        }

        const path = window.location.pathname;
        const pathSegments = path.split('/');
        const lastSegment = pathSegments.pop() || pathSegments.pop(); 

        this.seriesId = this.container.getAttribute("data-series-id") || "";
        this.keyword = lastSegment;
    }

    async load() {
        if (!this.container) return;

        try {
            const res = await fetch(`/api/p/related/${this.seriesId}/${this.keyword}`, {
                method: "GET"
            });

            const arr = await res.json();

            if (!arr?.data || arr.data.length < 1) {

                this.container.innerHTML = '<p style="margin: auto;padding: 1rem;">No series available</p>';
                return;
            }

            this.render(arr.data);

        } catch (err) {
            console.warn("Related fetch error:", err);
        }
    }

    render(items) {
        items.forEach(a => {
            const el = document.createElement("a");
            const entity = a.entities;
            el.href = `/title/${a.series_id}/${a.slug}`;
            el.classList.add("lzLinkCard", "lzFadeIn");

            el.innerHTML = `
                <div class="lzCard lzCard9x16">
                    <div class="lzCardThumbnail">
                        <img data-lazy-src="${a.cover_url}" alt="${a.name}" class="lazyload">
                    </div>
                    <div class="lzCardBody">
                        <p class="lzCardTitle">${a.name}</p>
                        <p class="lzCardMeta">${entity?.author?.[0]?.title || ''}</p>
                        <div class="lzCardFooter">
                            <div class="lzCardMeta lzMetaHide">${entity?.genre?.[0]?.title || ''}</div>
                            <div class="lzCardMeta lzMetaHide">${a.chapters_count} Chapter</div>
                        </div>
                    </div>
                </div>
            `;

            this.container.appendChild(el);

            // Fade in animation
            requestAnimationFrame(() => {
                setTimeout(() => el.classList.add("show"), 200);
            });
        });
    }
}