class TimeAgo {
  constructor(selector = '.time', locale = 'en', options = {}) {
    this.selector = selector;
    this.locale = locale;
    this.showSeconds = options.showSeconds ?? false;
    this.maxUnits = options.maxUnits ?? 2; // max unit yang ditampilkan
    this.updateInterval = options.updateInterval ?? 1000;
    this.observeMutations();
    this.updateAll();
    this.startAutoUpdate();
  }

  getUnits(diffSeconds) {
    return [
      { unit: 'year', seconds: 3600*24*365 },
      { unit: 'month', seconds: 3600*24*30 },
      { unit: 'day', seconds: 3600*24 },
      { unit: 'hour', seconds: 3600 },
      { unit: 'minute', seconds: 60 },
      { unit: 'second', seconds: 1 }
    ];
  }

  formatTime(diffSeconds) {
    const units = this.getUnits(diffSeconds);
    const parts = [];
    let remainder = diffSeconds;

    for (const { unit, seconds } of units) {
      const amount = Math.floor(remainder / seconds);
      if (amount > 0 || (unit === 'second' && parts.length === 0)) {
        // skip detik jika showSeconds = false
        if (unit === 'second' && !this.showSeconds && parts.length > 0) continue;
        parts.push(`${amount}${unit[0]}`); // h, m, s
        remainder -= amount * seconds;
      }
      if (parts.length >= this.maxUnits) break;
    }

    return parts.join(' ') + ' ago';
  }

  updateElement(el) {
    const datetime = el.dataset.datetime;
    if (!datetime) return;
    const date = new Date(datetime);
    const diffSeconds = Math.floor((new Date() - date) / 1000);
    el.textContent = this.formatTime(diffSeconds);
  }

  updateAll() {
    document.querySelectorAll(this.selector).forEach(el => this.updateElement(el));
  }

  startAutoUpdate() {
    // Hanya jalankan interval jika maxUnits > 2
    if (this.maxUnits <= 2) return;
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.updateAll(), this.updateInterval);
  }

  observeMutations() {
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType !== 1) return;
          if (node.matches(this.selector)) this.updateElement(node);
          node.querySelectorAll && node.querySelectorAll(this.selector).forEach(el => this.updateElement(el));
        });
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }
}

// Usage
document.addEventListener("DOMContentLoaded", () => {
  // Interval hanya aktif jika maxUnits > 2
  new TimeAgo('.time', 'en', { maxUnits: 2, showSeconds: false });
});
