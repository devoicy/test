class FavoriteManager {
  constructor() {
    this.localKey = "bookmark";
    this.favorites = new Set();
    this.requestLock = new Set();
    this.isInitialized = false;

    this.initAuthListener();
  }

  async init() {
    const cached = localStorage.getItem(this.localKey);
    if (cached) {
      this.favorites = new Set(JSON.parse(cached));
      this.updateAllUI();
    }

    this.bindEvents();

    await window.Auth.ready;
    this.isInitialized = true;

    if (window.Auth.isAuthenticated && this.favorites.size === 0) {
      await this.loadFromDB();
    }
  }

  isLocked(id) {
    return this.requestLock.has(id);
  }

  lock(id) {
    this.requestLock.add(id);
  }

  unlock(id) {
    this.requestLock.delete(id);
  }

  initAuthListener() {
    window.addEventListener("auth:status-changed", e => {
      if (!e.detail.authenticated) {
        this.favorites.clear();
        localStorage.removeItem(this.localKey);
        this.updateAllUI();
      }
    });
  }

  async loadFromDB() {
    if (!window.Auth.isAuthenticated) return;

    try {
      const res = await window.Auth.authFetch("/api/a/bookmark/lists");
      if (!res.ok) return;

      const json = await res.json();
      if (json.status && Array.isArray(json.data)) {
        this.favorites = new Set(json.data);
        this.saveLocal();
        this.updateAllUI();
      }
    } catch (e) {
      console.error("[Bookmark] load failed", e);
    }
  }

  async toggle(seriesId, btn) {
    if (!window.Auth.isAuthenticated) {
      window.Auth.showLoginModal();
      return;
    }

    const id = Number(seriesId);
    if (!id || !btn) return;

    if (this.isLocked(id)) {
      window.Snackbar?.show('Please wait a moment, your old action is being processed')
      return;
    }

    this.lock(id);

    try {
      const res = await window.Auth.authFetch("/api/a/bookmark/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ seriesId: id })
      });

      const json = await res.json();
      if (res.ok && json.status) {
        json.message === "Bookmark added"
          ? this.favorites.add(id)
          : this.favorites.delete(id);

        window.Snackbar?.show(json.message);
        this.saveLocal();
        this.updateAllUI();
      }

      if(!res.ok && json.status) window.Snackbar?.show(json.message);
    } catch (e) {
      console.error("[Bookmark] toggle failed", e);
    } finally {
      setTimeout(() => this.unlock(id), 10000);
    }
  }

  updateAllUI() {
    document
      .querySelectorAll(".bookmark-btn[data-series-id]")
      .forEach(btn => {
        const id = Number(btn.getAttribute("data-series-id"));
        const icon = this.favorites.has(id)
          ? "bookmark-check"
          : "bookmark-plus";

        if (btn.getAttribute("data-icon") !== icon) {
          btn.setAttribute("data-icon", icon);
          btn.style.transform = "scale(1.2)";
          setTimeout(() => (btn.style.transform = "scale(1)"), 100);
        }
      });
  }

  saveLocal() {
    localStorage.setItem(this.localKey, JSON.stringify([...this.favorites]));
  }

  bindEvents() {
    document.addEventListener("click", e => {
      const btn = e.target.closest(".bookmark-btn");
      if (btn) this.toggle(btn.dataset.seriesId, btn);
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  window.FavoriteManager = new FavoriteManager();
  window.FavoriteManager.init();
});
