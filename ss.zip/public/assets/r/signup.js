class ModalSheet {
  constructor(modalId, backdropId, handleId, openBtnId = '') {
    this.modal = document.getElementById(modalId);
    this.backdrop = document.getElementById(backdropId);
    this.handle = document.getElementById(handleId);
    //this.openBtn = document.getElementById(openBtnId);

    this.startY = 0;
    this.startHeight = 0;

    this.init();
  }

  init() {
    //this.openBtn?.addEventListener("click", this.openModal);
    this.backdrop?.addEventListener("click", this.closeModal);
    this.handle?.addEventListener("mousedown", this.startDrag);
  }

  openModal = () => {
    this.modal?.classList.add("show");
    this.backdrop?.classList.add("show");
  };

  closeModal = () => {
    this.modal?.classList.remove("show");
    this.backdrop?.classList.remove("show");
    this.modal?.setAttribute('style','');
  };

  startDrag = (e) => {
    this.startY = e.clientY;
    this.startHeight = this.modal.offsetHeight;
    document.body.style.userSelect = 'none';

    const onMouseMove = (eMove) => {
      const deltaY = this.startY - eMove.clientY;
      let newHeight = this.startHeight + deltaY;
      if (newHeight > window.innerHeight) newHeight = window.innerHeight;
      if (newHeight < 100) newHeight = 100;
      this.modal.style.height = newHeight + 'px';
      this.modal.style.bottom = '0';
    }

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      document.body.style.userSelect = '';
      if (this.modal.offsetHeight < 150) this.closeModal();
    }

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  }
}

// Example usage:
document.addEventListener("DOMContentLoaded", () => {
  //new ModalSheet("sheetModal", "backdrop", "dragHandle", "openSheetBtn");
  window.ModalSheet = new ModalSheet("sheetModal", "backdrop", "dragHandle")
});