class LazyLoad {
    constructor() {
        // IntersectionObserver untuk lazy load
        this.observer = new IntersectionObserver(
            entries => this.onIntersect(entries),
            { threshold: 0.1 }
        );

        // tunggu DOM siap sebelum scan & observe mutations
        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", () => {
                this._onDomReady();
            });
        } else {
            // DOM sudah siap (script di footer)
            this._onDomReady();
        }
    }

    _onDomReady() {
        // initial scan seluruh dokumen
        this.scan(document);

        // init MutationObserver aman (pastikan body ada)
        this.initMutationObserver();
    }

    initMutationObserver() {
        // guard: jika sudah di-init, skip
        if (this._mo) return;

        this._mo = new MutationObserver(mutations => this.onMutation(mutations));

        // body mungkin null di kasus aneh; fallback ke documentElement
        const root = document.body || document.documentElement;
        if (!root) return; // ekstra safety

        this._mo.observe(root, { childList: true, subtree: true });
    }

    onIntersect(entries) {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;

            const box = entry.target;
            // cari img di dalam container — gunakan selector yang pasti
            const img = box.querySelector("img.lazyload[data-lazy-src]");
            if (!img) return;

            const realSrc = img.getAttribute("data-lazy-src");
            if (!realSrc) return;

            img.src = realSrc;

            img.onload = () => {
                box.classList.remove("loading");
                box.classList.add("loaded");
            };

            this.observer.unobserve(box);
        });
    }

    scan(scope) {
        if (!scope || !scope.querySelectorAll) return;

        const imgs = scope.querySelectorAll("img.lazyload[data-lazy-src]");
        imgs.forEach(img => {
            if (img.dataset._lazyInit) return;
            img.dataset._lazyInit = "1";

            // placeholder 1px GIF
            if (!img.src) {
                img.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
            }

            const box = img.parentElement || img;
            box.classList.add("loading");
            this.observer.observe(box);
        });
    }

    onMutation(mutations) {
        // process added nodes (efficient)
        for (const m of mutations) {
            for (const node of m.addedNodes) {
                if (node.nodeType !== 1) continue; // hanya element

                // jika node sendiri adalah img.lazyload
                if (node.matches && node.matches("img.lazyload[data-lazy-src]")) {
                    const parent = node.parentElement || node;
                    this.scan(parent);
                    continue;
                }

                // jika node mengandung images lazy
                if (node.querySelectorAll) {
                    const imgs = node.querySelectorAll("img.lazyload[data-lazy-src]");
                    if (imgs.length > 0) this.scan(node);
                }
            }
        }
    }
}

// auto init single instance (safe)
if (!window.lazyload) {
    window.lazyload = new LazyLoad();
}
