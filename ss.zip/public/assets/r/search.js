/*****************************
 * CLASS: IndexedDB Manager
 *****************************/
class IndexedDBManager {
  constructor(dbName, version, storeName, fileId, fileUrl) {
    this.dbName = dbName;
    this.version = version;
    this.storeName = storeName;
    this.fileId = fileId;
    this.fileUrl = fileUrl;
    this.db = null;
  }

  async init() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(this.dbName, this.version);

      req.onupgradeneeded = e => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName, { keyPath: "id" });
        }
      };

      req.onsuccess = e => {
        this.db = e.target.result;
        resolve();
      };

      req.onerror = err => reject(err);
    });
  }

  getFileRecord() {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.storeName, "readonly");
      const store = tx.objectStore(this.storeName);
      const req = store.get(this.fileId);

      req.onsuccess = () => resolve(req.result || null);
      req.onerror = err => reject(err);
    });
  }

  saveFileBlob(blob) {
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(this.storeName, "readwrite");
      const store = tx.objectStore(this.storeName);
      store.put({ id: this.fileId, data: blob, lastUpdated: Date.now() });

      tx.oncomplete = () => resolve();
      tx.onerror = err => reject(err);
    });
  }

  async fetchAndStoreFile() {
    const res = await fetch(this.fileUrl);
    if (!res.ok) throw new Error("Fetch failed");

    const buffer = await res.arrayBuffer();
    const blob = new Blob([buffer]);

    await this.saveFileBlob(blob);
  }

  async checkAndUpdate(oneDayMs) {
    const record = await this.getFileRecord();

    if (!record) {
      await this.fetchAndStoreFile();
    } else if (!record.lastUpdated || Date.now() - record.lastUpdated > oneDayMs) {
      await this.fetchAndStoreFile();
    }
  }

  async getDecodedData() {
    const record = await this.getFileRecord();
    if (!record) return [];

    const bytes = new Uint8Array(await record.data.arrayBuffer());
    const decoded = msgpack.decode(bytes);

    return Array.isArray(decoded) ? decoded : [];
  }
}

/*****************************
 * CLASS: Search Engine
 *****************************/
class SearchEngine {
  constructor(limit = 25) {
    this.limit = limit;
    this.data = [];
    this.filtered = [];
    this.page = 1;
    this.totalPages = 1;
  }

  load(data) {
    this.data = data;
    this.filtered = data;
    this.page = 1;
    this.totalPages = Math.ceil(this.filtered.length / this.limit);
  }

  search(query) {
    if (!query.trim()) {
      this.filtered = this.data;
    } else {
      const q = query.toLowerCase();
      this.filtered = this.data.filter(item => item.name?.toLowerCase().includes(q));
    }
    this.page = 1;
    this.totalPages = Math.ceil(this.filtered.length / this.limit);
  }

  getPageData() {
    const start = (this.page - 1) * this.limit;
    return this.filtered.slice(start, start + this.limit);
  }
}

/*****************************
 * CLASS: UI Controller
 *****************************/
class SearchController {
  constructor(engine) {
    this.engine = engine;

    this.input = document.getElementById("searchInput");
    this.here = document.getElementById("contain");
    this.container = null;
    this.list = null;
    this.pagination = null;

    this.btnSearch = document.getElementById("searchBtn");

    this.registerEvents();
  }

  registerEvents() {
    // tombol search (jika mau dipakai)
    this.btnSearch.addEventListener("click", () => {});

    // input ENTER
    this.input.addEventListener("keydown", e => {

      // buat popup search (sekali per ENTER)
      this.here.innerHTML = `
        <div class="lz max-w-1212" id="searchc"
             style="display:none;position:fixed;padding-top:75px;
             top:0;left:50%;transform:translateX(-50%);
             width:100%;height:100vh;z-index:999;background:var(--md-surface)">

          <div class="infs base-btn">
            <span style="font-size:1.1rem;">Search Result</span>
            <button class="icon-btn svg no-line reset" data-icon="delete" id="clear"></button>
          </div>

          <div class="lzCardList" id="search" style="margin-bottom: 2rem;"></div>
          <div class="fwr pt-1" style="margin-bottom: 2rem;">
			<div class="fwr gp05" style="display: flex;flex-wrap: wrap;gap: 6px;justify-content: center;align-items: center;" id="pagination"></div>
      	</div>

        </div>`;

      // bind elemen
      this.container  = this.here.querySelector('#searchc');
      this.btnClear   = this.container.querySelector('#clear');
      this.list       = this.container.querySelector('#search');
      this.pagination = this.container.querySelector('#pagination');

      // tombol close popup
      this.btnClear.onclick = () => {
        this.container.style.display = "none";
        document.body.classList.remove("no-scroll");
      };

      // eksekusi ENTER untuk search
      if (e.key === "Enter") {
        this.container.style.display = "";
        document.body.classList.add("no-scroll");

        this.engine.search(e.target.value);
        this.render();
      }
    });
  }

  render() {
    this.renderList();
    this.renderPagination();
  }

  renderList() {
    const data = this.engine.getPageData();
    this.list.innerHTML = "";

    if (data.length === 0) {
      this.list.innerHTML = `
        <span style="margin: auto;text-align:center;">Result not found</span>
      `;
      this.pagination.innerHTML = "";
      return;
    }

    data.forEach(item => {
      const a = document.createElement("a");
      a.className = "lzLinkCard";
      a.href = "#";

      a.innerHTML = `
        <div class="lzCard lzCard9x16">
          <div class="lzCardThumbnail">
            <img data-lazy-src="${item.cover_url}" alt="${item.name}" class="lazyload">
          </div>
          <div class="lzCardBody">
            <p class="lzCardTitle">${item.name}</p>
            <p class="lzCardMeta time" data-datetime="${item.updated_at}"></p>
          </div>
        </div>
      `;
      this.list.appendChild(a);
    });
  }

  renderPagination() {
    const total = this.engine.totalPages;
    const current = this.engine.page;

    this.pagination.innerHTML = "";
    if (total <= 1) return;

    const makeBtn = (label, page, disabled = false, icon = null) => {
      const el = document.createElement(disabled ? "div" : "a");

      el.className = disabled
        ? "base-btn btn-filled-disabled"
        : "base-btn btn-filled";

      if (!disabled) el.href = "#";

      el.innerHTML = `
        ${icon === "left" ? '<span class="icon-btn svg" data-icon="chevron-left"></span>' : ""}
        <span class="btn-t">${label}</span>
        ${icon === "right" ? '<span class="icon-btn svg" data-icon="chevron-right"></span>' : ""}
      `;

      if (!disabled) {
        el.addEventListener("click", e => {
          e.preventDefault();
          this.engine.page = page;
          this.render();
        });
      }
      return el;
    };

    // Prev
    this.pagination.appendChild(
      makeBtn("Prev", current - 1, current === 1, "left")
    );

    const delta = 2;
    for (let i = 1; i <= total; i++) {
      if (i === 1 || i === total || (i >= current - delta && i <= current + delta)) {
        const disabled = i === current;
        this.pagination.appendChild(makeBtn(i, i, disabled));
      } else if (this.pagination.lastChild?.textContent !== "...") {
        const dot = document.createElement("div");
        dot.className = "base-btn btn-filled-disabled";
        dot.innerHTML = `<span class="btn-t">...</span>`;
        this.pagination.appendChild(dot);
      }
    }

    // Next
    this.pagination.appendChild(
      makeBtn("Next", current + 1, current === total, "right")
    );
  }
}

/*****************************
 * BOOTSTRAP
 *****************************/
document.addEventListener("DOMContentLoaded", async () => {
  const db = new IndexedDBManager(
    "MyDB",
    1,
    "files",
    "largeFile",
    "/api/p/search"
  );

  await db.init();
  await db.checkAndUpdate(24 * 60 * 60 * 1000);

  const engine = new SearchEngine(25);
  const ui = new SearchController(engine);

  const data = await db.getDecodedData();
  engine.load(data);

  //if (ui.list) ui.render();
});
