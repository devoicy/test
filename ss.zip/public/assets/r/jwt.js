class AuthManager {
  constructor() {
    this._status = "loading";
    this.isRefreshing = false;
    this.refreshQueue = [];
    this.lastCheck = 0;
    this.throttleTime = 60000;
    this.storageKey = "auth_logged_in";
    this.uiRendered = false;

    this.ready = this.initialize();
    this.initWatchers();
  }

  get isAuthenticated() {
    return this._status === "authenticated";
  }

  get status() {
    return this._status;
  }

  async initialize() {
    try {
      const res = await fetch("/api/a/auth/check", {
        credentials: "include"
      });

      if (res.ok) {
        this._status = "authenticated";
        this.applyAuthenticatedUI();
        this.syncStorage(true);
        this.emit();
        return true;
      }

      const data = await res.json().catch(() => ({}));
      if (data.message === "TOKEN_EXPIRED") {
        const refreshed = await this.refreshToken();
        if (refreshed) {
          this._status = "authenticated";
          this.applyAuthenticatedUI();
          this.syncStorage(true);
          this.emit();
          return true;
        }
      }

      this._status = "unauthenticated";
      this.syncStorage(false);
      this.emit();
      return false;

    } catch {
      this._status = "unauthenticated";
      this.syncStorage(false);
      this.emit();
      return false;
    }
  }

  syncStorage(isValid) {
    localStorage.setItem(this.storageKey, isValid ? "1" : "0");
  }

  emit() {
    window.dispatchEvent(
      new CustomEvent("auth:status-changed", {
        detail: {
          authenticated: this.isAuthenticated,
          status: this._status
        }
      })
    );
  }

  async authFetch(url, options = {}) {
    options.credentials = "include";

    let res = await fetch(url, options);

    if (res.status === 401) {
      const data = await res.clone().json().catch(() => ({}));

      if (data.message === "TOKEN_EXPIRED") {
        try {
          await this.refreshToken();
          return fetch(url, options);
        } catch {
          this.handleSessionFailure();
          throw new Error("UNAUTHENTICATED");
        }
      }

      this.handleSessionFailure();
      throw new Error("UNAUTHENTICATED");
    }

    return res;
  }

  async refreshToken() {
    if (this.isRefreshing) {
      // Jika sedang refresh, balikkan promise yang akan settle nanti
      return new Promise((resolve, reject) => {
        this.refreshQueue.push({ resolve, reject });
      });
    }

    this.isRefreshing = true;

    try {
      const res = await fetch("/api/a/auth/refresh", {
        credentials: "include"
      });

      if (!res.ok) {
        // Jika status code bukan 2xx (misal 401), lempar error
        throw new Error("REFRESH_FAILED");
      }
      
      // Berhasil: Selesaikan semua antrian yang menunggu
      this.refreshQueue.forEach(p => p.resolve(true));
      return true;

    } catch (err) {
      // Gagal: Tolak semua antrian yang menunggu dengan error yang sama
      this.refreshQueue.forEach(p => p.reject(err));
      
      // Lempar kembali agar pemanggil utama (pemicu refresh) tahu kalau ini gagal
      throw err;

    } finally {
      // Selalu jalankan ini baik berhasil maupun gagal
      this.isRefreshing = false;
      this.refreshQueue = []; 
    }
  }

  initWatchers() {
    window.addEventListener("storage", (e) => {
      if (e.key === this.storageKey && e.newValue === "0") {
        this.handleSessionFailure(false);
      }
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        const now = Date.now();
        if (now - this.lastCheck > this.throttleTime) {
          this.validateSilently();
        }
      }
    });
  }

  async validateSilently() {
    try {
      const res = await fetch("/api/a/auth/check", {
        credentials: "include"
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        if (data.message === "TOKEN_EXPIRED") {
          await this.refreshToken();
        } else {
          this.handleSessionFailure();
        }
      }

      this.lastCheck = Date.now();
    } catch {}
  }

  applyAuthenticatedUI() {
    document.body.classList.add("logged-in");

    if (!this.uiRendered) {
      this.renderAuthenticatedUI();
      this.uiRendered = true;
    }
  }

  applyUnauthenticatedUI() {
    document.body.classList.remove("logged-in");
    this.cleanupAuthenticatedUI();
    this.uiRendered = false;
  }

  renderAuthenticatedUI() {
    this.createDrawerButton(
      "drawer",
      "bookmark-box",
      "Bookmarks",
      () => (window.location = "/bookmarks")
    );

    this.createDrawerButton(
      "drawer",
      "logout",
      "Logout",
      () => this.signout()
    );

    const loginBtn = document.getElementById("login-btn");
    if (loginBtn) loginBtn.style.display = "none";
  }

  cleanupAuthenticatedUI() {
    document.querySelectorAll(".dynamic-auth-item").forEach(el => el.remove());
    const loginBtn = document.getElementById("login-btn");
    if (loginBtn) loginBtn.style.display = "block";
  }

  createDrawerButton(parentId, icon, text, handler) {
    const parent = document.getElementById(parentId);
    if (!parent) return;

    const id = `auth-btn-${text}`;
    if (document.getElementById(id)) return;

    const div = document.createElement("div");
    div.className = "ddrawer dynamic-auth-item";
    div.id = id;

    const a = document.createElement("a");
    a.className = "addrawer";
    a.addEventListener("click", handler);
    a.innerHTML = `
      <span class="drawerItem icon-btn svg no-line" data-icon="${icon}"></span>
      <span>${text}</span>
    `;

    div.appendChild(a);
    parent.appendChild(div);
  }

  handleSessionFailure(showModal = true) {
    if (this._status === "unauthenticated") return;

    this._status = "unauthenticated";
    this.applyUnauthenticatedUI();
    this.syncStorage(false);
    this.emit();

    if (showModal) this.showLoginModal();
  }

  signout() {
    this.handleSessionFailure(false);
    fetch("/auth/signout", { credentials: "include" })
      .finally(() => (window.location.href = "/"));
  }

  showLoginModal() {
    if (window.ModalSheet) window.ModalSheet.openModal();
  }
}

window.Auth = new AuthManager();
