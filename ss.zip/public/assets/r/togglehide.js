class ToggleHide {
  constructor(options) {
    this.box = document.querySelector(options.box);
    this.button = document.querySelector(options.button);
    this.previewHeight = options.previewHeight || 120;

    if (!this.box || !this.button) return;

    this.init();
    this.bindEvents();
  }

  init() {
    // Hide tombol jika konten pendek
    if (this.box.scrollHeight <= this.previewHeight + 10) {
      this.button.style.display = "none";
    }

    // Set preview awal
    this.box.style.maxHeight = this.previewHeight + "px";
  }

  bindEvents() {
    this.button.addEventListener("click", () => this.toggle());
  }

  toggle() {
    const expanded = this.box.classList.toggle("expanded");

    if (expanded) {
      this.expand();
    } else {
      this.collapse();
    }
  }

  expand() {
    this.box.style.maxHeight = this.box.scrollHeight + "px";
    this.button.textContent = "Show Less";
    this.button.style.background = "rgba(106, 105, 105, 0.23)";
  }

  collapse() {
    this.box.style.maxHeight = this.previewHeight + "px";
    this.button.textContent = "Show More";
    this.button.removeAttribute("style");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  new ToggleHide({
    box: ".hide",
    button: ".toggle-hide-btn",
    previewHeight: 100
  });
});