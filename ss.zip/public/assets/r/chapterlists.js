class ChapterList {
    constructor(container) {
        this.container = container;
        this.sortBtn = document.getElementById("btnSort");

        this.chaptersData = [];
        this.isNewestFirst = true;

        this.bindEvents();
        this.loadChapters();
    }

    bindEvents() {
        // Hanya bind jika tombol sort ada
        if (this.sortBtn) {
            this.sortBtn.addEventListener("click", () => this.onSortClick());
        }
    }

    async loadChapters() {
        const seriesId = this.container.dataset.seriesId;
        if (!seriesId) return console.warn("err seriesId");

        try {
            const res = await fetch("/api/p/chapter/lists/"+seriesId, {
                method: "GET"
            });

            this.chaptersData = await res.json();
            if (!Array.isArray(this.chaptersData.data) || this.chaptersData.data.length === 0) {
                this.container.innerHTML = `<p style="margin: auto;padding: 1rem;">No chapters available</p>`;
                this.initRelatedObserver()
                return;
            }
            const r = this.chaptersData.data[this.chaptersData.data.length-1];
            const btnRead = document.createElement('a')
            btnRead.classList.add('base-btn', 'btn-filled', 'btn-b');
            btnRead.innerHTML = '<span class="btn-t">Start Reading</span>';
            btnRead.href = window.location.href+'/'+r.number;
            document.querySelector('.ch_e_ll').appendChild(btnRead)
            this.renderChapters(true);
            this.initRelatedObserver()
        } catch (err) {
            console.error(err);
            this.container.innerHTML = `<p style="margin: auto;padding: 1rem;">Oops! Try again</p>`;
        }
    }

    updateSortButton() {
        if (!this.sortBtn) return; // safeguard

        const icon = this.sortBtn.querySelector("span");
        if (!icon) return;

        icon.removeAttribute("data-icon-injected");

        const state = this.isNewestFirst ? "oldest" : "newest";

        const map = {
            newest:  { icon: "sort-descending" },
            oldest:  { icon: "sort-ascending" }
        };

        icon.setAttribute("data-icon", map[state].icon);
    }

    formatViews(n) {
      return Intl.NumberFormat('en', {
        notation: "compact",
        maximumFractionDigits: 1
      }).format(n);
    }

    renderChapters(animated = false) {
        this.container.innerHTML = "";

        let list = [...this.chaptersData.data];
        if (this.isNewestFirst) list.reverse();

        list.forEach((ch, i) => {
            const html = `
                <a class="ch_list ch-anim" href="${window.location.pathname}/chapter/${ch.chapter_id}/${ch.number}">
                    <div class="ch_thumb">
                        <img class="lazyload" data-lazy-src="${ch.cover_url}">
                    </div>
                    <div class="ch_list_inf">
                        <div class="ch_ds_name">${ch.number}</div>
                        <div class="ch_ttl">${ch.name}</div>
                        <div class="ch_tt_l">
                            <div class="ch_tt_l2"><div class="time" style="line-height: 3;" data-datetime="${ch.created_at}Z"></div></div>
                            <div class="ch_stt">
                                <div class="base-btn"><span>${this.formatViews(ch.views)}</span><span class="svgs no-line btn-t-l" data-icon="eye-outline"></span></div>
                            </div>
                        </div>
                    </div>
                </a>
            `;

            this.container.insertAdjacentHTML("beforeend", html);

            if (animated) {
                const el = this.container.lastElementChild;
                setTimeout(() => el.classList.add("show"), i * 40);
            }
        });
    }

    onSortClick() {
        const items = [...this.container.children];

        items.forEach((el, i) => {
            setTimeout(() => el.classList.add("sort-hide"), i * 15);
        });

        setTimeout(() => {
            this.isNewestFirst = !this.isNewestFirst;
            this.renderChapters(true);
            this.updateSortButton();
        }, 200);
    }

    initRelatedObserver() {
        const relatedEl = document.getElementById("related");
        if (!relatedEl) return;
        const r = new Related()
        // Jika sudah terlihat, langsung panggil related
        const isVisible = relatedEl.getBoundingClientRect().top < window.innerHeight;
        if (isVisible) {
           r.load(); 
            return;
        }

        // Jika belum terlihat → pakai IntersectionObserver
        const observer = new IntersectionObserver((entries, ob) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    r.load();       // panggil fungsi related
                    ob.disconnect(); // stop observer biar tidak dipanggil berkali-kali
                }
            });
        }, {
            rootMargin: "0px 0px -20% 0px" // panggil lebih cepat 20% sebelum masuk
        });

        observer.observe(relatedEl);
    }

}


document.addEventListener("DOMContentLoaded", () => {
    const chapters = document.getElementById("chapters");

    // Tidak ada elemen? → tidak usah jalan apa-apa
    if (!chapters) return;

    window.chapterList = new ChapterList(chapters);
});

