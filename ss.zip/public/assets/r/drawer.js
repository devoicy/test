class UIController {
  constructor() {
    // DOM Elements
    this.drawer = document.getElementById("drawer");
    this.overlay = document.getElementById("overlay");
    this.menuBtn = document.getElementById("menuBtn");

    this.searchBtn = document.getElementById("searchBtn");
    this.searchContainer = document.getElementById("searchContainer");
    this.clearSearch = document.getElementById("clearSearch");
    this.title = document.getElementById("title");
    this.searchInput = document.getElementById("searchInput");
    this.topbar = document.getElementById("topbar");

    // State
    this.searchOpen = false;
    this.lastScrollY = 0;

    // Initialize
    this.init();
  }

  init() {
    this.addEventListeners();
  }

  // -------- Drawer --------
  openDrawer = () => {
    this.drawer?.classList.add("open");
    this.overlay?.classList.add("show");
  };

  closeDrawer = () => {
    this.drawer?.classList.remove("open");
    this.overlay?.classList.remove("show");
  };

  toggleDrawer = () => {
    this.drawer?.classList.toggle("open");
    this.overlay?.classList.toggle("show");
  };

  // -------- Search --------
  toggleSearch = () => {
    this.searchOpen = !this.searchOpen;
    this.searchContainer?.classList.toggle("show", this.searchOpen);
    if (this.title) this.title.style.opacity = this.searchOpen ? "0" : "1";
    if (this.searchOpen) this.searchInput?.focus();
    else {
      if (this.searchInput) {
        this.searchInput.value = "";
        this.searchInput.blur();
      }
    }
  };

  clearSearch = () => {
    if (this.searchInput) {
      this.searchInput.value = "";
      this.searchInput.focus();
    }
  };

  // -------- Events --------
  handleDocumentClick = e => {
    if (!this.searchOpen) return;
    this.overlay?.classList.add("show");
    const inside = this.searchContainer?.contains(e.target) || this.searchBtn?.contains(e.target);
    if (!inside) this.toggleSearch();
  };

  handleKeydown = e => {
    if ((e.key === "Escape" || e.key === "Enter") && this.searchOpen) {
      this.toggleSearch();
      this.overlay?.classList.remove("show");
    }
  };

  handleScroll = () => {
    const current = window.scrollY;
    this.topbar?.classList.toggle('hidden', current > this.lastScrollY);
    this.lastScrollY = current;
  };

  // -------- Add all listeners --------
  addEventListeners() {
    this.menuBtn?.addEventListener("click", this.toggleDrawer);
    this.overlay?.addEventListener("click", () => {
      this.closeDrawer();
      if (this.searchOpen) this.toggleSearch();
    });

    this.searchBtn?.addEventListener("click", this.toggleSearch);
    this.clearSearch?.addEventListener("click", this.clearSearch);

    document.addEventListener("click", this.handleDocumentClick);
    document.addEventListener("keydown", this.handleKeydown);
    window.addEventListener("scroll", this.handleScroll);
  }
}

// Instantiate the controller
document.addEventListener("DOMContentLoaded", () => {
  window.UIController = new UIController();
});