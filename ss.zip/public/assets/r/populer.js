class Populer {
    /**
     * @param {string} wrapperId - ID dari .lzSliderWrapper
     * @param {string} apiUrl - URL API untuk fetch data
     * @param {object} options - opsi tambahan
     */
constructor(wrapperId, apiUrl = "/api/p/series/trending", options = {}) {
    this.wrapper = document.getElementById(wrapperId);
    
    if (!this.wrapper) {
        console.error(`Wrapper #${wrapperId} tidak ditemukan!`);
        return;
    }

    // ✅ querySelector langsung dapet elemennya (bukan folder/collection)
    // ✅ Tetap pakai TITIK karena ini selector CSS
    this.track = this.wrapper.querySelector(".lzSliderTrack");
    
    if (!this.track) {
        console.error("Elemen .lzSliderTrack tidak ada di dalam wrapper!");
        return;
    }

    // ✅ Selector kompleks (dua class sekaligus) cuma bisa jalan di querySelector
    this.prevBtn = this.wrapper.querySelector(".lzSliderBtn.prev");
    this.nextBtn = this.wrapper.querySelector(".lzSliderBtn.next");

    this.apiUrl = apiUrl;
    this.options = {
        itemsCount: options.itemsCount || 7,
        scrollStep: options.scrollStep || 220,
        autoplaySpeed: options.autoplaySpeed || 2200,
        autoplayPause: options.autoplayPause || 3500,
    };

    this.init();
}

    init() {
        this.renderPlaceholders();
        this.loadData();
        this.setupButtons();
        this.autoplay();
    }

    renderPlaceholders() {
        const { itemsCount } = this.options;
        this.track.innerHTML = "";

        for (let i = 0; i < itemsCount; i++) {
            this.track.insertAdjacentHTML("beforeend", `
                <div class="lzLinkCard">
                    <div class="lzCard lzCard9x16" style="flex: 0 0 180px;height: 280px;">
                        <div class="lzCardThumbnail loading">
                            <img src="http://localhost:8022/admin/series/add">
                        </div>
                    </div>
                </div>
            `);
        }
    }

    async loadData() {
        try {
            const res = await fetch(this.apiUrl);
            const json = await res.json();

            this.track.innerHTML = "";

            if (json.data?.length) {
                this.track.classList.add("active");
                this.track.setAttribute('style', 'background:unset;')
            }

            if(json.data?.length === 0) {
        const rootElement = this.wrapper.closest('.lz');
        if (rootElement) {
            rootElement.remove(); // Hapus seluruh section (termasuk judul H2)
        }
            }
            json.data.forEach(item => {
                let author = item.entities.author?.[0]?.title ?? "-";
                let genre = item.entities.genre?.[0]?.title ?? "-";

                this.track.insertAdjacentHTML("beforeend", `
                    <a class="lzLinkCard" href="/title/${item.slug}">
                        <div class="lzCard lzCard9x16">
                            <div class="lzCardThumbnail">
                                <img data-lazy-src="${item.cover_url}" alt="${item.name}" class="lazyload">
                            </div>
                            <div class="lzCardBody">
                                <p class="lzCardTitle">${item.name}</p>
                                <p class="lzCardMeta">${author}</p>
                                <div class="lzCardFooter">
                                    <div class="lzCardMeta lzMetaHide">${genre}</div>
                                    <div class="lzCardMeta lzMetaHide">${item.chapters_count} Chapter</div>
                                </div>
                            </div>
                        </div>
                    </a>
                `);
            });
        } catch (err) {
            console.error(`Populer load error for ${this.wrapper.id}:`, err);
        }
    }

    autoplay() {
        const { scrollStep, autoplaySpeed, autoplayPause } = this.options;
        const track = this.track;
        let timer;

        const run = () => {
            timer = setInterval(() => {
                track.scrollBy({ left: scrollStep, behavior: "smooth" });
                if (track.scrollLeft + track.clientWidth >= track.scrollWidth - 5) {
                    setTimeout(() => track.scrollTo({ left: 0, behavior: "smooth" }), 300);
                }
            }, autoplaySpeed);
        };

        run();

        track.addEventListener("scroll", () => {
            clearInterval(timer);
            clearTimeout(track._pauseTimer);
            track._pauseTimer = setTimeout(() => run(), autoplayPause);
        });
    }

    setupButtons() {
        const { scrollStep } = this.options;
        if (!this.prevBtn || !this.nextBtn) return;

        this.prevBtn.classList.add("show");
        this.nextBtn.classList.add("show");

        this.prevBtn.onclick = () => this.track.scrollBy({ left: -scrollStep, behavior: "smooth" });
        this.nextBtn.onclick = () => this.track.scrollBy({ left: scrollStep, behavior: "smooth" });
    }

}

// Inisialisasi semua slider
window.addEventListener('DOMContentLoaded', () => {
    new Populer("trending", "/api/p/series/trending");
    new Populer("toprated", "/api/p/series/toprated");
});
