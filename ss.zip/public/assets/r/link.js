class ActiveLink {
    constructor(selector = "a", activeClass = "active") {
        this.selector = selector;
        this.activeClass = activeClass;
    }

    run() {
        const path = window.location.pathname;

        document.querySelectorAll(this.selector).forEach(a => {
            const href = a.getAttribute("href");

            // cocokkan path
            if (href === path) {
                a.classList.add(this.activeClass);
            }
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    new ActiveLink("a", "active").run();
});
