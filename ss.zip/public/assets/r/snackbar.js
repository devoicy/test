class SnackbarManager {

    static container = null;

    static init() {
        if (!this.container) {
            this.container = document.createElement("div");
            this.container.id = "snackbar-container";
            this.container.style = `
                position: fixed;
                bottom: 24px;
                left: 50%;
                transform: translateX(-50%);
                display: flex;
                flex-direction: column-reverse;
                align-items: center;
                gap: 10px;
                z-index: 99999;
                pointer-events: none;
                width: 100%;
                max-width: 100%;
            `;
            document.body.appendChild(this.container);
        }
    }

    static show(message, type = "default", duration = 3500) {
        this.init();
        this.display({ message, type, duration });
    }

    static display({ message, type, duration }) {
        const snackbar = document.createElement("div");

        snackbar.className = "snackbar-item";
        snackbar.innerHTML = `<span>${message}</span>`;
        snackbar.style = this.style(type);

        this.container.appendChild(snackbar);

        requestAnimationFrame(() => {
            snackbar.style.opacity = "1";
            snackbar.style.transform = "translateY(0)";
        });

        // auto hide
        const timeout = setTimeout(() => {
            this.hide(snackbar);
        }, duration);

        // click dismiss
        snackbar.addEventListener("click", () => {
            clearTimeout(timeout);
            this.hide(snackbar);
        });
    }

    static hide(snackbar) {
        snackbar.style.opacity = "0";
        snackbar.style.transform = "translateY(20px)";
        setTimeout(() => snackbar.remove(), 250);
    }

    static style(type) {
        const bg = {
            success: "rgba(56, 142, 60, 0.92)",
            error: "rgba(211, 47, 47, 0.92)",
            warning: "rgba(255, 160, 0, 0.92)",
            info: "rgba(33, 150, 243, 0.92)",
            default: "rgba(40, 40, 40, 0.92)",
        }[type] || "rgba(40, 40, 40, .92)";

        return `
            padding: 14px 18px;
            color: white;
            font-size: 15px;
            border-radius: 4px;
            background: ${bg};
            backdrop-filter: blur(14px) saturate(180%);
            -webkit-backdrop-filter: blur(14px) saturate(180%);
            box-shadow: 0 4px 14px rgba(0,0,0,.25);

            opacity: 0;
            transform: translateY(20px);
            transition: opacity .25s ease, transform .25s ease;

            pointer-events: auto;
            cursor: pointer;

            max-width: 90%;
            text-align: center;
        `;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    window.Snackbar = SnackbarManager;
});