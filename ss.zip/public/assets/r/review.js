class ReviewModal {

    constructor({ modalId, modalBodyId, closeBtnId, reviewBtnSelector }) {
        this.reviewModal = document.getElementById(modalId);
        this.modalBody   = document.getElementById(modalBodyId);
        this.closeBtn    = document.getElementById(closeBtnId);
        this.reviewBtns  = document.querySelectorAll(reviewBtnSelector);
        this.requestLock = new Set()

        if (!this.reviewModal || !this.modalBody) return;
        this.init();
    }

    async init() {
        await window.Auth.ready;

        this.closeBtn?.addEventListener("click", () => this.close());

        this.reviewModal
            .querySelector(".review-modal-backdrop")
            ?.addEventListener("click", () => this.close());

        this.reviewBtns.forEach(btn => {
            btn.addEventListener("click", () => {
                const seriesId = btn.dataset.seriesId;
                if (seriesId) this.openWithSeries(seriesId);
            });
        });
    }

    isLocked(id) {
        return this.requestLock.has(id);
    }
    
    lock(id) {
        this.requestLock.add(id);
    }
    
    unlock(id) {
        this.requestLock.delete(id);
    }
    /* ---------- OPEN / CLOSE ---------- */

    open() {
        this.reviewModal.classList.remove("review-hiden");
        this.reviewModal.classList.add("show");
        document.body.classList.add("review-modal-open");
    }

    close() {
        this.reviewModal.classList.remove("show");
        document.body.classList.remove("review-modal-open");

        setTimeout(() => {
            this.reviewModal.classList.add("review-hiden");
            this.modalBody.innerHTML = "";
        }, 300);
    }

    /* ---------- LOAD DATA ---------- */

    async openWithSeries(seriesId) {
        try {
            const res = await fetch(`/api/p/review/${seriesId}`, {
                credentials: "include"
            });

            const json = await res.json();
            if (json.status !== 200) return;

            const reviews = Array.isArray(json.data) ? json.data : [];
            this.modalBody.innerHTML = "";

            this.renderReviewSection(seriesId, reviews);
            this.open();

        } catch (err) {
            window.Snackbar.show(err?.message ?? err);
        }
    }

    /* ---------- RENDER REVIEW ---------- */

    renderReviewSection(seriesId, reviews) {
        if (reviews.length === 0) {
            this.renderEmptyMessage(window.Auth.isAuthenticated);
            if (window.Auth.isAuthenticated) {
                this.renderReviewForm(seriesId, null);
            }
            return;
        }

        const userReview = reviews.find(r => r.is_user_review == 1) || null;
        const others     = reviews.filter(r => r.is_user_review == 0);

        if (window.Auth.isAuthenticated) {
            this.renderReviewForm(seriesId, userReview);
        }

        const list = document.createElement("div");
        list.className = "review-list-container";
        this.modalBody.appendChild(list);

        requestAnimationFrame(() => list.classList.add("show"));

        if (userReview) this.addReviewToList(userReview, list, true);
        others.forEach(r => this.addReviewToList(r, list));
    }

    /* ---------- EMPTY ---------- */

    renderEmptyMessage(loggedIn) {
        const msg = document.createElement("div");
        msg.id = "msg";
        msg.style = "padding:1rem;margin:auto;text-align:center;";
        msg.textContent = loggedIn
            ? "No reviews yet — be the first to write!"
            : "No reviews yet — be the first!";
        this.modalBody.appendChild(msg);
    }

    /* ---------- FORM ---------- */

    renderReviewForm(seriesId, existing) {
        const form = document.createElement("div");
        form.className = "review-form";

        form.innerHTML = `
            <h4>${existing ? "Edit Your Review" : "Your Review"}</h4>

            <div class="star-rating">
                ${[1,2,3,4,5].map(n =>
                    `<span data-value="${n}" class="svg no-line" data-icon="star"></span>`
                ).join("")}
            </div>

            <textarea class="review-comment"
                placeholder="Write your review...">${existing?.comment ?? ""}</textarea>

            <button class="submit-review base-btn btn-filled">
                <span class="btn-t">${existing ? "Update" : "Submit"}</span>
            </button>
        `;

        this.modalBody.prepend(form);
        requestAnimationFrame(() => form.classList.add("show"));

        const getRating = this.setupStars(form, existing?.rating || 0);
        this.setupSubmit(form, seriesId, getRating);
    }

    /* ---------- STAR ---------- */

    setupStars(form, initial) {
        const stars = form.querySelectorAll(".star-rating span");
        let rating = initial;

        const update = () => {
            stars.forEach(s =>
                s.classList.toggle("filled", +s.dataset.value <= rating)
            );
        };

        update();

        stars.forEach(star => {
            star.addEventListener("click", () => {
                rating = +star.dataset.value;
                update();
            });
        });

        return () => rating; // FIX: closure aman
    }

    /* ---------- SUBMIT ---------- */

    setupSubmit(form, seriesId, getRating) {
        const btn = form.querySelector(".submit-review");

        btn.addEventListener("click", async () => {
            const rating  = getRating();
            const comment = form.querySelector(".review-comment").value.trim();

            if (!rating)  return window.Snackbar.show("Select a rating");
            if (!comment) return window.Snackbar.show("Write a review");

            if (this.isLocked(seriesId)) return;
            this.lock(seriesId);

            try {
                const res = await window.Auth.authFetch("/api/a/review/toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ series_id: seriesId, rating, comment })
                });

                const json = await res.json();
                if (json.status !== 200)
                    return window.Snackbar.show(json.message);

                await this.refreshReviewList(seriesId);

            } catch (err) {
                window.Snackbar.show(err?.message ?? err);
            }  finally {
                setTimeout(() => this.unlock(seriesId), 3000);
            }
        });
    }

    /* ---------- LIST ---------- */

    async refreshReviewList(seriesId) {
        try {
            const res = await window.Auth.authFetch(`/api/p/review/${seriesId}`);
            const json = await res.json();
            if (json.status !== 200) return;

            const reviews = json.data || [];
            const user = reviews.find(r => r.is_user_review == 1);
            const others = reviews.filter(r => r.is_user_review == 0);

            this.modalBody.querySelector("#msg")?.remove();
            this.modalBody.querySelector(".review-list-container")?.remove();

            const list = document.createElement("div");
            list.className = "review-list-container";
            this.modalBody.appendChild(list);
            requestAnimationFrame(() => list.classList.add("show"));

            if (user) this.addReviewToList(user, list, true);
            others.forEach(r => this.addReviewToList(r, list));

        } catch (err) {
            window.Snackbar.show(err?.message ?? err);
        }
    }

    addReviewToList(r, container, isUser = false) {
        const div = document.createElement("div");
        div.className = `review-item${isUser ? " user-review" : ""}`;

        div.innerHTML = `
            <div class="review-user">
                <img src="${r.avatar_url}" class="review-avatar">
                <div>
                    <strong>${r.display_name || r.username}</strong>
                    <div class="review-rating">${this.renderStars(r.rating)}</div>
                </div>
            </div>
            <p>${r.comment}</p>
            <small class="time" data-datetime="${r.updated_at}Z"></small>
        `;

        isUser ? container.prepend(div) : container.appendChild(div);
        requestAnimationFrame(() => div.classList.add("show"));
    }

    renderStars(n) {
        return Array.from({ length: 5 }, (_, i) =>
            `<span class="svg no-line" data-icon="${i < n ? "star" : "star-outline"}"></span>`
        ).join("");
    }
}



/* ---------- USAGE ---------- */

document.addEventListener("DOMContentLoaded", () => {
        window.reviewModalInstance = new ReviewModal({
            modalId: "review-modal",
            modalBodyId: "review-modal-body",
            closeBtnId: "review-modal-close",
            reviewBtnSelector: ".review-btn"
        });

});