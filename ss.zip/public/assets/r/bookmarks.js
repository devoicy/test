class BookmarkList {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) return;

        this.cursor = null;         // pointer halaman berikutnya
        this.isLoading = false;     // mencegah double load
        this.hasMore = true;        // apakah masih ada data

        this.init();
    }

    async init() {
        await this.loadNextPage();
    }

    async loadNextPage() {
        if (this.isLoading || !this.hasMore) return;

        this.isLoading = true;
        try {
            const data = await this.fetchBookmarks(this.cursor);

            if (!Array.isArray(data.data) || data.data.length === 0) {
                if (!this.cursor) this.showEmpty();
                this.hasMore = false;
                return;
            }

            this.renderList(data.data);

            // Ubah cursor ke pointer berikutnya
            this.cursor = data.next ?? null;

            // Kalau next_cursor = null → sudah habis
            if (!this.cursor) this.hasMore = false;

        } catch (err) {
            this.showError(err);
        } finally {
            this.isLoading = false;
        }
    }

    async fetchBookmarks(cursor = null) {
        let url = "/api/a/bookmark";
        if (cursor) url += `?cursor=${cursor}`;

        const res = await Auth.authFetch(url);
        return res.json();
    }

    showEmpty() {
        this.container.innerHTML = `<p style="margin: auto; padding: 1rem;">No bookmarks found.</p>`;
    }

    showError(err) {
        console.error("Failed to load bookmarks:", err);
    }

    renderList(list) {
        list.forEach((ch, i) => {
            console.log(ch);
            const hasChapter = ch.chapter_id !== null;
            const chapterName = hasChapter ? ch.chapter_name : "";
            const chapterNumber = hasChapter ? ch.chapter_number : "";
            const series = ch.series_id;
            const chapter = ch.chapter_id;
            const slug = ch.series_slug || "#";

            const html = `
                <div class="ch_list ch-anim">
                    <a href="/title/${series}/${slug}">
                        <div class="ch_thumb">
                            <img class="lazyload" data-lazy-src="${ch.cover_url}" alt="${ch.series_name}">
                        </div>
                    </a>
                    <div class="ch_list_inf">
                        <div class="ch_ttl"><a href="/title/${series}/${slug}">${ch.series_name}</a></div>
                        <div class="ch_ds_name">Last read</div>
                        ${hasChapter ? `
                        <div class="ch_tt_l">
                            <div class="ch_tt_l2"><a href="/title/${series}/${slug}/chapter/${chapter}/${chapterNumber}">${chapterName} (${chapterName})</a></div>
                            <div class="ch_stt">
                                <div class="time" data-datetime="${ch.updated_at}Z"></div>
                            </div>
                        </div>` : ""}
                    </div>
                </div>
            `;

            this.container.insertAdjacentHTML("beforeend", html);

            const el = this.container.lastElementChild;
            setTimeout(() => el.classList.add("show"), i * 40);
        });

        this.setupObserver();
    }

    setupObserver() {
        // Pilih elemen terakhir
        const lastItem = this.container.lastElementChild;
        if (!lastItem) return;

        if (this.observer) this.observer.disconnect();

        this.observer = new IntersectionObserver(async (entries) => {
            if (entries[0].isIntersecting) {
                await this.loadNextPage();
            }
        });

        this.observer.observe(lastItem);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    new BookmarkList("bookmarks");
});
