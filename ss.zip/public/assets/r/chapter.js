class FABController {
  constructor() {
    // Elements
    this.fabContainer = document.getElementById('fabContainer');
    this.fabMain = document.getElementById('fabMain');
    this.fabMenus = document.querySelectorAll('.fab-menu');
    this.fabB = document.getElementById('fabB');
    this.fabMenuSub = document.getElementById('fabMenuSub');
    this.speedButtons = document.querySelectorAll('.fab-sub-menu .speed');
    this.fabFullscreen = document.getElementById('fabFullscreen');
    this.fabInfo = document.getElementById('fabInfo');

    // State
    this.autoScrollInterval = null;
    this.scrollSpeed = 1;
    this.isPlaying = false;
    this.fabHidden = false;
    this.lastClickTime = 0;
    this.lastScroll = window.scrollY;

    // Initialize
    this.initEvents();
  }

  // --- FAB Show/Hide ---
  showFAB() {
    this.fabContainer.classList.add('show');
    this.fabContainer.classList.remove('hidden');
  }

  hideFAB() {
    this.fabContainer.classList.add('hidden');
    this.fabContainer.classList.remove('show');
  }

  fabMenuAll(action) {
    this.fabMenus.forEach(menu => {
      if (action === 'show') menu.classList.add('show');
      else if (action === 'hide') menu.classList.remove('show');
      else if (action === 'toggle') menu.classList.toggle('show');
    });
  }

  // --- Auto Scroll ---
  startAutoScroll() {
    if (this.autoScrollInterval) clearInterval(this.autoScrollInterval);
    const intervalTime = 16;
    const scrollStep = this.scrollSpeed;
    this.autoScrollInterval = setInterval(() => {
      window.scrollBy(0, scrollStep);
      if ((window.innerHeight + window.scrollY) >= document.body.scrollHeight) this.stopAutoScroll();
    }, intervalTime);
    this.isPlaying = true;
  }

  stopAutoScroll() {
    if (this.autoScrollInterval) clearInterval(this.autoScrollInterval);
    this.autoScrollInterval = null;
    this.isPlaying = false;
  }

  // --- Report Chapter ---
  reportChapter(message) {
    fetch('https://report.tonjit.workers.dev/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: window.location.href, message: message })
    })
      .then(res => res.json())
      .then(data => {
        if (data.status === 'ok') {
          window.Snackbar.show('Report submitted! Thank you.');
        } else {
          window.Snackbar.show('Failed to submit report: ' + (data.message || 'Unknown error'));
        }
      })
      .catch(err => {
        console.error(err);
        window.Snackbar.show('Failed to submit report.');
      });
  }

  // --- Fullscreen Toggle ---
  toggleFullscreen() {
    const ffSpan = this.fabFullscreen.querySelector('span');
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        ffSpan.removeAttribute('data-icon-injected');
        ffSpan.setAttribute('data-icon', 'fullscreen-exit');
      });
    } else {
      document.exitFullscreen().then(() => {
        ffSpan.removeAttribute('data-icon-injected');
        ffSpan.setAttribute('data-icon', 'fullscreen');
      });
    }
  }

  // --- Open Report Modal ---
  openReportModal() {
    const sheet = document.querySelector('.sheet-content');
    sheet.innerHTML = `
      <div class="review-form show" style="max-width: 300px;margin: auto;">
        <h4 style="margin-bottom:1rem;">Report Chapter</h4>
        <textarea id="report-message" placeholder="Describe the issue..."></textarea>
        <button class="base-btn btn-filled" id="submit-review">
          <span class="btn-t" margin-top:1rem>Send</span>
        </button>
      </div>
    `;
    window.ModalSheet.openModal();

    const submitBtn = document.getElementById('submit-review');
    submitBtn.addEventListener('click', () => {
      const message = document.getElementById('report-message').value.trim();
      if (message) {
        this.reportChapter(message);
        window.ModalSheet.closeModal();
      } else {
        window.Snackbar.show('Please enter a message.');
      }
    });
  }

  // --- Event Listeners ---
  initEvents() {
    // Main FAB toggle
    this.fabMain.addEventListener('click', e => {
      e.stopPropagation();
      this.fabMenuAll('toggle');
    });

    // Auto Scroll toggle
    this.fabB.addEventListener('click', e => {
      e.stopPropagation();
      if (this.isPlaying) this.stopAutoScroll();
      else this.fabMenuSub.classList.toggle('show');
    });

    // Speed buttons
    this.speedButtons.forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        this.scrollSpeed = parseFloat(btn.textContent.replace('x', '')) || 1;
        this.fabMenuAll('hide');
        this.fabMenuSub.classList.remove('show');
        this.startAutoScroll();
      });
    });

    // Fullscreen
    this.fabFullscreen.addEventListener('click', e => {
      e.stopPropagation();
      this.toggleFullscreen();
    });

    // Info (Report Modal)
    this.fabInfo.addEventListener('click', e => {
      e.stopPropagation();
      this.openReportModal();
    });

    // Double click to hide/show FAB
    document.body.addEventListener('click', () => {
      const currentTime = new Date().getTime();
      if (currentTime - this.lastClickTime < 2500) { // double click
        if (this.isPlaying) this.stopAutoScroll();
        this.fabHidden = !this.fabHidden;
        this.fabHidden ? this.hideFAB() : this.showFAB();
        this.fabMenuAll('hide');
      }
      this.lastClickTime = currentTime;
    });

    // Auto hide on scroll
    window.addEventListener('scroll', () => {
      const currentScroll = window.scrollY;
      if (currentScroll > this.lastScroll) {
        this.hideFAB();
        this.fabHidden = true;
        this.fabMenuAll('hide');
      }
      this.lastScroll = currentScroll;
    });

    // Click outside closes menus
    document.addEventListener('click', () => {
      this.fabMenuAll('hide');
      this.fabMenuSub.classList.remove('show');
    });

    // Stop propagation on menu clicks
    this.fabMenus.forEach(menu => menu.addEventListener('click', e => e.stopPropagation()));
    this.fabMenuSub.addEventListener('click', e => e.stopPropagation());
    this.fabB.addEventListener('click', e => e.stopPropagation());
    this.fabFullscreen.addEventListener('click', e => e.stopPropagation());
    this.fabMain.addEventListener('click', e => e.stopPropagation());
    this.fabInfo.addEventListener('click', e => e.stopPropagation());
  }
}

// --- Initialize FAB Controller ---
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('fabMain')) {
    window.fabController = new FABController();
  } else {
    console.warn('FAB elements not found.');
  }
});

