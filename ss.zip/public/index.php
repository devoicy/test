<?php

define('APP_ENV', 'production');

require_once __DIR__ . '/../vendor/autoload.php';

use Swoole\Http\Server;
use Swoole\Http\Request;
use Swoole\Http\Response;
use Swoole\Runtime;
use Swoole\Table;
use Webtoon\Service\WorkerManager;
use Webtoon\Service\Router\Router;

Runtime::enableCoroutine(true);
// -----------------------------------------------------
// BOOTSTRAP MASTER PROCESS (Hanya dijalankan sekali)
// -----------------------------------------------------
require_once __DIR__ . '/../app/bootmaster.php';
require_once __DIR__ . '/../app/AppBootstrap.php';

// --------------------------------------------------
// BOOTSTRAP
// --------------------------------------------------
$bootstrap = new AppBootstrap();

// -----------------------------------------------------
// SWOOLE SERVER CONFIG
// -----------------------------------------------------

$server = new Swoole\Http\Server(
    "0.0.0.0",
    8022,
    SWOOLE_PROCESS
);

$server->set([
    'display_errors' => true,
    'enable_coroutine' => true,
    'worker_num'             => 2,
    'open_cpu_affinity'      => true,
    'max_request'            => 0,
    'open_tcp_nodelay'       => true,
    'tcp_fastopen'           => true,
    'log_level'              => SWOOLE_LOG_NONE,
    'log_file'               => __DIR__ .'/swoole.log',
    'send_yield'             => true,
    'enable_reuse_port'      => true,
    'http_compression'      => false,
    'buffer_output_size'     => 50 * 1024,
]);


$server->on("WorkerStart", function(Server $server, int $workerId) use ($bootstrap) {
    
    require __DIR__ . '/../app/bootworker.php';

    // 1. Get service definitions untuk worker ini
    $serviceDefinitions = $bootstrap->getServiceDefinitions($workerId);
    // 2. Create router dengan cache optimization
    $router = new Router(
        $serviceDefinitions,
         __DIR__ . '/../var/cache',
        [
            'environment' => 'development',
            'enable_container_compilation' => false,
            'enable_route_caching' => false,
        ]
    );
    
    // 3. Define semua routes (SEBELUM initialize!)
    $bootstrap->defineRoutes($router);
    
    // 4. Initialize router (LOCK routes)
    $router->initialize();
    
    // 5. Store router di server context
    $server->router = $router;
    
    // 6. Optional: Warm up services
    $bootstrap->warmupServices($router->getContainer());
    
    echo "✅ Router initialized for Worker #{$workerId}" . PHP_EOL;
    
    if ($router->getCacheFile()) {
        echo "📊 Route cache: " . basename($router->getCacheFile()) . PHP_EOL;
    }

    // Cuma Worker 0 yang jadi "Worker Administrasi"
    if ($workerId === 0) {
        $db = App::$container->get(\Database::class);
        $log = App::$container->get(\Webtoon\Service\Logger::class);
        $manager = new \Webtoon\Service\WorkerManager($db, $log);
        
        // GAS SEMUA TASK!
        $manager->startAllTasks();
        
        echo "[System] Background Tasks started on Worker 0\n";
    }

});


$server->on("request", function (Request $request, Response $response) use ($server) {


    // Router sudah di-initialize di workerStart
    if (isset($server->router) && $server->router instanceof Router) {
    $workerId = $server->worker_id;
    $request->get['xtoon_worker'] = $workerId;
    $path = $request->server['request_uri'] ?? '/';
    $method = $request->server['request_method'] ?? 'GET';
    $query  = $request->server['query_string']   ?? '';

    if (App::$isCacheEnabled && $method === 'GET') {

        $key = hash('crc32b', ($path . '?' . $query));

        switch (App::$cacheDriver) {

            case 'swoole':
                /** @var Swoole\Table $cacheTable */
                $cacheTable = App::$cacheTable;

                $data = $cacheTable->get($key);

                if ($data !== false && $data['expire_at'] > time()) {
                    // CACHE HIT
                    $response->header('Content-Type', $data['type']);
                    $response->header('X-Cache', 'HIT-SW');
                    $response->end($data['data']);
                    return;
                }
                break;

            case 'apcu':
                $success = false;
                $data = apcu_fetch($key, $success);

                if ($success) {
                    $response->header('Content-Type', $data['type']);
                    $response->header('X-Cache', 'HIT-AP');
                    $response->end($data['data']);
                    return;
                }
                break;
        }
    }

    if (str_starts_with($path, '/assets')) {

        $static = realpath(__DIR__ . $path);
        $dot = strrpos($static, '.');
        $ext = $dot !== false ? substr($static, $dot + 1) : '';

        if ($ext === 'php') goto router;

        if (!$static || !str_starts_with($static, realpath(__DIR__ . '/assets'))) {

            $response->status(403);
            $response->end('Forbidden');

            return;

        }

        switch ($ext) {
            case 'css':  $ct = 'text/css'; break;
            case 'js':   $ct = 'application/javascript'; break;
            case 'png':  $ct = 'image/png'; break;
            case 'jpg':
            case 'jpeg': $ct = 'image/jpeg'; break;
            case 'gif':  $ct = 'image/gif'; break;
            case 'html': $ct = 'text/html; charset=utf-8'; break;
            default:     $ct = 'application/octet-stream';
        }

        $response->header('Content-Type', $ct);
        $response->header('X-Cache', 'STATIC');

        if (!$response->sendfile($static)) {
            $response->status(404);
            $response->end('Not Found');
        }
        return;
    }

    // Router Dispatcher memanggil Controller yang sudah di-Autowired
    router:
    
    //App::$router->dispatch($request, $response);
    //$router->dispatch($request, $response);
    $server->router->handle($request, $response);
    } else {
        // Fallback jika router belum ready
        $response->status(503);
        $response->header('Content-Type', 'application/json');
        $response->end(json_encode([
            'error' => 'Service Unavailable',
            'message' => 'Worker is initializing'
        ]));
    }

    


});


$server->on('Task', function ($server, Swoole\Server\Task $task) {
    // ...
});

$server->on('Finish', function ($server, $task_id, $data) {
    // ...
});

$server->on('WorkerStop', function($server, $workerId) {
    // Graceful shutdown
    // Ambil instance dari container dan beresin sisa log
    $log = App::$container->get(\Webtoon\Service\Logger::class);
    $log->shutdown();
});

$server->start();