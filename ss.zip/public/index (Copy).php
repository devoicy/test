<?php
// index.php

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
require_once __DIR__ . '/../vendor/autoload.php';
use Swoole\Http\Server;
use Swoole\Http\Request;
use Swoole\Http\Response;
use Swoole\Runtime;
// Tambahkan use class yang dibutuhkan
//use App; 
//use Database;
//use Container;
use Swoole\Table;



// Simpan tabel ini agar dapat diakses oleh worker/router Anda
// (Asumsikan Anda menyimpannya dalam kontainer aplikasi)

Runtime::enableCoroutine(true);



$router = new \Router(); // Router diinisialisasi di Master Process

$server = new Swoole\Http\Server(
    "0.0.0.0",
    8022,
    SWOOLE_PROCESS
);

$server->set([
    // OPTIMALISASI LATENCY
    // Worker num disesuaikan dengan 2 core CPU Anda
    'worker_num'            => 2,
    'max_request'           => 10000, // Disarankan 10000 untuk mencegah potensi memory leak
    'open_tcp_nodelay'      => true,
    'tcp_fastopen'          => true,
    'log_level'             => SWOOLE_LOG_NONE, 
    // Pengaturan standar
    'send_yield'            => true,
    'enable_reuse_port'     => true,
    'buffer_output_size'    => 50 * 1024,
]);


$server->on("WorkerStart", function(Server $server, int $workerId) use ($router) {
$cacheTable = new Table(1024);
$cacheTable->column('data', Table::TYPE_STRING, 65535);
$cacheTable->column('expire_at', Table::TYPE_INT);
$cacheTable->create();
App::$cacheTable = $cacheTable;
    App::$container = new Container();

    // ==========================================================
    // UPGRADE: Menerapkan Lazy Loading untuk Database
    // ==========================================================
    // Database Pool tidak akan dibuat saat WorkerStart, 
    // melainkan saat pertama kali dipanggil di route handler.
    
    App::$container->set(Database::class, function (Container $c) use ($workerId) {
        // Factory ini hanya dieksekusi sekali di worker ketika Database dipanggil
        echo "Database Pool diinisialisasi (Lazy Load) oleh Worker #{$workerId}\n"; 
        return new Database(20);
    });

    // ==========================================================
    // DEFINISI ROUTE HARUS DILAKUKAN DI SINI
    // ==========================================================
    
$router->get('/', function(Request $request, Response $response) {
    
    // Kunci cache dan TTL (Time-To-Live)
    $key = 'test';
    $ttl = 300; // 5 menit
    
    // Ambil Swoole Table dari kontainer (asumsi dari langkah 1)
    /** @var \Swoole\Table $cacheTable */
    $cacheTable = App::$cacheTable;
    
    $users = null;

    // --- LOGIKA CACHE FETCH ---
    $cachedItem = $cacheTable->get($key);

    if ($cachedItem) {
        $currentTime = time();
        
        // Cek apakah data masih valid (belum melewati waktu kedaluwarsa)
        if ($currentTime < $cachedItem['expire_at']) {
            // Cache valid! Lakukan de-serialisasi untuk mendapatkan kembali array asli
            $users = unserialize($cachedItem['data']);
        } else {
            // Cache sudah kadaluarsa, hapus entri dari tabel
            $cacheTable->del($key);
        }
    }

    // Jika $users sudah terisi (berhasil dari cache), lewati DB
    if ($users !== null) {
        goto cache;
    }
    // --- AKHIR LOGIKA CACHE FETCH ---
    
    // Panggilan 'get' yang PERTAMA di sini (hanya terjadi saat cache miss)
    /** @var Database $db */
    $db = App::$container->get(Database::class);

    $pdo = $db->getConnection(); 
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM series_summary LIMIT 1");
        $stmt->execute();
        $users = $stmt->fetchAll();
        
        // --- LOGIKA CACHE STORE (KE SWOOLE TABLE) ---
        // Simpan hasil query (setelah diserialisasi) beserta waktu kedaluwarsa
        $cacheTable->set($key, [
            'data' => serialize($users),
            'expire_at' => time() + $ttl,
        ]);
        // --- AKHIR LOGIKA CACHE STORE ---
        
    } catch (\Throwable $e) {
        // ...
    } finally {
        $db->releaseConnection($pdo); 
    }

    cache:
    $response->header('Content-Type', 'application/json');
    $response->end(json_encode($users));
});

});


$server->on("request", function (Request $request, Response $response) use ($router) {
    // Dipanggil di setiap request, router menggunakan definisi dari WorkerStart
    $router->dispatch($request, $response);
});


$server->on('Task', function ($server, Swoole\Server\Task $task) {
    // Jika Anda ingin implementasi Task, lakukan di sini
});

$server->on('Finish', function ($server, $task_id, $data) {
    // Jika Anda ingin implementasi Finish, lakukan di sini
});

$server->start();