<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* Admin/series_list.twig.html */
class __TwigTemplate_dbadb8f3d4a94417c848bd803f57e8d6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "Admin/base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("Admin/base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        yield "<div class=\"container py-4\">
    <div class=\"d-flex justify-content-between align-items-center mb-3\">
        <h2 class=\"h4 mb-0 fw-bold\">Series Management</h2>
        <a href=\"/admin/series/add\" class=\"btn btn-success btn-sm d-flex align-items-center gap-1\">
            <i class=\"bi bi-plus-lg\"></i> Add New Series
        </a>
    </div>

    ";
        // line 11
        if ((($tmp = ($context["series"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 12
            yield "    <div class=\"card border-0 shadow-sm\">
        <div class=\"table-responsive\">
            <table class=\"table table-hover align-middle mb-0\">
                <thead class=\"table-light\">
                    <tr>
                        <th class=\"ps-3\" style=\"width: 80px;\">ID</th>
                        <th>Series Name</th>
                        <th>Created At</th>
                        <th class=\"text-center\">Status</th>
                        <th class=\"text-end pe-3\">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["series"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["s"]) {
                // line 26
                yield "                    <tr>
                        <td class=\"ps-3 text-muted\">#";
                // line 27
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 27), "html", null, true);
                yield "</td>
                        <td>
                            <div class=\"fw-bold text-truncate\" style=\"max-width: 250px;\">
                                <a href=\"/title/";
                // line 30
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 30), "html", null, true);
                yield "/";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "slug", [], "any", false, false, false, 30), "html", null, true);
                yield "\" 
                                   target=\"_blank\" 
                                   class=\"text-decoration-none text-primary\"
                                   title=\"";
                // line 33
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "name", [], "any", false, false, false, 33));
                yield "\">
                                    ";
                // line 34
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "name", [], "any", false, false, false, 34));
                yield "
                                </a>
                            </div>
                        </td>
                        <td class=\"text-muted small\">
                            ";
                // line 39
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "created_at", [], "any", false, false, false, 39), "d M Y"), "html", null, true);
                yield "
                        </td>
                        <td class=\"text-center\">
                            ";
                // line 42
                if ((CoreExtension::getAttribute($this->env, $this->source, $context["s"], "is_published", [], "any", false, false, false, 42) == 1)) {
                    // line 43
                    yield "                                <span class=\"badge rounded-pill bg-success-subtle text-success border border-success-subtle\">Published</span>
                            ";
                } else {
                    // line 45
                    yield "                                <span class=\"badge rounded-pill bg-warning-subtle text-warning border border-warning-subtle\">Draft</span>
                            ";
                }
                // line 47
                yield "                        </td>
                        <td class=\"text-end pe-3\">
                            <div class=\"btn-group btn-group-sm\">
                                <a href=\"/admin/series/";
                // line 50
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 50), "html", null, true);
                yield "/edit\" class=\"btn btn-outline-primary\">
                                    Edit
                                </a>
                                <a href=\"/admin/series/";
                // line 53
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["s"], "id", [], "any", false, false, false, 53), "html", null, true);
                yield "/chapter/add\" class=\"btn btn-outline-secondary\">
                                    + Chapter
                                </a>
                            </div>
                        </td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['s'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 60
            yield "                </tbody>
            </table>
        </div>
    </div>

    ";
            // line 65
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["next"] ?? null), "id", [], "any", false, false, false, 65)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 66
                yield "    <div class=\"text-center mt-4\">
        <a href=\"/admin?i=";
                // line 67
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["next"] ?? null), "id", [], "any", false, false, false, 67), "html", null, true);
                yield "\" class=\"btn btn-outline-info btn-sm px-4 rounded-pill\">
            Load More Content
        </a>
    </div>
    ";
            }
            // line 72
            yield "
    ";
        } else {
            // line 74
            yield "    <div class=\"text-center py-5 bg-white rounded-3 border\">
        <p class=\"text-muted\">No series found.</p>
        <a href=\"/admin/series/add\" class=\"btn btn-primary btn-sm\">Create your first series</a>
    </div>
    ";
        }
        // line 79
        yield "</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "Admin/series_list.twig.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  189 => 79,  182 => 74,  178 => 72,  170 => 67,  167 => 66,  165 => 65,  158 => 60,  145 => 53,  139 => 50,  134 => 47,  130 => 45,  126 => 43,  124 => 42,  118 => 39,  110 => 34,  106 => 33,  98 => 30,  92 => 27,  89 => 26,  85 => 25,  70 => 12,  68 => 11,  58 => 3,  51 => 2,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "Admin/series_list.twig.html", "/home/lana/Documents/last/views/Admin/series_list.twig.html");
    }
}
