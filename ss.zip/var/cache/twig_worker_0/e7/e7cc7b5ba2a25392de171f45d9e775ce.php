<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* Admin/chapter_edit.html */
class __TwigTemplate_a284d063428dd39ddb1ef87fe430a55b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "Admin/base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("Admin/base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"container py-5\">
    <div class=\"row justify-content-center\">
        <div class=\"col-lg-8\">
            <div class=\"card shadow-sm border-0 rounded-3\">
                <div class=\"card-body p-4\">
                    <form action=\"\" method=\"post\" id=\"chapterForm\">
                        <div class=\"d-flex align-items-center justify-content-between mb-4 border-bottom pb-3\">
                            <h3 class=\"fw-bold text-primary mb-0\">Edit Chapter</h3>
                            <span class=\"badge bg-info-subtle text-info px-3 py-2\">Series ID: ";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "series_id", [], "any", false, false, false, 12), "html", null, true);
        yield "</span>
                        </div>

                        <div class=\"row g-3\">
                            <div class=\"col-md-8\">
                                <label class=\"form-label fw-bold\">Cover URL</label>
                                <input type=\"url\" name=\"cover_url\" class=\"form-control\" 
                                       placeholder=\"https://example.com/image.jpg\" value=\"";
        // line 19
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["chapter"] ?? null), "cover_url", [], "any", false, false, false, 19), "html", null, true);
        yield "\" required>
                            </div>

                            <div class=\"col-md-4\">
                                <label class=\"form-label fw-bold\">Chapter Number</label>
                                <input type=\"number\" name=\"number\" step=\"0.1\" min=\"0\" class=\"form-control\" 
                                       placeholder=\"e.g. 1.5\" value=\"";
        // line 25
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["chapter"] ?? null), "number", [], "any", false, false, false, 25), "html", null, true);
        yield "\" required>
                            </div>

                            <div class=\"col-12\">
                                <label class=\"form-label fw-bold\">Chapter Title / Name</label>
                                <input type=\"text\" name=\"name\" class=\"form-control\" 
                                       placeholder=\"Judul Chapter (opsional)\" value=\"";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["chapter"] ?? null), "name", [], "any", false, false, false, 31), "html", null, true);
        yield "\"required>
                            </div>

                            <div class=\"col-12\">
                                <div class=\"d-flex justify-content-between align-items-center mb-2\">
                                    <label class=\"form-label fw-bold mb-0\">Raw JSON Content (Array of URLs)</label>
                                    <button type=\"button\" class=\"btn btn-sm btn-outline-secondary\" onclick=\"formatJSON()\">
                                        <i class=\"bi bi-braces\"></i> Format JSON
                                    </button>
                                </div>
                                <textarea name=\"content\" id=\"jsonInput\" class=\"form-control text-monospace\" rows=\"12\" 
                                          style=\"font-family: 'Courier New', monospace; font-size: 13px;\" 
                                          required placeholder='[\"https://image1.jpg\", \"https://image2.jpg\"]'>";
        // line 43
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["chapter"] ?? null), "content", [], "any", false, false, false, 43), "html", null, true);
        yield "</textarea>
                                <div id=\"jsonFeedback\" class=\"invalid-feedback\">Format JSON tidak valid!</div>
                            </div>

                            <div class=\"col-12 mt-4 pt-3 border-top d-flex gap-2\">
                                <button name=\"is_published\" value=\"1\" type=\"submit\" class=\"btn btn-primary px-4 py-2 fw-bold\">
                                    Publish Chapter
                                </button>
                                <button name=\"is_published\" value=\"0\" type=\"submit\" class=\"btn btn-outline-secondary px-4 py-2\">
                                    Save as Draft
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    /**
     * Fungsi untuk mempercantik tampilan JSON di textarea
     */
    function formatJSON() {
        const area = document.getElementById('jsonInput');
        try {
            const obj = JSON.parse(area.value);
            area.value = JSON.stringify(obj, null, 4); // Indentasi 4 spasi
            area.classList.remove('is-invalid');
            area.classList.add('is-valid');
        } catch (e) {
            area.classList.add('is-invalid');
            alert(\"JSON tidak valid, tidak bisa diformat.\");
        }
    }

    /**
     * Validasi sebelum submit
     */
    document.getElementById('chapterForm').addEventListener('submit', function(e) {
        const area = document.getElementById('jsonInput');
        try {
            JSON.parse(area.value);
        } catch (err) {
            e.preventDefault();
            area.classList.add('is-invalid');
            document.getElementById('jsonFeedback').style.display = 'block';
            alert(\"Mohon perbaiki format JSON sebelum mengirim.\");
        }
    });
</script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "Admin/chapter_edit.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  111 => 43,  96 => 31,  87 => 25,  78 => 19,  68 => 12,  58 => 4,  51 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "Admin/chapter_edit.html", "/home/lana/Documents/last/views/Admin/chapter_edit.html");
    }
}
