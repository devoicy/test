<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* pagination.html */
class __TwigTemplate_7597523afa136a09216e122a8c431641 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        if ((($context["total_pages"] ?? null) > 1)) {
            // line 2
            yield "<div class=\"fwr pt-1\" style=\"margin-bottom: 2rem;\">
\t<div class=\"fwr gp05\" style=\"display: flex;flex-wrap: wrap;gap: 6px;justify-content: center;align-items: center;\">
\t<!-- Tombol Prev -->
    ";
            // line 5
            if ((($context["page"] ?? null) > 1)) {
                // line 6
                yield "    \t<a class=\"base-btn btn-filled\" href=\"?page=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($context["page"] ?? null) - 1), "html", null, true);
                yield "\"><span class=\"icon-btn svg\" data-icon=\"chevron-left\"></span><span class=\"btn-t\">Prev</span></a>
    ";
            } else {
                // line 8
                yield "    \t<div class=\"base-btn btn-filled-disabled\"><span class=\"icon-btn svg\" data-icon=\"chevron-left\"></span><span class=\"btn-t\">Prev</span></div>
    ";
            }
            // line 10
            yield "    <!-- Nomor halaman -->
    ";
            // line 11
            $context["start"] = max(1, (($context["page"] ?? null) - 2));
            // line 12
            yield "    ";
            $context["end"] = min(($context["total_pages"] ?? null), (($context["page"] ?? null) + 2));
            // line 13
            yield "    ";
            if ((($context["start"] ?? null) > 1)) {
                // line 14
                yield "    \t<a class=\"base-btn btn-filled\" href=\"?page=1\"><span class=\"btn-t\">1</span></a>
\t\t";
                // line 15
                if ((($context["start"] ?? null) > 2)) {
                    yield "<div class=\"base-btn btn-filled-disabled\"><span class=\"btn-t\">...</span></div>";
                }
                // line 16
                yield "    ";
            }
            // line 17
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(range(($context["start"] ?? null), ($context["end"] ?? null)));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 18
                yield "\t\t";
                if (($context["i"] == ($context["page"] ?? null))) {
                    // line 19
                    yield "\t\t\t<div class=\"base-btn btn-filled-disabled\"><span class=\"btn-t\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["i"], "html", null, true);
                    yield "</span></div>
\t\t";
                } else {
                    // line 21
                    yield "\t\t\t<a class=\"base-btn btn-filled\" href=\"?page=";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["i"], "html", null, true);
                    yield "\"><span class=\"btn-t\">";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["i"], "html", null, true);
                    yield "</span></a>
\t\t";
                }
                // line 23
                yield "\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['i'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            yield "
\t";
            // line 25
            if ((($context["end"] ?? null) < ($context["total_pages"] ?? null))) {
                // line 26
                yield "\t\t";
                if ((($context["end"] ?? null) < (($context["total_pages"] ?? null) - 1))) {
                    yield "<div class=\"base-btn btn-filled-disabled\"><span class=\"btn-t\">...</span></div>";
                }
                // line 27
                yield "\t\t<a class=\"base-btn btn-filled\" href=\"?page=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total_pages"] ?? null), "html", null, true);
                yield "\"><span class=\"btn-t\">";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total_pages"] ?? null), "html", null, true);
                yield "</span></a>
    ";
            }
            // line 29
            yield "    <!-- Tombol Next -->
    ";
            // line 30
            if ((($context["page"] ?? null) < ($context["total_pages"] ?? null))) {
                // line 31
                yield "\t    <a class=\"base-btn btn-filled\" href=\"?page=";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($context["page"] ?? null) + 1), "html", null, true);
                yield "\"><span class=\"btn-t\">Next</span><span class=\"icon-btn svg\" data-icon=\"chevron-right\"></span></a>
    ";
            } else {
                // line 33
                yield "    \t<div class=\"base-btn btn-filled-disabled\"><span class=\"btn-t\">Next</span><span class=\"icon-btn svg\" data-icon=\"chevron-right\"></span></div>
    ";
            }
            // line 35
            yield "\t</div>
</div>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "pagination.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  143 => 35,  139 => 33,  133 => 31,  131 => 30,  128 => 29,  120 => 27,  115 => 26,  113 => 25,  110 => 24,  104 => 23,  96 => 21,  90 => 19,  87 => 18,  82 => 17,  79 => 16,  75 => 15,  72 => 14,  69 => 13,  66 => 12,  64 => 11,  61 => 10,  57 => 8,  51 => 6,  49 => 5,  44 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "pagination.html", "/home/lana/Documents/last/views/pagination.html");
    }
}
