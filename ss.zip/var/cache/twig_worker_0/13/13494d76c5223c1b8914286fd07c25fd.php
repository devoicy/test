<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* base.html */
class __TwigTemplate_396cacdbbdb755b96587b34989783c89 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  ";
        // line 6
        yield from $this->unwrap()->yieldBlock('head', $context, $blocks);
        // line 7
        yield "  <script src=\"/assets/r/jwt.js\"></script>
  <script src=\"/assets/r/time.js\"></script>
  <script src=\"/assets/r/link.js\"></script>
  <script src=\"/assets/r/fav.js\"></script>
  <script src=\"/assets/r/signup.js\"></script>
  <script src=\"/assets/r/snackbar.js\"></script>
  <script src=\"/assets/r/togglehide.js\"></script>
  <script src=\"/assets/r/chapterlists.js\"></script>
  <script src=\"/assets/r/lazy.js\"></script>
  <script src=\"/assets/r/drawer.js\"></script>
  <script src=\"/assets/r/review.js\"></script>
  <script src=\"/assets/r/bookmarks.js\"></script>
  <script src=\"/assets/r/related.js\"></script>
  <script src=\"/assets/r/chapter.js\"></script>
  <script src=\"/assets/r/populer.js\"></script>
  <script src=\"/assets/r/msgpack.js\"></script>
  <script src=\"/assets/r/search.js\"></script>
  <script src=\"/assets/r/icon.js\"></script>

  <link rel=\"stylesheet\" type=\"text/css\" href=\"/assets/css/input.css\">
  <!--script>const csrf = \"";
        // line 27
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["csrf_token"] ?? null), "html", null, true);
        yield "\";</script-->
  <!--script src=\"/assets/js.bundle.js\"></script-->
  <link rel=\"stylesheet\" type=\"text/css\" href=\"/assets/styles.css\">

</head>
<body>
";
        // line 33
        yield from $this->load("drawer.html", 33)->unwrap()->yield($context);
        // line 34
        yield "
<main>";
        // line 35
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        yield "</main>

";
        // line 37
        yield from $this->load("modal.html", 37)->unwrap()->yield($context);
        // line 38
        yield from $this->load("footer.html", 38)->unwrap()->yield($context);
        // line 39
        yield "</body>
</html>";
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "base.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  114 => 35,  104 => 6,  98 => 39,  96 => 38,  94 => 37,  89 => 35,  86 => 34,  84 => 33,  75 => 27,  53 => 7,  51 => 6,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "base.html", "/home/lana/Documents/last/views/base.html");
    }
}
