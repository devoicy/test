<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* series.html */
class __TwigTemplate_3a8c53588f303445d9b39399ab77126f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        yield "<title>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "title", [], "any", false, false, false, 3), "html", null, true);
        yield "</title>
<link rel=\"canonical\" href=\"";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta name=\"description\" content=\"";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "description", [], "any", false, false, false, 5), "html", null, true);
        yield "\">
<meta name=\"keywords\" content=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "keywords", [], "any", false, false, false, 6), "html", null, true);
        yield "\">
<meta property=\"og:title\" content=\"";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "title", [], "any", false, false, false, 7), "html", null, true);
        yield "\">
<meta property=\"og:description\" content=\"";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "description", [], "any", false, false, false, 8), "html", null, true);
        yield "\">
<meta property=\"og:image\" content=\"";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "cover", [], "any", false, false, false, 9), "html", null, true);
        yield "\">
<meta property=\"og:type\" content=\"website\">
<meta property=\"og:url\" content=\"";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta name=\"twitter:card\" content=\"summary_large_image\">
<meta name=\"twitter:title\" content=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "title", [], "any", false, false, false, 13), "html", null, true);
        yield "\">
<meta name=\"twitter:description\" content=\"";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "description", [], "any", false, false, false, 14), "html", null, true);
        yield "\">
<meta name=\"twitter:image\" content=\"";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "cover", [], "any", false, false, false, 15), "html", null, true);
        yield "\">
<script type=\"application/ld+json\">
";
        // line 17
        yield CoreExtension::getAttribute($this->env, $this->source, ($context["meta"] ?? null), "jsonld", [], "any", false, false, false, 17);
        yield "
</script>
";
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 22
        yield "

<div class=\"lz max-w-1212\">
  <div class=\"infs\">
    <nav class=\"breadcrumb\" aria-label=\"Breadcrumb\">
      <ol>
        <li><a href=\"/\">Home</a></li>
        <li><a href=\"/title\">Series</a></li>
        <li aria-current=\"page\">";
        // line 30
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["name"] ?? null), "html", null, true);
        yield "</li>
      </ol>
    </nav>
  </div>
  <div class=\"lzCntnr\">
    <div class=\"celx5\">
      <div class=\"ccv ccvx\">
        <button class=\"ccvb\">
          <img data-lazy-src=\"";
        // line 38
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["cover_url"] ?? null), "html", null, true);
        yield "\" src=\"data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==\" alt=\"name\" class=\"lazyload\">
        </button>
      </div>
      <div class=\"ced\">
        <div class=\"cedwf\">
          <h2 class=\"eldti\" style=\"color: #fff\">";
        // line 43
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["name"] ?? null), "html", null, true);
        yield "</h2>
          <div class=\"flex items-center\"><span style=\"color: grey;\">";
        // line 44
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rating_average"] ?? null), "html", null, true);
        yield " / 5 (";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rating_count"] ?? null), "html", null, true);
        yield " ratings)</span></div>
          <div class=\"hide-wrapper\">
          <div class=\"hide\">
            <div class=\"eenty\"> ";
        // line 47
        if ((($tmp = ($context["entities"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["entities"] ?? null));
            foreach ($context['_seq'] as $context["key"] => $context["entity"]) {
                yield " ";
                if ((($tmp = $context["entity"]) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield " <div class=\"celdm\">
                <span class=\"cddag\">";
                    // line 48
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), $context["key"]), "html", null, true);
                    yield "</span> ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable($context["entity"]);
                    foreach ($context['_seq'] as $context["_key"] => $context["g"]) {
                        yield " <span><a class=\"cdal\" href=\"/";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
                        yield "/";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["g"], "id", [], "any", false, false, false, 48), "html", null, true);
                        yield "/";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["g"], "slug", [], "any", false, false, false, 48), "html", null, true);
                        yield "\">";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["g"], "title", [], "any", false, false, false, 48), "html", null, true);
                        yield "</a></span> ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['g'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 49
                    yield "              </div>
              <div class=\"cdlah\"></div> ";
                }
                // line 50
                yield " ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['key'], $context['entity'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            yield " ";
        }
        // line 51
        yield "            </div>

            <div class=\"description\">
              <p style=\"color: #fff\">";
        // line 54
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["description"] ?? null), "html", null, true);
        yield "</p>
            </div>
          </div><button class=\"toggle-hide-btn\">Show More</button>
          </div>


            <div class=\"cest\">
              <div class=\"flex\">
                <button class=\"review-btn icon-btn svg no-line reset\" data-series-id=\"";
        // line 62
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["series_id"] ?? null), "html", null, true);
        yield "\" data-icon=\"star-outline\"></button>
                <button class=\"bookmark-btn icon-btn svg no-line reset\" data-series-id=\"";
        // line 63
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["series_id"] ?? null), "html", null, true);
        yield "\" data-icon=\"bookmark-plus\"></button>
              </div>
            </div>
        </div>
          
        
        <div class=\"ch_e_ll\">

        </div>
      </div>
    </div>
  </div>
</div>


<script>

</script>

<div id=\"review-modal\" class=\"review-modal review-hiden\">
    <div class=\"review-modal-backdrop\"></div>
    <div class=\"review-modal-panel\">
        <!-- Header -->
        <div class=\"review-modal-header\">
            <button id=\"review-modal-close\" class=\"icon-btn svg no-line\" data-icon=\"close\">
            </button>
            <span class=\"title btn-t-l\" style=\"margin-left: 12px;\">Reviews</span>
        </div>

        <!-- Body -->
        <div class=\"review-modal-body\" id=\"review-modal-body\">
            <!-- Review form & review list akan diinject di sini -->
        </div>
    </div>
</div>



<div class=\"lz max-w-1212\">
  <div class=\"lzCntnr\">
    <div class=\"episodeLowerList__eyi2a\">
      <div class=\"infs\">
        <div style=\"text-align: end;\">
          <button id=\"btnSort\" class=\"base-btn\">
            <span class=\"svg no-line\" data-icon=\"sort-ascending\"></span>
            <span style=\"padding-left: 1rem;\">Sort by Order</span>
          </button>
        </div>
      </div>
      <div class=\"episodeListContents__qDvQv\" id=\"chapters\" data-series-id=\"";
        // line 112
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["series_id"] ?? null), "html", null, true);
        yield "\">
      </div>
    </div>
  </div>
</div>
<!-- related -->
<div class=\"lz max-w-1212\" style=\"padding-bottom: 5rem;\">
  <div class=\"infs\"><h2>You may also like</h2></div>
  <div id=\"related\" class=\"lzCardList\" data-series-id=\"";
        // line 120
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["series_id"] ?? null), "html", null, true);
        yield "\"></div>
</div>

";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "series.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  287 => 120,  276 => 112,  224 => 63,  220 => 62,  209 => 54,  204 => 51,  196 => 50,  192 => 49,  173 => 48,  163 => 47,  155 => 44,  151 => 43,  143 => 38,  132 => 30,  122 => 22,  115 => 21,  107 => 17,  102 => 15,  98 => 14,  94 => 13,  89 => 11,  84 => 9,  80 => 8,  76 => 7,  72 => 6,  68 => 5,  64 => 4,  59 => 3,  52 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "series.html", "/home/lana/Documents/last/views/series.html");
    }
}
