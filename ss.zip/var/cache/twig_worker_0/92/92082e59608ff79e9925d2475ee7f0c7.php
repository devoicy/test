<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* Admin/chapter_list.html */
class __TwigTemplate_c953fa51db7251c6f4c15805fa938bd5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "Admin/base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("Admin/base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"container py-4\">
    <nav aria-label=\"breadcrumb\">
        <ol class=\"breadcrumb mb-2\">
            <li class=\"breadcrumb-item\"><a href=\"/admin/series\" class=\"text-decoration-none\">Series</a></li>
            <li class=\"breadcrumb-item active\">Chapters List</li>
        </ol>
    </nav>

    <div class=\"d-flex justify-content-between align-items-center mb-4\">
        <div>
            <h2 class=\"h4 mb-0 fw-bold\">Manage Chapters</h2>
            <p class=\"text-muted small mb-0\">Series ID: #";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
        yield "</p>
        </div>
        <a href=\"/admin/series/";
        // line 17
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
        yield "/chapter/add\" class=\"btn btn-success btn-sm d-flex align-items-center gap-1\">
            <i class=\"bi bi-plus-lg\"></i> Add New Chapter
        </a>
    </div>

    ";
        // line 22
        if ((($tmp = ($context["data"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 23
            yield "    <div class=\"card border-0 shadow-sm\">
        <div class=\"table-responsive\">
            <table class=\"table table-hover align-middle mb-0\">
                <thead class=\"table-light\">
                    <tr>
                        <th class=\"ps-3\" style=\"width: 80px;\">ID</th>
                        <th>Chapter Info</th>
                        <th class=\"text-center\">Number</th>
                        <th class=\"text-center\">Views</th>
                        <th class=\"text-center\">Status</th>
                        <th class=\"text-end pe-3\">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["chapter"]) {
                // line 38
                yield "                    <tr>
                        <td class=\"ps-3 text-muted\">#";
                // line 39
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "chapter_id", [], "any", false, false, false, 39), "html", null, true);
                yield "</td>
                        <td>
                            <div class=\"fw-bold text-dark\">
                                ";
                // line 42
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "name", [], "any", true, true, false, 42)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "name", [], "any", false, false, false, 42), "No Title")) : ("No Title")));
                yield "
                            </div>
                            <div class=\"text-muted extra-small\" style=\"font-size: 0.75rem;\">
                                Created: ";
                // line 45
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "created_at", [], "any", false, false, false, 45), "d M Y"), "html", null, true);
                yield "
                            </div>
                        </td>
                        <td class=\"text-center\">
                            <span class=\"badge bg-light text-dark border fw-medium\">
                                Ch. ";
                // line 50
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "number", [], "any", false, false, false, 50), "html", null, true);
                yield "
                            </span>
                        </td>
                        <td class=\"text-center\">
                            <small class=\"text-muted\"><i class=\"bi bi-eye\"></i> ";
                // line 54
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber(CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "views", [], "any", false, false, false, 54), 0, ",", "."), "html", null, true);
                yield "</small>
                        </td>
                        <td class=\"text-center\">
                            ";
                // line 57
                if ((CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "is_published", [], "any", false, false, false, 57) == 1)) {
                    // line 58
                    yield "                                <span class=\"badge rounded-pill bg-success-subtle text-success border border-success-subtle px-3\">Published</span>
                            ";
                } else {
                    // line 60
                    yield "                                <span class=\"badge rounded-pill bg-warning-subtle text-warning border border-warning-subtle px-3\">Draft</span>
                            ";
                }
                // line 62
                yield "                        </td>
                        <td class=\"text-end pe-3\">
                            <a href=\"/admin/series/";
                // line 64
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
                yield "/chapter/edit/";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["chapter"], "chapter_id", [], "any", false, false, false, 64), "html", null, true);
                yield "\" 
                               class=\"btn btn-sm btn-outline-primary px-3\">
                                <i class=\"bi bi-pencil-square\"></i> Edit
                            </a>
                        </td>
                    </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['chapter'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 71
            yield "                </tbody>
            </table>
        </div>
    </div>
    ";
        } else {
            // line 76
            yield "    <div class=\"card border-0 shadow-sm py-5 text-center\">
        <div class=\"card-body\">
            <i class=\"bi bi-journal-x display-4 text-muted mb-3 d-block\"></i>
            <h5 class=\"text-muted\">Belum ada chapter...</h5>
            <p class=\"small text-secondary mb-4\">Mulai tambahkan chapter pertama untuk series ini.</p>
            <a href=\"/admin/series/";
            // line 81
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "/chapter/add\" class=\"btn btn-primary btn-sm px-4\">
                Add Chapter Now
            </a>
        </div>
    </div>
    ";
        }
        // line 87
        yield "</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "Admin/chapter_list.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  194 => 87,  185 => 81,  178 => 76,  171 => 71,  156 => 64,  152 => 62,  148 => 60,  144 => 58,  142 => 57,  136 => 54,  129 => 50,  121 => 45,  115 => 42,  109 => 39,  106 => 38,  102 => 37,  86 => 23,  84 => 22,  76 => 17,  71 => 15,  58 => 4,  51 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "Admin/chapter_list.html", "/home/lana/Documents/last/views/Admin/chapter_list.html");
    }
}
