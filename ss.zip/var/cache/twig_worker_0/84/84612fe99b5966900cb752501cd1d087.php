<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* Admin/series_create.twig */
class __TwigTemplate_7c55afa5265c6e49a75879fd7f06142f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "Admin/base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("Admin/base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        yield "
<div class=\"container py-5\">
    <div class=\"row justify-content-center\">
        <div class=\"col-lg-10\">
            <div class=\"card p-4\">
                <form method=\"POST\">
                    <h3 class=\"section-title text-primary\">Series Information</h3>
                    
                    <div class=\"row g-3\">
                        <div class=\"col-md-6\">
                            <label class=\"form-label\">Title / Name</label>
                            <input type=\"text\" name=\"name\" class=\"form-control\" placeholder=\"Series title\" required>
                        </div>

                        <div class=\"col-md-6\">
                            <label class=\"form-label\">Cover Image URL</label>
                            <input type=\"url\" name=\"cover_url\" class=\"form-control\" placeholder=\"https://example.com/image.jpg\">
                        </div>

                        <div class=\"col-12\">
                            <label class=\"form-label\">Description</label>
                            <textarea name=\"description\" class=\"form-control\" rows=\"2\" placeholder=\"Brief synopsis...\"></textarea>
                        </div>

                        <h3 class=\"section-title text-primary mt-5\">Taxonomy & Metadata</h3>

                        ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entities"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 30
            yield "                            <div class=\"col-md-6\">
                                <label class=\"form-label\">";
            // line 31
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), Twig\Extension\CoreExtension::replace($context["type"], ["-" => " "])), "html", null, true);
            yield "</label>
                                <div class=\"input-group\">
                                    <span class=\"input-group-text bg-light text-muted small\">
                                        <i class=\"bi bi-tag\"></i>
                                    </span>
                                    <input type=\"text\" 
                                           name=\"entities[";
            // line 37
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["type"], "html", null, true);
            yield "][]\" 
                                           class=\"form-control\" 
                                           placeholder=\"Action, Adventure, etc\">
                                </div>
                                <div class=\"form-text\">Pisahkan dengan koma</div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['type'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        yield "
                        <div class=\"col-12 mt-4 pt-3 border-top d-flex gap-2\">
                            <button type=\"submit\" name=\"is_published\" value=\"1\" class=\"btn btn-primary px-4 py-2\">
                                Publish Series
                            </button>
                            <button type=\"submit\" name=\"is_published\" value=\"0\" class=\"btn btn-outline-secondary px-4 py-2\">
                                Save as Draft
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "Admin/series_create.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  115 => 44,  102 => 37,  93 => 31,  90 => 30,  86 => 29,  58 => 3,  51 => 2,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "Admin/series_create.twig", "/home/lana/Documents/last/views/Admin/series_create.twig");
    }
}
