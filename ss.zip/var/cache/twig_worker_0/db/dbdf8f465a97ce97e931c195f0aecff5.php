<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* Admin/series_edit.html */
class __TwigTemplate_87aa18caa24f225338a576ef0d2a3dd2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "Admin/base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("Admin/base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"container py-5\">
    <div class=\"row justify-content-center\">
        <div class=\"col-lg-10\">
            <div class=\"card shadow-sm border-0 rounded-3\">
                <div class=\"card-body p-4\">
                    <form method=\"POST\">
                        <div class=\"d-flex align-items-center justify-content-between mb-4 border-bottom pb-3\">
                            <h3 class=\"fw-bold text-primary mb-0\">Edit Series: ";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "name", [], "any", false, false, false, 11));
        yield "</h3>
                            <a href=\"/admin/series\" class=\"btn btn-outline-secondary btn-sm\">Back to List</a>
                        </div>

                        <div class=\"row g-3\">
                            <div class=\"col-md-6\">
                                <label class=\"form-label fw-bold\">Title</label>
                                <input type=\"text\" name=\"name\" class=\"form-control\" value=\"";
        // line 18
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "name", [], "any", false, false, false, 18));
        yield "\" required>
                            </div>

                            <div class=\"col-md-6\">
                                <label class=\"form-label fw-bold\">Cover URL</label>
                                <input type=\"url\" name=\"cover_url\" class=\"form-control\" value=\"";
        // line 23
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "cover_url", [], "any", false, false, false, 23));
        yield "\">
                            </div>

                            <div class=\"col-12\">
                                <label class=\"form-label fw-bold\">Description</label>
                                <textarea name=\"description\" class=\"form-control\" rows=\"3\">";
        // line 28
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "description", [], "any", false, false, false, 28));
        yield "</textarea>
                            </div>

                            <div class=\"col-md-6\">
                                <label class=\"form-label fw-bold\">Status</label>
                                <select name=\"is_published\" class=\"form-select\">
                                    <option value=\"1\" ";
        // line 34
        yield (((CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "is_published", [], "any", false, false, false, 34) == 1)) ? ("selected") : (""));
        yield ">Published</option>
                                    <option value=\"0\" ";
        // line 35
        yield (((CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "is_published", [], "any", false, false, false, 35) == 0)) ? ("selected") : (""));
        yield ">Draft</option>
                                </select>
                            </div>

                            <h3 class=\"fw-bold text-primary mt-5 border-bottom pb-3\">Taxonomy & Entities</h3>

                            <div class=\"row g-3 mt-1\">
";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["available_entities"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 43
            yield "    <div class=\"col-md-6\">
        <div class=\"form-group mb-3\">
            <label class=\"form-label fw-bold\">";
            // line 45
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), Twig\Extension\CoreExtension::replace($context["type"], ["-" => " "])), "html", null, true);
            yield "</label>
            <input type=\"text\" 
                   name=\"entities[";
            // line 47
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["type"], "html", null, true);
            yield "][]\" 
                   class=\"form-control\"
                   placeholder=\"Comma separated...\"
                   ";
            // line 51
            yield "                   value=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(Twig\Extension\CoreExtension::map($this->env, (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "entities", [], "any", false, true, false, 51), $context["type"], [], "array", true, true, false, 51) &&  !(null === (($_v0 = CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "entities", [], "any", false, false, false, 51)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[$context["type"]] ?? null) : null)))) ? ((($_v1 = CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "entities", [], "any", false, false, false, 51)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[$context["type"]] ?? null) : null)) : ([])), function ($__e__) use ($context, $macros) { $context["e"] = $__e__; return CoreExtension::getAttribute($this->env, $this->source, ($context["e"] ?? null), "title", [], "any", false, false, false, 51); }), ", "));
            yield "\">
            <div class=\"form-text small\">E.g: Action, Adventure</div>
        </div>
    </div>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['type'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        yield "                            </div>

                            <div class=\"col-12 mt-4 pt-3 border-top\">
                                <button class=\"btn btn-primary px-5 py-2 fw-bold\" type=\"submit\">
                                    Save Changes
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "Admin/series_edit.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  147 => 56,  135 => 51,  129 => 47,  124 => 45,  120 => 43,  116 => 42,  106 => 35,  102 => 34,  93 => 28,  85 => 23,  77 => 18,  67 => 11,  58 => 4,  51 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "Admin/series_edit.html", "/home/lana/Documents/last/views/Admin/series_edit.html");
    }
}
