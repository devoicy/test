<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* drawer.html */
class __TwigTemplate_c654ebbe56714e88e8867cc064c1d483 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "
<script>
document.addEventListener(\"DOMContentLoaded\", () => {  
const path = window.location.pathname;

document.querySelectorAll(\"a\").forEach(a => {
    if (a.getAttribute(\"href\") === path) {
        a.classList.add(\"active\");
    }
});
});  
</script>
<div id=\"drawer\" class=\"drawer\">
<div class=\"ddrawer\">
  <a class=\"addrawer\" href=\"/\">
    <span class=\"drawerItem icon-btn svg no-line\" data-icon=\"home\"></span><span>Home</span>
  </a>
</div>
<div class=\"ddrawer\">
  <a class=\"addrawer\" href=\"/profile\">
    <span class=\"drawerItem icon-btn svg no-line\" data-icon=\"trending-up\"></span><span>Trending</span>
  </a>
</div>
<div class=\"ddrawer\">
  <a class=\"addrawer\" href=\"/title\">
    <span class=\"drawerItem icon-btn svg no-line\" data-icon=\"compass\"></span><span>Explore</span>
  </a>
</div>

<div class=\"ddrawer\" id=\"login\">
  <a class=\"addrawer\" onclick=\"Auth.signin()\">
    <span class=\"drawerItem icon-btn svg no-line\" data-icon=\"login\"></span><span>Sign In</span>
  </a>
</div>
</div>

<div id=\"overlay\" class=\"overlay blur\"></div>

<!-- Top Bar -->
<div class=\"topbar blur10\" id=\"topbar\">
  <button id=\"menuBtn\" class=\"icon-btn svg\" data-icon=\"menu\">s</button>
  <div id=\"title\" class=\"title\">Ohmycomics</div>
  <button id=\"searchBtn\" class=\"icon-btn svg\" data-icon=\"magnify\">s</button>

  <!-- SEARCH BAR -->
  <div id=\"searchContainer\" class=\"search-bar\">
    <span class=\"search-icon svg\" data-icon=\"magnify\"></span>
    <input id=\"searchInput\" type=\"text\" placeholder=\"Search…\">
    <button id=\"clearSearch\" class=\"clear-btn svg\" data-icon=\"close\"></button>
  </div>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "drawer.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "drawer.html", "/home/lana/Documents/last/views/drawer.html");
    }
}
