<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* chapter.html */
class __TwigTemplate_66b684a63dcc58052b1b2048d9944b41 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        yield "<title>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "name", [], "any", false, false, false, 3), "html", null, true);
        yield " - ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "name", [], "any", false, false, false, 3), "html", null, true);
        yield " | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_title"] ?? null), "html", null, true);
        yield "</title>
<link rel=\"canonical\" href=\"";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta name=\"description\" content=\"Read ";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "name", [], "any", false, false, false, 5), "html", null, true);
        yield " ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "name", [], "any", false, false, false, 5), "html", null, true);
        yield " online.\">
<meta property=\"og:title\" content=\"";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "name", [], "any", false, false, false, 6), "html", null, true);
        yield " - ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "name", [], "any", false, false, false, 6), "html", null, true);
        yield "\">
<meta property=\"og:description\" content=\"Read ";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "name", [], "any", false, false, false, 7), "html", null, true);
        yield " ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "name", [], "any", false, false, false, 7), "html", null, true);
        yield " online.\">
<meta property=\"og:type\" content=\"website\">
<meta property=\"og:url\" content=\"";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:image\" content=\"";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["image"] ?? null), "html", null, true);
        yield "\">
<meta name=\"twitter:card\" content=\"summary_large_image\">
<meta name=\"twitter:title\" content=\"";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "name", [], "any", false, false, false, 12), "html", null, true);
        yield " - ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "name", [], "any", false, false, false, 12), "html", null, true);
        yield "\">
<meta name=\"twitter:description\" content=\"Read ";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "name", [], "any", false, false, false, 13), "html", null, true);
        yield " ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "name", [], "any", false, false, false, 13), "html", null, true);
        yield " online.\">
<meta name=\"twitter:image\" content=\"";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["image"] ?? null), "html", null, true);
        yield "\">
";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "<div class=\"lz max-w-1212\">
  <div class=\"infs\">
    <nav class=\"breadcrumb\" aria-label=\"Breadcrumb\">
      <ol>
        <li>
          <a href=\"/\">Home</a >
        </li>
        <li>
          <a href=\"/title\">Series</a>
        </li>
        <li>
          <a href=\"/title/";
        // line 28
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "id", [], "any", false, false, false, 28), "html", null, true);
        yield "/";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "slug", [], "any", false, false, false, 28), "html", null, true);
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "name", [], "any", false, false, false, 28), "html", null, true);
        yield "</a>
        </li>
        <li aria-current=\"page\">";
        // line 30
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "name", [], "any", false, false, false, 30), "html", null, true);
        yield "</li>
      </ol>
    </nav>
  </div>
</div>
<div style=\"background: #fff;\" id=\"images\"></div>

<script>
    (function() {
        const data = ";
        // line 39
        yield CoreExtension::getAttribute($this->env, $this->source, ($context["current"] ?? null), "images", [], "any", false, false, false, 39);
        yield ";
        const container = document.getElementById('images');

        if (!data || !data.files || !Array.isArray(data.files)) {
            container.innerHTML = '<p style=\"padding: 20px;\">Tidak ada gambar ditemukan.</p>';
            return;
        }

        data.files.forEach((fileName) => {
            const div = document.createElement('div');
            const img = document.createElement('img');
            
            div.setAttribute('class', 'image-container chapter');

            img.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=='
            img.setAttribute('data-lazy-src', `\${data.url}/\${data.dir}/\${fileName}`);
            img.classList.add('lazyload');
            img.onerror = function() {
                console.error(\"Gagal memuat:\", this.src);
                this.style.display = 'none';
            };

            div.appendChild(img);
            container.appendChild(div);
        });
    })();
</script>
<div class=\"fab-container\" id=\"fabContainer\">
  <div class=\"fab-menu horizontal\" id=\"fabMenu1\">";
        // line 67
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["navigation"] ?? null), "prev", [], "any", false, false, false, 67)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " <div class=\"fab fab-sub\" id=\"fabLeft\">
      <a href=\"/title/";
            // line 68
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "id", [], "any", false, false, false, 68), "html", null, true);
            yield "/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "slug", [], "any", false, false, false, 68), "html", null, true);
            yield "/chapter/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["navigation"] ?? null), "prev", [], "any", false, false, false, 68), "id", [], "any", false, false, false, 68), "html", null, true);
            yield "/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["navigation"] ?? null), "prev", [], "any", false, false, false, 68), "number", [], "any", false, false, false, 68), "html", null, true);
            yield "\">
        <span class=\"svg no-line\" data-icon=\"chevron-left\"></span>
      </a>
    </div>";
        }
        // line 71
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["navigation"] ?? null), "next", [], "any", false, false, false, 71)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " <div class=\"fab fab-sub\" id=\"fabRight\">
      <a href=\"/title/";
            // line 72
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "id", [], "any", false, false, false, 72), "html", null, true);
            yield "/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "slug", [], "any", false, false, false, 72), "html", null, true);
            yield "/chapter/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["navigation"] ?? null), "next", [], "any", false, false, false, 72), "id", [], "any", false, false, false, 72), "html", null, true);
            yield "/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["navigation"] ?? null), "next", [], "any", false, false, false, 72), "number", [], "any", false, false, false, 72), "html", null, true);
            yield "\">
        <span class=\"svg no-line\" data-icon=\"chevron-right\"></span>
      </a>
    </div>";
        }
        // line 75
        yield " <div class=\"fab fab-sub\" id=\"fabFullscreen\">
      <span class=\"svg no-line\" data-icon=\"fullscreen\"></span>
    </div>
    <div class=\"fab-sub-container\">
      <div class=\"fab fab-sub\" id=\"fabB\">
        <span class=\"svg no-line\" data-icon=\"play\"></span>
      </div>
      <div class=\"fab-sub-menu\" id=\"fabMenuSub\">
        <div class=\"fab fab-sub speed\">3x</div>
        <div class=\"fab fab-sub speed\">2x</div>
        <div class=\"fab fab-sub speed\">1.5x</div>
        <div class=\"fab fab-sub speed\">1x</div>
      </div>
    </div>
  </div>
  <div class=\"fab-menu vertical\" id=\"fabMenu2\">
    <div class=\"fab fab-sub\" id=\"fabInfo\">
      <span class=\"svg no-line\" data-icon=\"flag\"></span>
    </div>
  </div>
  <div class=\"fab\" id=\"fabMain\">
    <span class=\"svg no-line\" data-icon=\"plus\"></span>
  </div>
</div>
<script>
async function Counter(path) {
  const url = path;
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Response status: \${response.status}`);
    }

    const result = await response.json();
    console.log(result);
  } catch (error) {
    console.error(error.message);
  }

}
async function chapterHistory(path, payload) {
  try {
    const response = await fetch(path, {
      method: \"POST\",
      headers: { \"Content-Type\": \"application/json\" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(`Response status: \${response.status}`);
    return await response.json();
  } catch (error) {
    console.error(error.message);
    return null;
  }
}

Counter(\"/api/p/counter\");

</script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "chapter.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  225 => 75,  212 => 72,  208 => 71,  195 => 68,  191 => 67,  160 => 39,  148 => 30,  139 => 28,  126 => 17,  119 => 16,  112 => 14,  106 => 13,  100 => 12,  95 => 10,  91 => 9,  84 => 7,  78 => 6,  72 => 5,  68 => 4,  59 => 3,  52 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "chapter.html", "/home/lana/Documents/last/views/chapter.html");
    }
}
