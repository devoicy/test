<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* home.html */
class __TwigTemplate_944d00cf80a382b0e96792f8927f7ce3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        $context["firstSeries"] = (($_v0 = ($context["data"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[0] ?? null) : null);
        // line 4
        yield "
";
        // line 6
        yield "<title>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["firstSeries"] ?? null), "name", [], "any", false, false, false, 6), "html", null, true);
        yield " and Other 3d Hentai Comic | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["config"] ?? null), "site_title", [], "any", false, false, false, 6), "html", null, true);
        yield "</title>
<link rel=\"canonical\" href=\"";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta name=\"description\" content=\"Explore manga series like ";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["firstSeries"] ?? null), "name", [], "any", false, false, false, 8), "html", null, true);
        yield " and more. Discover genres, authors, and the latest status of ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "total_rows", [], "any", false, false, false, 8), "html", null, true);
        yield " series.\">
<meta property=\"og:title\" content=\"";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["firstSeries"] ?? null), "name", [], "any", false, false, false, 9), "html", null, true);
        yield " and Other 3d Hentai Comic | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["config"] ?? null), "site_title", [], "any", false, false, false, 9), "html", null, true);
        yield "\">
<meta property=\"og:description\" content=\"";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["description"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:type\" content=\"website\">
<meta property=\"og:url\" content=\"";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["uri"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:image\" content=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["firstSeries"] ?? null), "cover_url", [], "any", false, false, false, 13), "html", null, true);
        yield "\">

";
        // line 16
        yield "<meta name=\"twitter:card\" content=\"summary_large_image\">
<meta name=\"twitter:title\" content=\"";
        // line 17
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["firstSeries"] ?? null), "name", [], "any", false, false, false, 17), "html", null, true);
        yield " and Other 3d Hentai Comic | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["config"] ?? null), "site_title", [], "any", false, false, false, 17), "html", null, true);
        yield "\">
<meta name=\"twitter:description\" content=\"Explore manga series like ";
        // line 18
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["firstSeries"] ?? null), "name", [], "any", false, false, false, 18), "html", null, true);
        yield " and more. Discover genres, authors, and the latest status of ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["series"] ?? null), "total_rows", [], "any", false, false, false, 18), "html", null, true);
        yield " series.\">
<meta name=\"twitter:image\" content=\"";
        // line 19
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["firstSeries"] ?? null), "cover_url", [], "any", false, false, false, 19), "html", null, true);
        yield "\">
";
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 22
        yield "<div class=\"lz max-w-1212\">
\t<div class=\"infs\">
\t\t<nav class=\"breadcrumb\" aria-label=\"Breadcrumb\">
\t\t\t<ol>
\t\t\t\t<li aria-current=\"page\">Home</li>
\t\t\t</ol>
\t\t</nav>
\t</div>
\t<div>
\t\twelcome to the sparta clup
\t</div>
</div>
<style>
.lzSliderWrapper {
\tposition: relative;
}

.populer {
\toverflow-x: auto;
\tdisplay: flex;
\tgap: 4px;
\tpadding-bottom: 10px;
\tscroll-snap-type: x mandatory;
}

.populer .lzLinkCard {
\tflex: 0 0 165px;
\tscroll-snap-align: start;
}

.lzSliderBtn {
\tposition: absolute;
\ttop: 50%;
\ttransform: translateY(-50%);
\tz-index: 10;
\tbackground: rgba(0,0,0,0.5);
\tborder: none;
\tcolor: #fff;
\tfont-size: 26px;
\theight: 45px;
\twidth: 45px;
\tborder-radius: 50%;
\tcursor: pointer;
\tdisplay: flex;
\tjustify-content: center;
\talign-items: center;
\tbackdrop-filter: blur(4px);
}

.lzSliderBtn.prev { left: -15px; }
.lzSliderBtn.next { right: -15px; }

.lzSliderBtn:hover {
\tbackground: rgba(0,0,0,0.8);
}
.lzSliderBtn {
    opacity: 0;
    pointer-events: none;
    transition: opacity .3s ease;
}

/* ketika data sudah siap */
.lzSliderBtn.show {
    opacity: 1;
    pointer-events: auto;
}

/* --- Placeholder cards --- */
.placeholder-card {
    flex: 0 0 180px;
    height: 280px;
    border-radius: 12px;
    background: linear-gradient(90deg, #ddd 0%, #eee 50%, #ddd 100%);
    background-size: 200% 100%;
    animation: shimmer 1.2s infinite;
}

@keyframes shimmer {
    from { background-position: -200% 0; }
    to   { background-position: 200% 0; }
}
.populer {
    -ms-overflow-style: none;  /* IE/Edge */
    scrollbar-width: none;     /* Firefox */
}

.populer::-webkit-scrollbar {
    display: none;             /* Chrome/Safari */
}

</style>

<div class=\"lz max-w-1212\">
\t<div class=\"infs\">
\t\t<h2>trending</h2>
\t</div>

\t<div class=\"lzSliderWrapper\" id=\"trending\">
\t\t<button class=\"lzSliderBtn prev\">‹</button>

\t\t<div class=\"lzSliderTrack populer\">
\t\t\t<!-- placeholder akan dibuat via JS -->
\t\t</div>

\t\t<button class=\"lzSliderBtn next\">›</button>
\t</div>
</div>


<div class=\"lz max-w-1212\">
\t<div class=\"infs\">
\t\t<h2>toprated</h2>
\t</div>

\t<div class=\"lzSliderWrapper\" id=\"toprated\">
\t\t<button class=\"lzSliderBtn prev\">‹</button>

\t\t<div class=\"lzSliderTrack populer\">
\t\t\t<!-- placeholder akan dibuat via JS -->
\t\t</div>

\t\t<button class=\"lzSliderBtn next\">›</button>
\t</div>
</div>

<div class=\"lz max-w-1212\">

\t<div class=\"infs\">
\t\t<div style=\"display: flex;justify-content: space-between;align-items: center;\">\t\t<h2 style=\"border-bottom: unset;\">Last update</h2>
\t\t\t<a href=\"/title\">View All</a>
\t\t</div>
\t</div>
    <div class=\"lzCardList\" id=\"results\" style=\"margin-bottom: 2rem;\">
      ";
        // line 155
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["related"]) {
            // line 156
            yield "        <a class=\"lzLinkCard\" href=\"/title/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "slug", [], "any", false, false, false, 156), "html", null, true);
            yield "\">
          <div class=\"lzCard lzCard9x16\">
            <div class=\"lzCardThumbnail\">
              <img data-lazy-src=\"";
            // line 159
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "cover_url", [], "any", false, false, false, 159), "html", null, true);
            yield "\" alt=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "name", [], "any", false, false, false, 159), "html", null, true);
            yield "\" class=\"lazyload\">
            </div>
            <div class=\"lzCardBody\">
              <p class=\"lzCardTitle\">";
            // line 162
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "name", [], "any", false, false, false, 162), "html", null, true);
            yield "</p>
              <p class=\"lzCardMeta\">";
            // line 163
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (($_v1 = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["related"], "entities_text", [], "any", false, false, false, 163), "author", [], "any", false, false, false, 163)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[0] ?? null) : null), "title", [], "any", false, false, false, 163), "html", null, true);
            yield "</p>
              <div class=\"lzCardFooter\">
                <div class=\"lzCardMeta lzMetaHide\">";
            // line 165
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (($_v2 = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["related"], "entities_text", [], "any", false, false, false, 165), "genre", [], "any", false, false, false, 165)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[0] ?? null) : null), "title", [], "any", false, false, false, 165), "html", null, true);
            yield "</div>
                <div class=\"lzCardMeta lzMetaHide\">";
            // line 166
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "chapters_count", [], "any", false, false, false, 166), "html", null, true);
            yield " Chapter</div>
              </div>
            </div>
          </div>
        </a>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['related'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 172
        yield "


<script>

</script>







    </div>
  </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "home.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  309 => 172,  297 => 166,  293 => 165,  288 => 163,  284 => 162,  276 => 159,  269 => 156,  265 => 155,  130 => 22,  123 => 21,  116 => 19,  110 => 18,  104 => 17,  101 => 16,  96 => 13,  92 => 12,  87 => 10,  81 => 9,  75 => 8,  71 => 7,  64 => 6,  61 => 4,  59 => 3,  52 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "home.html", "/home/lana/Documents/last/views/home.html");
    }
}
