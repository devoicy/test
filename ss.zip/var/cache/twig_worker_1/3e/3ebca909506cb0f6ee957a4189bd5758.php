<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* entity.html */
class __TwigTemplate_fc3d98ab30f875dabd3ef06a96659b67 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        yield "<title>Explore ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 3)), "html", null, true);
        yield "s (";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total_rows"] ?? null), "html", null, true);
        yield ") ";
        if ((($context["site_page"] ?? null) > 1)) {
            yield "| Page ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_page"] ?? null), "html", null, true);
            yield " ";
        }
        yield "| ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_title"] ?? null), "html", null, true);
        yield "</title>
<meta name=\"description\" content=\"Discover popular ";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 4)), "html", null, true);
        yield "s such as ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(Twig\Extension\CoreExtension::map($this->env, Twig\Extension\CoreExtension::slice($this->env->getCharset(), ($context["data"] ?? null), 0, 4), function ($__i__) use ($context, $macros) { $context["i"] = $__i__; return CoreExtension::getAttribute($this->env, $this->source, ($context["i"] ?? null), "name", [], "any", false, false, false, 4); }), ", "), "html", null, true);
        yield ".\">
<link rel=\"canonical\" href=\"";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:title\" content=\"Explore ";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 6)), "html", null, true);
        yield "s (";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total_rows"] ?? null), "html", null, true);
        yield ") | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_title"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:description\" content=\"Discover popular ";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 7)), "html", null, true);
        yield "s such as ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(Twig\Extension\CoreExtension::map($this->env, Twig\Extension\CoreExtension::slice($this->env->getCharset(), ($context["data"] ?? null), 0, 4), function ($__i__) use ($context, $macros) { $context["i"] = $__i__; return CoreExtension::getAttribute($this->env, $this->source, ($context["i"] ?? null), "name", [], "any", false, false, false, 7); }), ", "), "html", null, true);
        yield ".\">
<meta property=\"og:url\" content=\"";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:type\" content=\"website\">
<meta name=\"twitter:card\" content=\"summary_large_image\">
<meta name=\"twitter:title\" content=\"Explore ";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 11)), "html", null, true);
        yield "s (";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total_rows"] ?? null), "html", null, true);
        yield ") | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_title"] ?? null), "html", null, true);
        yield "\">
<meta name=\"twitter:description\" content=\"Discover popular ";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 12)), "html", null, true);
        yield "s such as ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(Twig\Extension\CoreExtension::map($this->env, Twig\Extension\CoreExtension::slice($this->env->getCharset(), ($context["data"] ?? null), 0, 4), function ($__i__) use ($context, $macros) { $context["i"] = $__i__; return CoreExtension::getAttribute($this->env, $this->source, ($context["i"] ?? null), "name", [], "any", false, false, false, 12); }), ", "), "html", null, true);
        yield ".\">
";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "<div class=\"lz max-w-1212\">
  <div class=\"infs\">
    <nav class=\"breadcrumb\" aria-label=\"Breadcrumb\">
      <ol>
        <li><a href=\"/\">Home</a></li>
        <li aria-current=\"page\">";
        // line 21
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 21)), "html", null, true);
        yield "</li>
      </ol>
    </nav>
  </div>
  <div style=\"display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom: 1rem;\">
";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 27
            yield "<a href=\"/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entity"], "type", [], "any", false, false, false, 27), "html", null, true);
            yield "/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entity"], "entity_id", [], "any", false, false, false, 27), "html", null, true);
            yield "/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entity"], "slug", [], "any", false, false, false, 27), "html", null, true);
            yield "\" class=\"base-btn btn-filled\"><span class=\"btn-t\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entity"], "name", [], "any", false, false, false, 27), "html", null, true);
            yield " (";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entity"], "series_count", [], "any", false, false, false, 27), "html", null, true);
            yield ")</span></a>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entity'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        yield "</div>
";
        // line 30
        yield from $this->load("pagination.html", 30)->unwrap()->yield($context);
        // line 31
        yield "</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "entity.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  169 => 31,  167 => 30,  164 => 29,  147 => 27,  143 => 26,  135 => 21,  128 => 16,  121 => 15,  112 => 12,  104 => 11,  98 => 8,  92 => 7,  84 => 6,  80 => 5,  74 => 4,  59 => 3,  52 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "entity.html", "/home/lana/Documents/last/views/entity.html");
    }
}
