<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* listsbyentity.html */
class __TwigTemplate_3992afee6cbf57cc441a4b4bf46940a0 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        $context["entityTypePrefixes"] = ["alternative-title" => "Alternative title: ", "artist" => "Explore works by artist ", "author" => "Explore works by author ", "character" => "Explore works featuring ", "demographic" => "Explore series for ", "end-date" => "Series ending on ", "genre" => "Explore series in the ", "group" => "Explore works from group ", "language" => "Explore series in ", "parody" => "Explore series parodying ", "publisher" => "Explore works published by ", "release-date" => "Series released on ", "serialization-site" => "Series serialized at ", "status" => "Series with status ", "tag" => "Explore series tagged with ", "theme" => "Explore series with theme ", "translation" => "Explore translations by ", "type" => "Explore series type "];
        // line 23
        $context["prefix"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["entityTypePrefixes"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 23), [], "array", true, true, false, 23)) ? (Twig\Extension\CoreExtension::default((($_v0 = ($context["entityTypePrefixes"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 23)] ?? null) : null), "Explore ")) : ("Explore "));
        // line 24
        yield "
<title>";
        // line 25
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 25), "html", null, true);
        yield " | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_title"] ?? null), "html", null, true);
        yield "</title>
<meta name=\"description\" content=\"";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["prefix"] ?? null), "html", null, true);
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 26), "html", null, true);
        yield ".\">
<link rel=\"canonical\" href=\"";
        // line 27
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<!-- Open Graph -->
<meta property=\"og:title\" content=\"";
        // line 29
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 29), "html", null, true);
        yield " | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_title"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:description\" content=\"";
        // line 30
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["prefix"] ?? null), "html", null, true);
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 30), "html", null, true);
        yield ".\">
<meta property=\"og:image\" content=\"";
        // line 31
        yield ((CoreExtension::getAttribute($this->env, $this->source, (($_v1 = ($context["data"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[0] ?? null) : null), "cover_url", [], "any", false, false, false, 31)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (($_v2 = ($context["data"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[0] ?? null) : null), "cover_url", [], "any", false, false, false, 31), "html", null, true)) : (""));
        yield "\">
<meta property=\"og:url\" content=\"";
        // line 32
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\">
<meta property=\"og:type\" content=\"website\">

<!-- Twitter Card -->
<meta name=\"twitter:card\" content=\"summary_large_image\">
<meta name=\"twitter:title\" content=\"";
        // line 37
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 37), "html", null, true);
        yield " | ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["site_title"] ?? null), "html", null, true);
        yield "\">
<meta name=\"twitter:description\" content=\"";
        // line 38
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["prefix"] ?? null), "html", null, true);
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 38), "html", null, true);
        yield ".\">
<meta name=\"twitter:image\" content=\"";
        // line 39
        yield ((CoreExtension::getAttribute($this->env, $this->source, (($_v3 = ($context["data"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[0] ?? null) : null), "cover_url", [], "any", false, false, false, 39)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (($_v4 = ($context["data"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[0] ?? null) : null), "cover_url", [], "any", false, false, false, 39), "html", null, true)) : (""));
        yield "\">
";
        yield from [];
    }

    // line 42
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 43
        yield "  <div class=\"lz max-w-1212\">
<div class=\"infs\">
  <nav class=\"breadcrumb\" aria-label=\"Breadcrumb\">
    <ol>
      <li><a href=\"/\">Home</a></li>
        <li><a href=\"/";
        // line 48
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 48), "html", null, true);
        yield "\">";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::capitalize($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "type", [], "any", false, false, false, 48)), "html", null, true);
        yield "</a></li>
        <li aria-current=\"page\">";
        // line 49
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "title", [], "any", false, false, false, 49), "html", null, true);
        yield "</li>
    </ol>
  </nav>
</div>

    <div class=\"lzCardList\" id=\"results\" style=\"margin-bottom: 2rem;\">
      ";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["related"]) {
            // line 56
            yield "        <a class=\"lzLinkCard\" href=\"/title/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "series_id", [], "any", false, false, false, 56), "html", null, true);
            yield "/";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "slug", [], "any", false, false, false, 56), "html", null, true);
            yield "\">
          <div class=\"lzCard lzCard9x16\">
            <div class=\"lzCardThumbnail\">
              <img data-lazy-src=\"";
            // line 59
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "cover_url", [], "any", false, false, false, 59), "html", null, true);
            yield "\" src=\"data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==\" alt=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "name", [], "any", false, false, false, 59), "html", null, true);
            yield "\" class=\"lazyload\">
            </div>
            <div class=\"lzCardBody\">
              <p class=\"lzCardTitle\">";
            // line 62
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "name", [], "any", false, false, false, 62), "html", null, true);
            yield "</p>
              <p class=\"lzCardMeta\">";
            // line 63
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (($_v5 = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["related"], "entities", [], "any", false, false, false, 63), "author", [], "any", false, false, false, 63)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[0] ?? null) : null), "title", [], "any", false, false, false, 63), "html", null, true);
            yield "</p>
              <div class=\"lzCardFooter\">
                <div class=\"lzCardMeta lzMetaHide\">";
            // line 65
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (($_v6 = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["related"], "entities", [], "any", false, false, false, 65), "genre", [], "any", false, false, false, 65)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[0] ?? null) : null), "title", [], "any", false, false, false, 65), "html", null, true);
            yield "</div>
                <div class=\"lzCardMeta lzMetaHide\">";
            // line 66
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["related"], "chapters_count", [], "any", false, false, false, 66), "html", null, true);
            yield " Chapter</div>
              </div>
            </div>
          </div>
        </a>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['related'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 72
        yield "    </div>
    ";
        // line 73
        yield from $this->load("pagination.html", 73)->unwrap()->yield($context);
        // line 74
        yield "  </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "listsbyentity.html";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  203 => 74,  201 => 73,  198 => 72,  186 => 66,  182 => 65,  177 => 63,  173 => 62,  165 => 59,  156 => 56,  152 => 55,  143 => 49,  137 => 48,  130 => 43,  123 => 42,  116 => 39,  111 => 38,  105 => 37,  97 => 32,  93 => 31,  88 => 30,  82 => 29,  77 => 27,  72 => 26,  66 => 25,  63 => 24,  61 => 23,  59 => 3,  52 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "listsbyentity.html", "/home/lana/Documents/last/views/listsbyentity.html");
    }
}
