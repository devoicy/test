<?php

use Swoole\Http\Request as SwooleRequest;
use Swoole\Http\Response as SwooleResponse;
use App\Controllers\Chapter\ChapterController;
use App\Controllers\Chapter\History;
use App\Controllers\Chapter\Counter;

$router->get('/title/{seriesSlug}/{chapterId}', [ChapterController::class,'readChapter']);
$router->get('/api/p/chapter/lists/{seriesId}', [ChapterController::class, 'readChapterLists']);

$router->get('/api/a/counter', [Counter::class, 'execute']);

$router->get('/api/a/chapter/history', [History::class, 'execute'], ['auth_jwt']);