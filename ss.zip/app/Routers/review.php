<?php

use App\Controllers\Review\ReviewController;

$router->post('/api/review/submit', [ReviewController::class, 'submit'], [
	'auth_jwt', 'rateLimit'
]);
$router->post('/api/review/lists', [ReviewController::class, 'lists'], ['auth_jwt']);
$router->post('/api/review/lists/view', [ReviewController::class, 'lists']);