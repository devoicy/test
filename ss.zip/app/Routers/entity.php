<?php

use App\Controllers\Entity\EntityController;

$entities = [
	'alternative-title',
	'artist',
	'author',
	'character',
	'demographic',
	'end-date',
	'genre',
	'group',
	'language',
	'parody',
	'publisher',
	'release-date',
	'serialization-site',
	'status',
	'tag',
	'theme',
	'translation',
	'type',
];

foreach ($entities as $entity) {
    // Route untuk slug -> seriesByEntity
	$router->get("/$entity/{slug}", [EntityController::class, 'getEntitySeriesLists']);
    
    // Route tanpa slug -> entity
	$router->get("/$entity", [EntityController::class, 'getEntity']);
}