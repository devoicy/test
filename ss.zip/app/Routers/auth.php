<?php

use App\Controllers\Auth\AuthController;

$router->get('/signin', [AuthController::class, 'getURL']);
$router->get('/signout', [AuthController::class, 'getSignout']);
$router->get('/callback', [AuthController::class, 'getCallback']);
$router->get('/auth/success', [AuthController::class, 'getPage']);
$router->post('/auth/refresh', [AuthController::class, 'getRefreshToken'], ['Sesi']);