<?php

use App\Controllers\Bookmark\BookmarkController;

$router->get('/bookmarks', [BookmarkController::class, 'bookmarks']);
$router->get('/api/a/bookmarks', [BookmarkController::class, 'lists'], ['auth_jwt']);
$router->get('/api/a/bookmark/lists', [BookmarkController::class, 'listsId'], ['auth_jwt']);
$router->post('/api/a/bookmark/toggle', [BookmarkController::class, 'toggle'], ['auth_jwt', 'rateLimit']);