<?php

use Webtoon\Service\eJWT;
use Webtoon\Service\Cookie;
use Webtoon\Service\Logger;
use Twig\Environment;
use Twig\Loader\LoaderInterface; // Interface yang menyebabkan error
use Twig\Loader\FilesystemLoader; // Implementasi Twig Loader
use MessagePack\Packer;
use MessagePack\PackOptions;
// ----------------------------------------------------------
// 🧱 CONTAINER (PER WORKER)
// ----------------------------------------------------------
//$container = new Container();

// --------------- Config Initialization ------------------
// 1. Inisialisasi objek Config per Worker
$configInstance = new \Webtoon\Config(); 
$configInstance->load(__DIR__ . '/../config.php');