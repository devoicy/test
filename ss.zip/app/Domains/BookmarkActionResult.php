<?php

namespace Webtoon\Domains;

/**
 * BookmarkActionResult merepresentasikan hasil akhir
 * dari sebuah aksi toggle bookmark.
 *
 * Kenapa ENUM?
 * - Menghindari boolean ambiguity
 * - Lebih mudah dibaca di controller & frontend
 * - Aman untuk refactor & event-driven architecture
 */
enum BookmarkActionResult: string
{
    case ADDED   = 'added';   // Bookmark baru ditambahkan
    case REMOVED = 'removed'; // Bookmark dihapus
    case EXISTS  = 'exists';  // Bookmark sudah ada (race-safe no-op)
}
