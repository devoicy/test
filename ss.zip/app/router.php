<?php
declare(strict_types=1);

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Service\Router;
use Webtoon\Service\eJWT;
use Webtoon\Service\Cookie;
use Webtoon\Service\Logger;
use Twig\Environment;
use Twig\Loader\LoaderInterface; // Interface yang menyebabkan error
use Twig\Loader\FilesystemLoader; 

use App;

$serviceDefinitions = [
    // --------------- Config ---------------
    \Webtoon\Config::class => \DI\factory(function() {
        $config = new \Webtoon\Config();
        $config->load(__DIR__ . '/../config.php');
        
        // Set App static variables (sesuai kode lama)
        App::$isCacheEnabled = $config->get('site.cache') ?? false;
        App::$cacheDriver = $config->get('site.system') ?? 'swoole';
        
        return $config;
    }),
    
    // --------------- MessagePack Packer ---------------
    Packer::class => \DI\factory(function() {
        return new Packer(PackOptions::DETECT_STR_BIN | PackOptions::FORCE_FLOAT32);
    }),
    
    // --------------- Twig Loader ---------------
    // SOLUSI: Definisikan FilesystemLoader secara eksplisit
    FilesystemLoader::class => \DI\factory(function() {
        return new FilesystemLoader(__DIR__ . '/../views');
    }),
    
    // SOLUSI: Bind interface LoaderInterface ke implementasi FilesystemLoader
    \Twig\Loader\LoaderInterface::class => \DI\get(FilesystemLoader::class),
    
    // --------------- Twig Environment ---------------
    // SOLUSI: Twig\Environment akan menerima LoaderInterface yang sudah di-bind
    Environment::class => \DI\factory(function($c) use ($workerId) {
        /** @var \Webtoon\Config $config */
        $config = $c->get(\Webtoon\Config::class);
        
        // Sekarang ini akan mendapatkan FilesystemLoader melalui LoaderInterface
        $loader = $c->get(\Twig\Loader\LoaderInterface::class);
        
        $twig = new Environment($loader, [
            'cache' => __DIR__ . "/cache/twig_worker_{$workerId}",
            'auto_reload' => true,
        ]);
        
        // Tambahkan global variables
        $twig->addGlobal('site', $config->get('site'));
        
        return $twig;
    }),
    
    // --------------- Database ---------------
    Database::class => \DI\factory(function($c) use ($workerId) {
        /** @var \Webtoon\Config $config */
        $config = $c->get(\Webtoon\Config::class);
        
        error_log("DB Pool initialized (Worker {$workerId})");
        return new Database($config, 2);
    }),
    
    // --------------- PDO Connection ---------------
    PDO::class => \DI\factory(function($c) {
        /** @var Database $db */
        $db = $c->get(Database::class);
        return $db->getConnection();
    }),
    
    // --------------- JWT ---------------
    eJWT::class => \DI\factory(function($c) {
        /** @var \Webtoon\Config $config */
        $config = $c->get(\Webtoon\Config::class);
        
        $secret = $config->get('jwt.secret');
        $access = $config->get('jwt.access_expire');
        $refresh = $config->get('jwt.refresh_expire');
        
        return new eJWT($secret, $access, $refresh);
    }),
    
    // --------------- Cookie ---------------
    Cookie::class => \DI\factory(function() {
        return new Cookie(false); // true di production
    }),
    
    // --------------- Logger ---------------
    Logger::class => \DI\factory(function($c) use ($workerId) {
        /** @var \Webtoon\Config $config */
        $config = $c->get(\Webtoon\Config::class);
        
        $logger = new Logger();
        $logger->workerId = $workerId;
        $logger->enableDebug = $config->get('logger.debug') ?? false;
        $logger->enableInfo = $config->get('logger.info') ?? true;
        $logger->enableError = $config->get('logger.error') ?? true;
        
        return $logger;
    }),
    
    // --------------- Bin Service ---------------
    Bin::class => \DI\autowire(),
    
    // --------------- Models ---------------
    \Webtoon\Models\Series\SeriesSummaryLists::class => \DI\autowire(),
    \Webtoon\Models\Series\SeriesId::class => \DI\autowire(),
    \Webtoon\Models\Series\SeriesDiscovery::class => \DI\autowire(),
    \Webtoon\Models\Series\SeriesSummaryDetail::class => \DI\autowire(),
    \Webtoon\Models\Auth\AuthRefresh::class => \DI\autowire(),
    
    // --------------- Controllers ---------------
    \Webtoon\Controllers\Series\SeriesSummaryLists::class => \DI\autowire(),
    \Webtoon\Controllers\Series\SeriesId::class => \DI\autowire(),
    \Webtoon\Controllers\Series\SeriesDiscovery::class => \DI\autowire(),
    \Webtoon\Controllers\Series\SeriesSummaryDetail::class => \DI\autowire(),
    \Webtoon\Controllers\Auth\AuthRefresh::class => \DI\autowire(),
    
    // --------------- Middleware ---------------
    \Webtoon\Middleware\Door::class => \DI\autowire(),
];

// Initialize router dengan service definitions
$router = new Router($serviceDefinitions);

// ---------------- ROUTES ----------------

$router->get('/', [
    \Webtoon\Controllers\Series\SeriesDiscovery::class,
    'execute'
]);

$router->get('/title', [
    \Webtoon\Controllers\Series\SeriesSummaryLists::class,
    'execute'
]);

$router->get('/title/{id}', [
    \Webtoon\Controllers\Series\SeriesId::class,
    'execute'
]);

$router->get('/title/{id}/{slug}', [
    \Webtoon\Controllers\Series\SeriesSummaryDetail::class,
    'execute'
]);

$entities = [
    'alternative-title',
    'artist',
    'author',
    'character',
    'demographic',
    'end-date',
    'genre',
    'group',
    'language',
    'parody',
    'publisher',
    'release-date',
    'serialization-site',
    'status',
    'tag',
    'theme',
    'translation',
    'type',
];

foreach ($entities as $entity) {

    $router->get("/{$entity}", [
        \Webtoon\Controllers\Entity\Entity::class,
        'execute'
    ]);

    $router->get("/{$entity}/{slug}", [
        \Webtoon\Controllers\Entity\EntitySeriesList::class,
        'execute'
    ]);

}

$router->get('/title/{seriesId}/{seriesSlug}/chapter/{chapterId}/{chapterNum}', [
    \Webtoon\Controllers\Chapter\Chapter::class,
    'execute'
]);

$router->get('/bookmark', [
    \Webtoon\Controllers\Bookmark\Bookmark::class,
    'execute'
]);

// ---------------- AUTH ------------------------


$router->get('/signin', [
    \Webtoon\Controllers\Auth\Google\CreateURL::class,
    'execute'
]);

$router->get('/signout', [
    \Webtoon\Controllers\Auth\Signout::class,
    'execute'
]);

$router->get('/callback', [
    \Webtoon\Controllers\Auth\Google\Callback::class,
    'execute'
]);

//----------------- JSON -------------------------

$router->get('/api/p/review/{seriesId}', [
    \Webtoon\Controllers\Review\ReviewLists::class,
    'execute'
]);
/*
$router->post('/api/a/review/toggle', [
    \Webtoon\Controllers\Review\ReviewAction::class,
    'execute'
]);
*/
$router->get('/api/p/related/{seriesId}/{seriesSlug}' , [
    \Webtoon\Controllers\Series\SeriesSearch::class,
    'execute'
]);

$router->get('/api/a/bookmark', [
    \Webtoon\Controllers\Bookmark\BookmarkList::class,
    'execute'
]);
/*
$router->post('/api/a/bookmark/toggle', [
    \Webtoon\Controllers\Bookmark\BookmarkAction::class,
    'execute'
]);
*/
$router->get('/api/a/bookmark/lists', [
    \Webtoon\Controllers\Bookmark\BookmarkSeriesIdList::class,
    'execute'
]);

$router->get('/api/p/chapter/lists/{seriesId}' , [
    \Webtoon\Controllers\Chapter\ChapterList::class,
    'execute'
]);

$router->get('/api/p/series/trending', [
    \Webtoon\Controllers\Series\SeriesDiscovery::class,
    'tren'
]);

$router->get('/api/p/series/toprated', [
    \Webtoon\Controllers\Series\SeriesDiscovery::class,
    'top'
]);

$router->get('/api/p/counter', [
    \Webtoon\Controllers\Chapter\Counter::class,
    'execute'
]);

//----------------- Auth -------------------------

$router->get('/api/a/auth/check' , [
    \Webtoon\Controllers\Auth\AuthCheck::class,
    'execute'
]);

$router->get('/api/a/auth/refresh' , [
    \Webtoon\Controllers\Auth\AuthRefresh::class,
    'execute'
], [
    'Webtoon\Middleware\Door'
]);
/*
$router->get('/api/p/search', function(Request $request, Response $response) {

    $response->header('Content-Encoding', 'gzip');
    $response->sendfile(cacheDir('search').'/search.bin');
    return;

});
*/

$router->initialize();