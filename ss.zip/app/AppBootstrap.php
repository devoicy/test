<?php
// AppBootstrap.php
declare(strict_types=1);

use App;
use Bin;
use Database;
use function DI\factory;
use DI\ContainerBuilder;
use Psr\Container\ContainerInterface;
use Twig\Environment;
use Twig\Loader\{ 
    FilesystemLoader, 
    LoaderInterface
};
use Webtoon\Service\Router\Router;
use Webtoon\{ 
    ApiResponse, 
    Config
};
use Webtoon\Service\{
    eJWT,
    Cookie,
    Slugify,
    Logger as LOG
};
use Webtoon\Controllers\Series\{
    SeriesDiscovery as ControllerSeriesDiscovery, 
    SeriesId as ControllerSeriesId, 
    SeriesSearch as ControllerSeriesSearch, 
    SeriesSummaryDetail as ControllerSeriesSummaryDetail, 
    SeriesSummaryList as ControllerSeriesSummaryList
};
use Webtoon\Models\Series\{
    SeriesDiscovery as ModelSeriesDiscovery, 
    SeriesId as ModelSeriesId, 
    SeriesSearch as ModelSeriesSearch, 
    SeriesSummaryById as ModelSeriesSummaryById, 
    SeriesSummaryList as ModelSeriesSummaryList,
    SeriesList as ModelSeriesList,
    SeriesCreate as ModelSeriesCreate
};
use Webtoon\Controllers\Auth\Google\{
    CreateURL,
    Callback
};
use Webtoon\Controllers\Auth\{
    Signout, 
    AuthCheck, 
    AuthRefresh
};
use Webtoon\Models\Auth\{
    UserCreate, 
    UserCreateRefreshToken,
    UserDeleteToken,
    UserFindByEmail,
    UserFindById,
    UserGetToken
};
use Webtoon\Controllers\Entity\{
    Entity as ControllerEntity,
    EntitySeriesList as ControllerEntitySeriesList
};
use Webtoon\Models\Entity\{
    Entity as ModelEntity,
    EntitySeriesList as ModelEntitySeriesList
};
use Webtoon\Controllers\Chapter\{
    Chapter as ControllerChapter,
    ChapterList as ControllerChapterList,
    Counter as ControllerChapterCounter
};
use Webtoon\Models\Chapter\{
    Chapter as ModelChapter,
    ChapterList as ModelChapterList,
    ChapterAction as ModelChapterAction
};
use Webtoon\Controllers\Bookmark\{
    Bookmark as ControllerBookmark,
    BookmarkList as ControllerBookmarkList,
    BookmarkAction as ControllerBookmarkAction,
    BookmarkSeriesIdList as ControllerBookmarkSeriesIdList
};
use Webtoon\Models\Bookmark\{
    BookmarkList as ModelBookmarkList,
    BookmarkAction as ModelBookmarkAction,
    BookmarkSeriesIdList as ModelBookmarkSeriesIdList,
    BookmarkReading as ModelBookmarkReading
};
use Webtoon\Controllers\Review\{
    ReviewAction as ControllerReviewAction,
    ReviewList as ControllerReviewList
};
use Webtoon\Models\Review\{
    ReviewAction as ModelReviewAction,
    ReviewList as ModelReviewList  
};
use Webtoon\Controllers\Admin\{
    SeriesList as AdminSeriesList,
    SeriesCreate as AdminSeriesCreate,
    SeriesEdit as AdminSeriesEdit,
    ChapterCreate as AdminChapterCreate,
    ChapterEdit as AdminChapterEdit,
    ChapterList as AdminChapterList
};
final class AppBootstrap
{
    /**
     * SERVICE DEFINITIONS dengan SEMUA dependencies yang diperlukan
     */
    public function getServiceDefinitions(int $workerId): array
    {
        $definitions = [
            'worker_id' => $workerId,
            // ============ CORE SERVICES ============
            
            // ---------------- CONFIG ----------------
            Config::class => (function () {
                $config = new Config();
                $config->load(__DIR__ . '/../config.php');

                // Legacy static bridge (akan dihapus di versi 2.0)
                App::$isCacheEnabled = $config->get('site.cache') ?? false;
                App::$cacheDriver   = $config->get('site.system') ?? 'swoole';

                return $config;
            }),

            // ---------------- DATABASE ----------------
            Database::class => (function (ContainerInterface $c) {
                $id = $c->get('worker_id');
                $config = $c->get(Config::class);
                error_log("DB pool initialized (Worker {$id})");
                return new Database($config, 2);
            }),

            // ---------------- TWIG LOADER ----------------
            FilesystemLoader::class => (function () {
                return new FilesystemLoader(__DIR__ . '/../views');
            }),

            // bind interface → implementation
            LoaderInterface::class => \DI\get(FilesystemLoader::class),

            // ---------------- TWIG ENV ----------------
            Environment::class => (function (ContainerInterface $c) {
                $id = $c->get('worker_id');
                $config = $c->get(Config::class);
                $loader = $c->get(LoaderInterface::class);

                $twig = new Environment($loader, [
                    'cache'       => __DIR__ . "/../var/cache/twig_worker_{$id}",
                    'auto_reload' => true,
                ]);

                $twig->addGlobal('site', $config->get('site'));

                return $twig;
            }),

            // ---------------- LOG ----------------
            LOG::class => (function (ContainerInterface $c) {
                $id = $c->get('worker_id');
                $config = $c->get(Config::class);

                $LOG = new LOG();
                $LOG->workerId     = $id;
                $LOG->enableDebug  = $config->get('logger.debug') ?? false;
                $LOG->enableInfo   = $config->get('logger.info') ?? true;
                $LOG->enableError  = $config->get('logger.error') ?? true;

                return $LOG;
            }),

            // ---------------- JWT ----------------
            eJWT::class => (function (ContainerInterface $c) {
                $config = $c->get(Config::class);

                return new eJWT(
                    $config->get('jwt.secret'),
                    $config->get('jwt.access_expire'),
                    $config->get('jwt.refresh_expire')
                );
            }),

            // ---------------- COOKIE ----------------
            Cookie::class => (function () {
                return new Cookie(false);
            }),

            // ---------------- BIN SERVICE ----------------
            Bin::class => (function () {
                return new Bin();
            }),

            Slugify::class => (function () {
                return new Slugify();
            }),

            // ---------------- API RESPONSE ----------------
            ApiResponse::class => (function () {
                return new ApiResponse();
            })

        ];

        // ============ MODELS ============
        $definitions = array_merge($definitions, $this->getModelDefinitions());
        
        // ============ CONTROLLERS ============
        $definitions = array_merge($definitions, $this->getControllerDefinitions());
        
        // ============ MIDDLEWARE ============
        $definitions = array_merge($definitions, $this->getMiddlewareDefinitions());

        return $definitions;
    }

    /**
     * MODEL DEFINITIONS - Semua models harus prototype
     */
    private function getModelDefinitions(): array
    {
        return [

            // 📊 SERIES MODELS
            ModelSeriesDiscovery::class => (function (ContainerInterface $c) {
                return new ModelSeriesDiscovery($c->get(Database::class));
            }),
            
            ModelSeriesSummaryList::class => (function (ContainerInterface $c) {
                return new ModelSeriesSummaryList(
                    $c->get(Database::class),
                    $c->get(Bin::class),
                    $c->get(LOG::class)
                );
            }),
            
            ModelSeriesId::class => (function (ContainerInterface $c) {
                return new ModelSeriesId(
                    $c->get(\Database::class),
                    $c->get(LOG::class)
                );
            }),
            
            ModelSeriesSummaryById::class => (function (ContainerInterface $c) {
                return new ModelSeriesSummaryById(
                    $c->get(\Database::class),
                    $c->get(LOG::class)
                );
            }),
            
            ModelSeriesSearch::class => (function (ContainerInterface $c) {
                return new ModelSeriesSearch(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            }),

            ModelSeriesList::class => (function (ContainerInterface $c) {
                return new ModelSeriesList(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            }),

            ModelSeriesCreate::class => (function (ContainerInterface $c) {
                return new ModelSeriesCreate(
                    $c->get(Database::class)
                );
            }),

            // 🔐 AUTH MODELS

            UserCreate::class => (function (ContainerInterface $c) {
                return new UserCreate(
                    $c->get(Database::class)
                );
            }),

            UserCreateRefreshToken::class => (function (ContainerInterface $c) {
                return new UserCreateRefreshToken(
                    $c->get(Database::class)
                );
            }),

            UserDeleteToken::class => (function (ContainerInterface $c) {
                return new UserDeleteToken(
                    $c->get(Database::class)
                );
            }),

            UserFindByEmail::class => (function (ContainerInterface $c) {
                return new UserFindByEmail(
                    $c->get(Database::class)
                );
            }),

            UserFindById::class => (function (ContainerInterface $c) {
                return new UserFindById(
                    $c->get(Database::class)
                );
            }),

            UserGetToken::class => (function (ContainerInterface $c) {
                return new UserGetToken(
                    $c->get(Database::class)
                );
            }),

            // 🏷️ ENTITY MODELS
            ModelEntity::class => (function (ContainerInterface $c) {
                return new ModelEntity(
                    $c->get(Database::class),
                    $c->get(Bin::class)
                );
            }),
            
            ModelEntitySeriesList::class => (function (ContainerInterface $c) {
                return new ModelEntitySeriesList(
                    $c->get(Database::class),
                    $c->get(Bin::class)
                );
            }),

            // 📖 CHAPTER MODELS
            ModelChapter::class => (function (ContainerInterface $c) {
                return new ModelChapter(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            }),
            
            ModelChapterList::class => (function (ContainerInterface $c) {
                return new ModelChapterList(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            }),

            ModelChapterAction::class => (function (ContainerInterface $c) {
                return new ModelChapterAction(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            }),
            // ⭐ REVIEW MODELS
            ModelReviewAction::class => (function (ContainerInterface $c) {
                return new ModelReviewAction(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            }),

            ModelReviewList::class => (function (ContainerInterface $c) {
                return new ModelReviewList(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            }),

            // 🔖 BOOKMARK MODELS
            ModelBookmarkList::class => (function (ContainerInterface $c) {
                return new ModelBookmarkList(
                    $c->get(\Database::class)
                );
            }),
            
            ModelBookmarkSeriesIdList::class => (function (ContainerInterface $c) {
                return new ModelBookmarkSeriesIdList(
                    $c->get(\Database::class)
                );
            }),

            ModelBookmarkAction::class => (function (ContainerInterface $c) {
                return new ModelBookmarkAction(
                    $c->get(\Database::class)
                );
            }),

            ModelBookmarkReading::class => (function (ContainerInterface $c) {
                return new ModelBookmarkReading(
                    $c->get(Database::class),
                    $c->get(LOG::class)
                );
            })
        ];
    }

    /**
     * CONTROLLER DEFINITIONS - Semua controllers harus prototype
     */
    private function getControllerDefinitions(): array
    {
        return [

            ControllerSeriesDiscovery::class => (function (ContainerInterface $c) {

                return new ControllerSeriesDiscovery(
                    $c->get(ModelSeriesDiscovery::class),  // ✅ Model dependency
                    $c->get(ModelSeriesSummaryList::class),  // ✅ Model dependency
                    $c->get(ApiResponse::class),  // ✅ Model dependency
                    $c->get(Environment::class)                               // ✅ Twig dependency
                );
            }), 
            
            ControllerSeriesSummaryList::class => (function (ContainerInterface $c) {
                return new ControllerSeriesSummaryList(
                    $c->get(ModelSeriesSummaryList::class),
                    $c->get(Environment::class),
                    $c->get(Config::class)
                );
            }),
            
            ControllerSeriesId::class => (function (ContainerInterface $c) {
                return new ControllerSeriesId(
                    $c->get(ModelSeriesId::class),
                    $c->get(Environment::class)
                );
            }),
            
            ControllerSeriesSummaryDetail::class => (function (ContainerInterface $c) {
                return new ControllerSeriesSummaryDetail(
                    $c->get(ModelSeriesSummaryById::class),
                    $c->get(Environment::class),
                    $c->get(Config::class)
                );
            }),
            
            ControllerSeriesSearch::class => (function (ContainerInterface $c) {
                return new ControllerSeriesSearch(
                    $c->get(ModelSeriesSearch::class),
                    $c->get(ApiResponse::class)
                );
            }),

            // 🔐 AUTH CONTROLLERS
            CreateURL::class => (function (ContainerInterface $c) {
                return new CreateURL();
            }),
            
            Callback::class => (function (ContainerInterface $c) {
                return new Callback(
                    $c->get(eJWT::class),
                    $c->get(Cookie::class),
                    $c->get(UserCreate::class),
                    $c->get(UserFindByEmail::class),
                    $c->get(UserCreateRefreshToken::class)
                );
            }),

            Signout::class => (function (ContainerInterface $c) {
                return new Signout(
                    $c->get(Cookie::class),
                    $c->get(UserDeleteToken::class),
                    $c->get(ApiResponse::class)
                );
            }),
            
            AuthCheck::class => (function (ContainerInterface $c) {
                return new AuthCheck(
                    $c->get(ApiResponse::class),
                    $c->get(eJWT::class)
                );
            }),
            
            AuthRefresh::class => (function (ContainerInterface $c) {
                return new AuthRefresh(
                    $c->get(ApiResponse::class),
                    $c->get(eJWT::class)
                );
            }),

            // 🏷️ ENTITY CONTROLLERS
            ControllerEntity::class => (function (ContainerInterface $c) {
                return new ControllerEntity(
                    $c->get(ModelEntity::class),
                    $c->get(Environment::class),
                    $c->get(Config::class)
                );
            }),
            
            ControllerEntitySeriesList::class => (function (ContainerInterface $c) {
                return new ControllerEntitySeriesList(
                    $c->get(ModelEntitySeriesList::class),
                    $c->get(Environment::class),
                    $c->get(Config::class)
                );
            }),

            // 📖 CHAPTER CONTROLLERS
            ControllerChapter::class => (function (ContainerInterface $c) {
                return new ControllerChapter(
                    $c->get(ModelChapter::class),
                    $c->get(ApiResponse::class),
                    $c->get(Slugify::class),
                    $c->get(Environment::class),
                    $c->get(Config::class)
                );
            }),
            
            ControllerChapterList::class => (function (ContainerInterface $c) {
                return new ControllerChapterList(
                    $c->get(ModelChapterList::class),
                    $c->get(ApiResponse::class)
                );
            }),
            
            ControllerChapterCounter::class => (function (ContainerInterface $c) {
                return new ControllerChapterCounter(
                    $c->get(ModelBookmarkReading::class),
                    $c->get(eJWT::class)
                );
            }),

            // ⭐ REVIEW CONTROLLERS

            ControllerReviewAction::class => (function (ContainerInterface $c) {
                return new ControllerReviewAction(
                    $c->get(ModelReviewAction::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class)
                );
            }),

            ControllerReviewList::class => (function (ContainerInterface $c) {
                return new ControllerReviewList(
                    $c->get(ModelReviewList::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class)
                );
            }),

            // 🔖 BOOKMARK CONTROLLERS

            ControllerBookmark::class => (function ( ContainerInterface $c) {
                return new ControllerBookmark(
                    $c->get(Environment::class)
                );
            }),

            ControllerBookmarkList::class => (function (ContainerInterface $c) {
                return new ControllerBookmarkList(
                    $c->get(ModelBookmarkList::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class)
                );
            }),

            ControllerBookmarkAction::class => (function (ContainerInterface $c) {
                return new ControllerBookmarkAction(
                    $c->get(ModelBookmarkAction::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class)
                );
            }),

            ControllerBookmarkSeriesIdList::class => (function (ContainerInterface $c) {
                return new ControllerBookmarkSeriesIdList(
                    $c->get(ModelBookmarkSeriesIdList::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class)
                );
            }),

            // Admin Controller

            AdminSeriesList::class => (function (ContainerInterface $c) {
                return new AdminSeriesList(
                    $c->get(ModelSeriesList::class),
                    $c->get(eJWT::class),
                    $c->get(Environment::class)
                );
            }),

            AdminSeriesCreate::class => (function (ContainerInterface $c) {
                return new AdminSeriesCreate(
                    $c->get(Slugify::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class),
                    $c->get(ModelSeriesCreate::class),
                    $c->get(Environment::class)                   
                );
            }),

            AdminSeriesEdit::class => (function (ContainerInterface $c) {
                return new AdminSeriesEdit(
                    $c->get(Slugify::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class),
                    $c->get(ModelSeriesCreate::class),
                    $c->get(ModelSeriesSummaryById::class),
                    $c->get(Environment::class)                   
                );
            }),

            AdminChapterCreate::class => (function (ContainerInterface $c) {
                return new AdminChapterCreate(
                    $c->get(ModelSeriesSummaryById::class),
                    $c->get(ModelChapterAction::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class),
                    $c->get(Environment::class)                   
                );
            }),

            AdminChapterEdit::class => (function (ContainerInterface $c) {
                return new AdminChapterEdit(
                    $c->get(ModelSeriesSummaryById::class),
                    $c->get(ModelChapter::class),
                    $c->get(ModelChapterAction::class),
                    $c->get(eJWT::class),
                    $c->get(ApiResponse::class),
                    $c->get(Environment::class)   
                );
            }),

            AdminChapterList::class => (function (ContainerInterface $c) {
                return new AdminChapterList(
                    $c->get(ModelChapterList::class),
                    $c->get(eJWT::class),
                    $c->get(Environment::class)                   
                );
            }),
        ];
    }

    /**
     * MIDDLEWARE DEFINITIONS - Middleware juga prototype
     */
    private function getMiddlewareDefinitions(): array
    {
        return [
            \Webtoon\Middleware\Door::class => (function (ContainerInterface $c) {
                return new \Webtoon\Middleware\Door(
                    $c->get(eJWT::class),
                    $c->get(UserFindById::class),
                    $c->get(UserGetToken::class),
                    $c->get(UserDeleteToken::class),
                    $c->get(UserCreateRefreshToken::class),
                    $c->get(Cookie::class),
                    $c->get(ApiResponse::class)
                );
            }),
            
            // Tambahkan middleware lain jika ada
            \Webtoon\Middleware\Cache::class => (function (ContainerInterface $c) {
                return new \Webtoon\Middleware\Cache(
                    $c->get(Config::class)
                );
            }),
            
            \Webtoon\Middleware\Admin::class => (function (ContainerInterface $c) {
                return new \Webtoon\Middleware\Admin(
                    $c->get(eJWT::class)
                );
            }),
        ];
    }

    /**
     * ROUTES - Semua route definitions
     */
    public function defineRoutes(Router $router): void
    {

        //$router->setGlobalMiddlewares([\Webtoon\Middleware\Cache::class]);

        // ============ WEB ROUTES ============
        $router->get('/', [
            ControllerSeriesDiscovery::class,
            'execute'
        ]);
        
        $router->get('/title', [
            ControllerSeriesSummaryList::class,
            'execute'
        ]);
        
        $router->get('/title/{id}', [
            ControllerSeriesId::class,
            'execute'
        ]);
        
        $router->get('/title/{id}/{slug}', [
            ControllerSeriesSummaryDetail::class,
            'execute'
        ],[
            'Webtoon\Middleware\Cache'
        ]);

        // ============ ENTITY ROUTES ============
        /*foreach ([
            'alternative-title','artist','author','character','demographic','end-date',
            'genre','group','language','parody','publisher','release-date',
            'serialization-site','status','tag','theme','translation','type'
        ] as $entity) {

            $router->get("/{$entity}", [
                ControllerEntity::class,
                'execute'
            ]);

            $router->get("/{$entity}/{slug}", [
                ControllerEntitySeriesList::class,
                'execute'
            ]);
        }

        $router->get("/e/{entityId}/{entityType}/{entitySlug}", [
            ControllerEntitySeriesList::class,
            'execute'
        ]);*/

        $entities = [
            'alternative-title','artist','author','character','demographic','end-date',
            'genre','group','language','parody','publisher','release-date',
            'serialization-site','status','tag','theme','translation','type'
        ];

        $pattern = implode('|', $entities);

        // 2. Daftarkan hanya 2 route pintar (FastRoute mendukung format {param:regex})
        // Menangani: /artist, /genre, /tag, dll.
        $router->get("/{entityType:{$pattern}}", [
            ControllerEntity::class, 
            'execute'
        ]);

        // Menangani: /artist/slug-name, /genre/shounen, dll.
        $router->get("/{entityType:{$pattern}}/{entityId}/{entitySlug}", [
            ControllerEntitySeriesList::class, 
            'execute'
        ]);

        //
        $router->get(
            '/title/{seriesId}/{seriesSlug}/chapter/{chapterId}/{chapterNum}',
            [ControllerChapter::class, 'execute']
        );

        $router->get('/bookmark', [
            \Webtoon\Controllers\Bookmark\Bookmark::class,
            'execute'
        ]);

        // ============ AUTH ROUTES ============
        $router->get('/signin', [
            CreateURL::class,
            'execute'
        ]);
        
        $router->get('/signout', [
            Signout::class,
            'execute'
        ]);
        
        $router->get('/callback', [
            Callback::class,
            'execute'
        ]);

        // ============ API ROUTES ============


        $router->post('/api/a/review/toggle', [
            ControllerReviewAction::class,
            'execute'
        ]);

        $router->get('/api/p/review/{seriesId}', [
            ControllerReviewList::class,
            'execute'
        ]);

        $router->get('/api/p/related/{seriesId}/{seriesSlug}', [
            ControllerSeriesSearch::class,
            'execute'
        ]);
        
        $router->get('/api/a/bookmark', [
            \Webtoon\Controllers\Bookmark\BookmarkList::class,
            'execute'
        ]);

        $router->post('/api/a/bookmark/toggle', [
            \Webtoon\Controllers\Bookmark\BookmarkAction::class,
            'execute'
        ]);

        $router->get('/api/a/bookmark/lists', [
            \Webtoon\Controllers\Bookmark\BookmarkSeriesIdList::class,
            'execute'
        ]);
        
        $router->get('/api/p/chapter/lists/{seriesId}', [
            ControllerChapterList::class,
            'execute'
        ]);

        $router->get('/api/p/series/trending', [
            \Webtoon\Controllers\Series\SeriesDiscovery::class,
            'tren'
        ]);
        
        $router->get('/api/p/series/toprated', [
            \Webtoon\Controllers\Series\SeriesDiscovery::class,
            'top'
        ]);

        $router->get('/api/p/counter', [
            \Webtoon\Controllers\Chapter\Counter::class,
            'execute'
        ]);

        $router->get('/api/a/auth/check', [
            AuthCheck::class,
            'execute'
        ]);
        
        $router->get(
            '/api/a/auth/refresh',
            [AuthRefresh::class, 'execute'],
            ['Webtoon\Middleware\Door']
        );

        // ============ ADMIN ============

        $router->get(
            '/admin',
            [
                AdminSeriesList::class,
                'execute'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );

        $router->get(
            '/admin/series/add',
            [
                AdminSeriesCreate::class,
                'get'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );


        $router->post(
            '/admin/series/add',
            [
                AdminSeriesCreate::class,
                'post'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );

        $router->get(
            '/admin/series/edit/{id}',
            [
                AdminSeriesEdit::class,
                'get'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );

        $router->post(
            '/admin/series/edit/{id}',
            [
                AdminSeriesEdit::class,
                'post'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );

        $router->get(
            '/admin/series/{id}/chapter',
            [
                AdminChapterList::class,
                'execute'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );

        $router->get(
            '/admin/series/{id}/chapter/add',
            [
                AdminChapterCreate::class,
                'get'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );


        $router->post(
            '/admin/series/{id}/chapter/add',
            [
                AdminChapterCreate::class,
                'post'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );

        $router->get(
            '/admin/series/{seriesId}/chapter/edit/{chapterId}',
            [
                AdminChapterEdit::class,
                'get'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );


        $router->post(
            '/admin/series/{seriesId}/chapter/edit/{chapterId}',
            [
                AdminChapterEdit::class,
                'post'
            ],
            [
                'Webtoon\Middleware\Door',
                'Webtoon\Middleware\Admin'
            ]
        );

    }

    /**
     * OPTIONAL WARMUP - Pre-load services yang berat
     */
    public function warmupServices(ContainerInterface $container): void
    {
        try {
            // Pre-warm services yang berat
            $container->get(Environment::class);
            $container->get(Database::class);
            $container->get(Bin::class);
            
            // Pre-warm models yang sering dipakai
            $container->get(ModelSeriesSummaryList::class);
            $container->get(ModelSeriesDiscovery::class);
            $container->get(ModelSeriesSearch::class);
            
        } catch (\Throwable $e) {
            error_log("⚠️ Warmup warning: " . $e->getMessage());
        }
    }
}