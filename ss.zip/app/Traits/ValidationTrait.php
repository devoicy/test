<?php
namespace Webtoon\Traits;

trait ValidationTrait
{

    protected $allowedTypes;

    public function allFieldsFilled(array $data, array $fields): bool
    {
        foreach ($fields as $field) {
            if (empty(trim($data[$field]))) return false;
        }
        return true;
    }

    public function missingFields(array $data, array $fields): array
    {
        $missing = [];
        foreach ($fields as $field) {
            if (empty(trim($data[$field]))) $missing[] = $field;
        }
        return $missing;
    }

    public function sanitizeString(string $string, int $limit = 200): string
    {

        return htmlspecialchars(mb_substr(trim($string), 0, $limit, 'UTF-8'), ENT_QUOTES, 'UTF-8');
    }

    public function isTypeValid($type){
        $this->allowedTypes ??= require __DIR__ . '/../Entities.php';
        return in_array($type, $this->allowedTypes, true);
    }

    public function seriesValidate(array $data): array
    {

        $required = ['title', 'cover_image', 'description'];
        // Validasi semua field wajib ada
        if (!$this->allFieldsFilled($data, $required)) {
            $missing = $this->missingFields($data, $required);
            throw new \Exception("Missing fields: " . implode(', ', $missing));
        }

        $data['title'] = $this->sanitizeString($data['title']);
        $data['slug'] = \URLify::slug($this->sanitizeString($data['title']));
        $data['cover_image'] = $this->sanitizeString($data['cover_image']);
        $data['description'] = $this->sanitizeString($data['description']);

        foreach ($data['entities'] as $key => $value) {
            if($data['entities'][$key]) {
                $json = json_decode($value);
                $validated = [];
                foreach($json as $value) {
                    $title = $this->sanitizeString($value);
                    if($title) {
                        array_push(
                            $validated,
                            [
                                'type' => $key,
                                'title' => $title,
                                'slug' => \URLify::slug($title)
                            ]);
                    }
                }
                $data['entities'][$key] = $validated;
            } else {
                unset($data['entities'][$key]);
            }
        }

        return $data;

    }

// Pastikan fungsi Anda di class ini terlihat seperti ini:

private function parseEntitiesByType(?string $str): array {
    if (!$str) return [];

    // Prioritas 1: JSON Decode (Native C, Paling Cepat)
    $entities = json_decode($str, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($entities)) {
        return $entities;
    }

    // Prioritas 2: Parsing String Kustom
    $entities = [];
    
    // GUNAKAN EXPLODE DENGAN BATAS 4
    $items = explode('|', $str);

    foreach ($items as $item) {
        if ($item === '') {
            continue;
        }

        // Pisahkan menjadi 4 bagian: type, id, slug, title
        $parts = explode(':', $item, 4); 

        if (count($parts) < 4) {
            continue;
        }

        $type = $parts[0];
        $id = (int)$parts[1]; 
        $slug = $parts[2];
        $title = rawurldecode($parts[3]);

        if (!isset($entities[$type])) {
            $entities[$type] = [];
        }

        $entities[$type][] = [
            'id' => $id,
            'slug' => $slug,
            'title' => $title,
        ];
    }

    return $entities;
}


    public function isJson($string, bool $assoc = true) {
        if (!is_string($string) || trim($string) === '') {
            return null; // bukan string atau kosong
        }

        $decoded = json_decode($string, $assoc);

        return (json_last_error() === JSON_ERROR_NONE) ? $decoded : null;
    }

/**
 * Cek panjang string sebelum simpan ke DB
 *
 * @param string $text     Teks yang ingin disimpan
 * @param int    $maxChars Maksimal karakter
 * @param int    $maxBytes Maksimal byte
 * @return array [isValid: bool, lengthChars: int, lengthBytes: int, error: string|null]
 */
public function validateTextLength(string $text, int $maxChars = 65535, int $maxBytes = 65535): array
{
    $lengthChars = mb_strlen($text, 'UTF-8');
    $lengthBytes = strlen($text);

    if ($lengthChars > $maxChars) {
        return [
            'isValid' => false,
            'lengthChars' => $lengthChars,
            'lengthBytes' => $lengthBytes,
            'error' => "Maks $maxChars char.",
        ];
    }

    if ($lengthBytes > $maxBytes) {
        return [
            'isValid' => false,
            'lengthChars' => $lengthChars,
            'lengthBytes' => $lengthBytes,
            'error' => "Maks $maxBytes byte.",
        ];
    }

    return [
        'isValid' => true,
        'lengthChars' => $lengthChars,
        'lengthBytes' => $lengthBytes,
        'error' => null,
    ];
}

    public function arr(int $code, bool $success, string $message, ?array $data = null)
    {

        return [
            "status" => $code,
            "success" => $success,
            "message" => $message,
            "data"    => $data
        ];

    }




}

