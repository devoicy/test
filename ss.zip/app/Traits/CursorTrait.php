<?php

namespace Webtoon\Traits;

trait CursorTrait
{
	private $secret = 'santai-saja-bro';
    // class yang pake trait ini harus punya: protected string $secret;

    /* --------------------- HELPER BASE64URL --------------------- */

    private function base64url_encode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private function base64url_decode(string $data): string|false
    {
        $data = strtr($data, '-_', '+/');
        $pad  = strlen($data) % 4;
        if ($pad > 0) $data .= str_repeat('=', 4 - $pad);

        return base64_decode($data, true);
    }

    /* ------------------------ SIGNATURE ------------------------- */

    private function createSignature(string $payload): string
    {
        return hash_hmac('sha256', $payload, $this->secret);
    }

    /* --------------------- ENCODE CURSOR ------------------------ */

    private function encodeCursor(array $data): string
    {
        if (!isset($data['id'])) {
            throw new \InvalidArgumentException("Cursor payload must contain 'id'.");
        }

        // Tambahkan nonce biar anti-pattern & anti-replay
        $data['nonce'] = bin2hex(random_bytes(4));

        // Optional expiry (ambil 24 jam) → bisa kamu matiin kalau mau
        $data['exp'] = time() + 86400; 

        $payload = json_encode($data);

        $sign = $this->createSignature($payload);

        return $this->base64url_encode($payload . '.' . $sign);
    }

    /* --------------------- DECODE CURSOR ------------------------ */

    private function decodeCursor(?string $cursor): array
    {
        if (!$cursor) {
            return [null, null];
        }

        $decoded = $this->base64url_decode($cursor);
        if (!$decoded || !str_contains($decoded, '.')) {
            return [null, null];
        }

        [$payload, $sign] = explode('.', $decoded, 2);

        $expected = $this->createSignature($payload);

        if (!hash_equals($expected, $sign)) {
            return [null, null]; // invalid/tampered
        }

        $data = json_decode($payload, true);

        // expiry check
        if (isset($data['exp']) && time() > $data['exp']) {
            return [null, null]; // expired
        }

        if (!isset($data['id']) || !is_numeric($data['id'])) {
            return [null];
        }

        return [(int)$data['id']];
    }
}
