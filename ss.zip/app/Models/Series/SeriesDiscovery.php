<?php
declare(strict_types=1);

namespace Webtoon\Models\Series;

use Database;
use PDO;
use Throwable;

/**
 * SeriesDiscovery v1.1 — High-Performance Index Utilizer
 * * DOKUMENTASI UNTUK TIM:
 * Class ini dirancang khusus agar query "HITS" (Top Views, Top Rated) berjalan di level O(log N).
 * * 🚨 ATURAN EMAS:
 * 1. Jangan ubah urutan WHERE is_published = 1. Ini adalah 'Leading Column' pada Composite Index.
 * 2. ORDER BY harus sesuai dengan urutan DESC pada skema INDEX di database.
 * 3. Hindari penggunaan JOIN di sini karena data sudah didenormalisasi ke series_summary.
 */
final class SeriesDiscovery
{
    public function __construct(private Database $db) {}

    /**
     * 📈 GET TRENDING (Top Views)
     * Menggunakan Index: series_summary_filter_views (is_published, views_count DESC)
     * * Mekanisme: Database langsung melompat ke bucket 'published', lalu mengambil 10 baris 
     * teratas tanpa proses SORTING lagi (Index sudah urut secara fisik).
     */
    public function getTrending(int $limit = 10): array
    {
        return $this->query([
            'mode' => 'views',
            'sql'  => "SELECT series_id, name, slug, cover_url, views_count, chapters_count, entities_text 
                       FROM series_summary 
                       WHERE is_published = 1 
                       ORDER BY views_count DESC 
                       LIMIT ?",
            'limit' => $limit
        ]);
    }

    /**
     * 🌟 GET TOP RATED (Rating Tertinggi)
     * Menggunakan Index: series_summary_filter_rating (is_published, rating_average DESC, rating_count)
     * * Parameter $minReviews penting untuk menghindari 'Low-Volume Bias' 
     * (Series baru 1 rating bintang 5 yang mengalahkan series 1000 rating bintang 4.8).
     */
    public function getTopRated(int $limit = 10, int $minReviews = 1): array
    {
        return $this->query([
            'mode' => 'rating',
            'sql'  => "SELECT series_id, name, slug, cover_url, rating_average, rating_count, chapters_count, entities_text 
                       FROM series_summary 
                       WHERE is_published = 1 AND rating_count >= ?
                       ORDER BY rating_average DESC 
                       LIMIT ?",
            'params' => [$minReviews, $limit]
        ]);
    }

    /**
     * 🆕 GET RECENTLY UPDATED (Update Terbaru)
     * Menggunakan Index: series_summary_filter (is_published, updated_at DESC)
     * * Digunakan untuk section "Baru Update" di Homepage.
     */
    public function getRecentlyUpdated(int $limit = 15): array
    {
        return $this->query([
            'mode' => 'updated',
            'sql'  => "SELECT series_id, name, slug, cover_url, chapters_count, updated_at, entities_text 
                       FROM series_summary 
                       WHERE is_published = 1 
                       ORDER BY updated_at DESC 
                       LIMIT ?",
            'limit' => $limit
        ]);
    }

    /**
     * Helper internal untuk eksekusi query.
     * Mengotomatisasi binding parameter dan casting tipe data.
     */
    private function query(array $config): array
    {
        $pdo = $this->db->getConnection();
        $stmt = null;

        try {
            $stmt = $pdo->prepare($config['sql']);
            $params = $config['params'] ?? [$config['limit']];
            foreach ($params as $i => $val) {
                $stmt->bindValue($i + 1, $val, is_int($val) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }

            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            foreach ($rows as &$row) {
                // 1. Numeric Casting
                if (isset($row['series_id'])) $row['series_id'] = (int)$row['series_id'];
                if (isset($row['views_count'])) $row['views_count'] = (int)$row['views_count'];
                if (isset($row['rating_average'])) $row['rating_average'] = (float)$row['rating_average'];
                if (isset($row['chapters_count'])) $row['chapters_count'] = (int)$row['chapters_count'];

                // 2. Decode Entities (Genre, Author, dkk)
                if (!empty($row['entities_text'])) {
                    $unpacked = msgpack_unpack($row['entities_text']);
                    $row['entities'] = $unpacked['entities'] ?? [];
                } else {
                    $row['entities'] = [];
                }

                // 3. Cleanup: Buang data binary biar response JSON ringan
                unset($row['entities_text']);
            }
            unset($row);
            return $rows;

        } catch (Throwable $e) {
            $this->db->logError($e, 'SeriesDiscovery|' . $config['mode']);
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }
}