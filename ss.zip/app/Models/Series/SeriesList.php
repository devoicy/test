<?php
declare(strict_types=1);

namespace Webtoon\Models\Series;

use Database;
use PDO;
use Webtoon\Service\Logger;

class SeriesList
{
    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    /**
     * @return array{series: array, next: ?array}
     */
    public function execute(?int $lastId = null, int $limit = 20): array
    {
        $pdo = $this->db->getConnection();
        $stmt = null;

        try {
            // Menggunakan WHERE 1=1 untuk mempermudah appending string SQL
            $sql = "SELECT id, is_published, name, slug, created_by, updated_by, created_at
                    FROM series 
                    WHERE 1=1";

            $params = [];

            if ($lastId !== null) {
                $sql .= " AND id < :lastId";
                $params[':lastId'] = $lastId;
            }

            // Selalu tambahkan ORDER BY untuk konsistensi cursor pagination
            $sql .= " ORDER BY id DESC LIMIT :limit";

            $stmt = $pdo->prepare($sql);
            
            // Bind params secara dinamis
            foreach ($params as $key => $val) {
                $stmt->bindValue($key, $val, PDO::PARAM_INT);
            }
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);

            $stmt->execute();
            
            // Ambil semua data (fetchAll)
            $series = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($series)) {
                return [
                    'series' => [],
                    'next'   => null
                ];
            }

            // Mengambil item terakhir untuk cursor berikutnya
            $lastItem = end($series);

            return [
                'series' => $series,
                'next' => [
                    'id' => (int) $lastItem['id']
                ]
            ];

        } catch (\Throwable $e) {
            $this->logger->error($e, 'SeriesList|execute');
            return [
                'series' => [],
                'next'   => null
            ];
        } finally {
            if ($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }
}