<?php
declare(strict_types=1);

namespace Webtoon\Models\Series;

use Database;
use PDO;
use Webtoon\Service\Logger;

/**
 * SeriesSummaryBySlug — Fetch detail satu series secara efisien
 * Pure read dari tabel denormalisasi (Zero Join).
 */
final class SeriesSummaryById
{
    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    public function execute(int $id): ?array
    {
        $pdo = $this->db->getConnection(); 
        $stmt = null;

        try {
            $stmt = $pdo->prepare("
                SELECT 
                    series_id, is_published, name, description, slug, cover_url, entities_text, 
                    views_count, bookmark_count, chapters_count, rating_average
                FROM series_summary
                WHERE series_id = :id
                LIMIT 1
            ");
            
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            // Explicitly use FETCH_ASSOC
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$data) {
                return null;
            }

            // 1. Casting Numeric Data (Penting untuk BIGINT & DECIMAL)
            $data['series_id']       = (int)$data['series_id'];
            $data['views_count']     = (int)$data['views_count'];
            $data['bookmark_count']  = (int)$data['bookmark_count'];
            $data['chapters_count']  = (int)$data['chapters_count'];
            $data['rating_average']  = (float)$data['rating_average'];

            // 2. Decode MsgPack Entities
            if (!empty($data['entities_text'])) {
                $unpacked = msgpack_unpack($data['entities_text']);
                $data['entities'] = $unpacked['entities'] ?? [];
            } else {
                $data['entities'] = [];
            }

            unset($data['entities_text']);

            return $data;

        } catch (\Throwable $e) {
            $this->logger->error($e, 'SeriesSummaryById|execute');
            return null;
        } finally {

            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }
    }
}