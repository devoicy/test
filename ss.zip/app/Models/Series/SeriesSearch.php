<?php

declare(strict_types=1);

namespace Webtoon\Models\Series;

use PDO;
use Throwable;
use Database;
use Webtoon\Service\Logger;

/**
 * SeriesSearch v3.1
 *
 * - Stateless (cache handled by middleware)
 * - Safe for Swoole coroutine
 * - MsgPack-first entity decoding
 * - Deterministic ranking
 */
final class SeriesSearch
{
    private const MIN_KEYWORD_LENGTH = 2;
    private const SEARCH_LIMIT       = 14;
    private const CANDIDATE_LIMIT    = 30;
    private const FALLBACK_THRESHOLD = 5;

    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    /**
     * Entry point (PURE FUNCTION)
     */
    public function execute(string $keyword, array $exclude = []): array
    {
        $keyword = trim($keyword);
        if (mb_strlen($keyword) < self::MIN_KEYWORD_LENGTH) {
            return [];
        }

        $naturalQuery = $this->buildNaturalQuery($keyword);
        $candidates   = $this->searchNatural($naturalQuery, $exclude);

        if (count($candidates) < self::FALLBACK_THRESHOLD) {
            $booleanQuery = $this->buildBooleanQuery($keyword);
            $fallbacks    = $this->searchBoolean($booleanQuery, $exclude);

            // Natural always wins
            foreach ($fallbacks as $id => $score) {
                $candidates[$id] ??= $score;
            }
        }

        return empty($candidates)
            ? []
            : $this->hydrateAndRank($candidates);
    }

    /* =====================================================
     * STAGE 1 — NATURAL SEARCH
     * ===================================================== */
    private function searchNatural(string $query, array $exclude): array
    {
        $pdo = $this->db->getConnection();
        $stmt = null;

        try {
            $params = [':q' => $query];
            $excludeSql = $this->buildExclude($exclude, $params);

            $stmt = $pdo->prepare(
                "SELECT series_id,
                        MATCH(name, description)
                        AGAINST (:q IN NATURAL LANGUAGE MODE) AS relevance
                 FROM series_summary
                 WHERE MATCH(name, description)
                       AGAINST (:q IN NATURAL LANGUAGE MODE)
                 $excludeSql
                 ORDER BY relevance DESC
                 LIMIT :limit"
            );

            $stmt->bindValue(':q', $query);
            $stmt->bindValue(':limit', self::CANDIDATE_LIMIT, PDO::PARAM_INT);

            foreach ($params as $k => $v) {
                if ($k !== ':q') {
                    $stmt->bindValue($k, $v, PDO::PARAM_INT);
                }
            }

            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];
        } catch (Throwable $e) {
            $this->logger->error($e, 'SeriesSearch|Natural');
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }

    /* =====================================================
     * STAGE 3 — BOOLEAN FALLBACK
     * ===================================================== */
    private function searchBoolean(string $query, array $exclude): array
    {
        if ($query === '') {
            return [];
        }

        $pdo = $this->db->getConnection();
        $stmt = null;

        try {
            $params = [':q' => $query];
            $excludeSql = $this->buildExclude($exclude, $params);

            $stmt = $pdo->prepare(
                "SELECT series_id,
                        MATCH(name, description)
                        AGAINST (:q IN BOOLEAN MODE) AS relevance
                 FROM series_summary
                 WHERE MATCH(name, description)
                       AGAINST (:q IN BOOLEAN MODE)
                 $excludeSql
                 LIMIT 15"
            );

            $stmt->execute($params);

            return $stmt->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];
        } catch (Throwable $e) {
            $this->logger->error($e, 'SeriesSearch|Boolean');
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }

    /* =====================================================
     * STAGE 2 — HYDRATE & SCORE
     * ===================================================== */
    private function hydrateAndRank(array $candidates): array
    {
        $ids = array_keys($candidates);
        $in  = implode(',', array_fill(0, count($ids), '?'));

        $pdo = $this->db->getConnection();
        $stmt = null;

        try {
            $stmt = $pdo->prepare(
                "SELECT series_id, name, slug, cover_url,
                        entities_text,
                        chapters_count, views_count, bookmark_count, rating_average
                 FROM series_summary
                 WHERE series_id IN ($in)"
            );

            $stmt->execute($ids);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($rows as &$row) {
                $id = (int) $row['series_id'];

                $row['entities'] = $this->decodeEntities($row['entities_text'] ?? null);
                unset($row['entities_text']);

                $row['_score'] = $this->score(
                    (float) ($candidates[$id] ?? 0),
                    (int)   $row['bookmark_count'],
                    (int)   $row['views_count'],
                    (float) $row['rating_average']
                );
            }
            unset($row);

            usort($rows, static fn($a, $b) => $b['_score'] <=> $a['_score']);

            return array_slice($rows, 0, self::SEARCH_LIMIT);
        } catch (Throwable $e) {
            $this->logger->error($e, 'SeriesSearch|Hydrate');
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }

    /* =====================================================
     * SCORING ENGINE (ISOLATED)
     * ===================================================== */
    private function score(
        float $match,
        int $bookmark,
        int $views,
        float $rating
    ): float {
        return
            ($match * 15.0)
            + log($bookmark + 1) * 2.0
            + log($views + 1)    * 1.0
            + ($rating * 0.5);
    }

    /* =====================================================
     * MSGPACK SAFE DECODER
     * ===================================================== */
    private function decodeEntities(?string $bin): array
    {
        if (!$bin) {
            return [];
        }

        try {
            $data = msgpack_unpack($bin);
            return is_array($data) ? ($data['entities'] ?? []) : [];
        } catch (Throwable) {
            return [];
        }
    }

    /* =====================================================
     * QUERY BUILDERS
     * ===================================================== */
    private function buildNaturalQuery(string $text): string
    {
        $text = mb_strtolower($text);
        return trim((string) preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $text));
    }

    private function buildBooleanQuery(string $text): string
    {
        $text  = mb_strtolower($text);
        $clean = preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $text);
        $words = preg_split('/\s+/', (string) $clean, -1, PREG_SPLIT_NO_EMPTY);

        if (!$words) {
            return '';
        }

        $tokens = [];
        foreach ($words as $w) {
            $tokens[] = mb_strlen($w) >= 3 ? $w . '*' : $w;
        }

        if (count($words) >= 2) {
            $tokens[] = '("' . implode(' ', $words) . '")';
        }

        return implode(' ', $tokens);
    }

    private function buildExclude(array $exclude, array &$params): string
    {
        if (!$exclude) {
            return '';
        }

        $placeholders = [];
        foreach (array_values($exclude) as $i => $id) {
            $key = ":ex_$i";
            $params[$key] = (int) $id;
            $placeholders[] = $key;
        }

        return ' AND series_id NOT IN (' . implode(',', $placeholders) . ')';
    }
}
