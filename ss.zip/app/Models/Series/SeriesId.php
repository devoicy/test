<?php
declare(strict_types=1);

namespace Webtoon\Models\Series;

use Database;
use PDO;
use Webtoon\Service\Logger;

/**
 * SeriesSummaryBySlug — Fetch detail satu series secara efisien
 * Pure read dari tabel denormalisasi (Zero Join).
 */
final class SeriesId
{
    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    public function execute(int $id): ?array
    {
        $pdo = $this->db->getConnection(); 
        $stmt = null;

        try {
            $stmt = $pdo->prepare("
                SELECT 
                    id, slug
                FROM series
                WHERE id = :id
                LIMIT 1
            ");
            
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            // Explicitly use FETCH_ASSOC
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$data) {
                return null;
            }

            return $data;

        } catch (\Throwable $e) {
            $this->logger->error($e, 'SeriesId|execute');
            return null;
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }
    }
}