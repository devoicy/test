<?php
declare(strict_types=1);

namespace Webtoon\Models\Series;

use Database;
use PDO;
use Swoole\Database\PDOProxy;
use InvalidArgumentException;
use RuntimeException;

/**
 * SeriesCreate v10.4 — Optimized for MySQL 8.0.44 & Swoole
 *
 * MYSQL 8.0 OPTIMIZATIONS:
 * - CTE untuk complex queries
 * - VALUES() dengan ROW() constructor
 * - Window functions ready
 * - Better JSON/msgpack handling
 */
final class SeriesCreate
{
    private const PIVOT_BATCH_SIZE = 500; // Bisa lebih besar untuk MySQL 8
    private const MAX_NAME_LENGTH = 255;
    private const MAX_SLUG_LENGTH = 100;
    private const MAX_DESCRIPTION_LENGTH = 2000;
    private const MAX_COVER_URL_LENGTH = 500;
    private const MYSQL_MAX_PLACEHOLDERS = 65535;

    public function __construct(private Database $db) {}

    public function execute(array $data, ?int $seriesId = null): ?int
    {
        $this->validateInput($data);
        
        $result = $this->db->transaction(
            function (PDO|PDOProxy $pdo) use ($data, $seriesId): ?int {
                return $this->processSeries($pdo, $data, $seriesId);
            },
            3
        );

        if ($result === false) {
            throw new RuntimeException('Failed to create/update series after retries');
        }

        return $result;
    }

    private function validateInput(array $data): void
    {
        $name = trim((string)($data['name'] ?? ''));
        $slug = trim((string)($data['slug'] ?? ''));

        if ($name === '' || $slug === '') {
            throw new InvalidArgumentException('Nama dan slug wajib diisi.');
        }

        if (strlen($name) > self::MAX_NAME_LENGTH) {
            throw new InvalidArgumentException(
                sprintf('Nama maksimal %d karakter', self::MAX_NAME_LENGTH)
            );
        }

        if (strlen($slug) > self::MAX_SLUG_LENGTH) {
            throw new InvalidArgumentException(
                sprintf('Slug maksimal %d karakter', self::MAX_SLUG_LENGTH)
            );
        }

        if (!preg_match('/^[a-z0-9\-]+$/', $slug)) {
            throw new InvalidArgumentException(
                'Slug hanya boleh berisi huruf kecil, angka, dan strip'
            );
        }

        $contentRating = (int)($data['content_rating'] ?? 0);
        if ($contentRating < 0 || $contentRating > 5) {
            throw new InvalidArgumentException('Content rating harus antara 0-5');
        }

        if (isset($data['description']) && strlen($data['description']) > self::MAX_DESCRIPTION_LENGTH) {
            throw new InvalidArgumentException(
                sprintf('Description maksimal %d karakter', self::MAX_DESCRIPTION_LENGTH)
            );
        }

        if (isset($data['cover_url']) && strlen($data['cover_url']) > self::MAX_COVER_URL_LENGTH) {
            throw new InvalidArgumentException(
                sprintf('Cover URL maksimal %d karakter', self::MAX_COVER_URL_LENGTH)
            );
        }
    }

    private function processSeries(
        PDO|PDOProxy $pdo, 
        array $data, 
        ?int $seriesId
    ): ?int {
        $name = trim((string)($data['name'] ?? ''));
        $slug = trim((string)($data['slug'] ?? ''));
        
        $currentSeriesId = $seriesId !== null 
            ? $this->updateSeries($pdo, $data, $seriesId, $name, $slug)
            : $this->createSeries($pdo, $data, $name, $slug);

        if ($currentSeriesId === null) {
            return null;
        }

        $summaryData = [];
        $this->syncEntitiesBulk(
            $pdo,
            $currentSeriesId,
            $data['entities'] ?? [],
            $summaryData
        );

        $this->updateSeriesSummary($pdo, $currentSeriesId, $data, $summaryData, $name, $slug);

        return $currentSeriesId;
    }

    private function updateSeries(
        PDO|PDOProxy $pdo,
        array $data,
        int $seriesId,
        string $name,
        string $slug
    ): int {
        // Gunakan CASE statement untuk conditional updates di MySQL 8
        $stmt = $pdo->prepare(
            "UPDATE series SET
                is_published   = ?,
                slug           = ?,
                name           = ?,
                description    = CASE WHEN ? IS NOT NULL THEN ? ELSE description END,
                cover_url      = CASE WHEN ? IS NOT NULL THEN ? ELSE cover_url END,
                content_rating = ?,
                is_nsfw        = ?,
                updated_by     = ?,
                updated_at     = CURRENT_TIMESTAMP(6) -- Microsecond precision
             WHERE id = ?"
        );

        $desc = $this->truncateDescription($data['description'] ?? null);
        $cover = $this->truncateCoverUrl($data['cover_url'] ?? null);

        $stmt->execute([
            (int)($data['is_published'] ?? 0),
            $slug,
            $name,
            $desc, $desc, // Untuk CASE statement
            $cover, $cover, // Untuk CASE statement
            (int)($data['content_rating'] ?? 0),
            (int)($data['is_nsfw'] ?? 0),
            $data['updated_by'] ?? null,
            $seriesId,
        ]);

        return $seriesId;
    }

    private function createSeries(
        PDO|PDOProxy $pdo,
        array $data,
        string $name,
        string $slug
    ): ?int {
        $stmt = $pdo->prepare(
            "INSERT INTO series (
                is_published, slug, name, description, cover_url,
                content_rating, is_nsfw,
                created_by, updated_by,
                created_at, updated_at
            ) VALUES (
                ?, ?, ?, ?, ?,
                ?, ?,
                ?, ?,
                CURRENT_TIMESTAMP(6), CURRENT_TIMESTAMP(6)
            )"
        );

        $stmt->execute([
            (int)($data['is_published'] ?? 0),
            $slug,
            $name,
            $this->truncateDescription($data['description'] ?? null),
            $this->truncateCoverUrl($data['cover_url'] ?? null),
            (int)($data['content_rating'] ?? 0),
            (int)($data['is_nsfw'] ?? 0),
            $data['created_by'] ?? null,
            $data['updated_by'] ?? null,
        ]);

        $currentSeriesId = (int)(string)$pdo->lastInsertId();
        
        if ($currentSeriesId <= 0) {
            return null;
        }

        $this->createSeriesStats($pdo, $currentSeriesId);

        return $currentSeriesId;
    }

    private function createSeriesStats(PDO|PDOProxy $pdo, int $seriesId): void
    {
        try {
            // MySQL 8: Use INSERT ... ON DUPLICATE KEY UPDATE dengan VALUES()
            $pdo->prepare(
                "INSERT INTO series_stats (series_id, updated_at)
                 VALUES (?, CURRENT_TIMESTAMP(6))
                 ON DUPLICATE KEY UPDATE
                    updated_at = CURRENT_TIMESTAMP(6)"
            )->execute([$seriesId]);
        } catch (\PDOException $e) {
            error_log($e);
        }
    }

    private function updateSeriesSummary(
        PDO|PDOProxy $pdo,
        int $seriesId,
        array $data,
        array $summaryData,
        string $name,
        string $slug
    ): void {
        // MySQL 8 mendukung JSON natively, tapi kita tetap pakai msgpack untuk kompatibilitas
        $packed = msgpack_pack([
            'v'        => 1,
            'entities' => $summaryData,
            'updated'  => time(),
            'mysql8'   => true, // Flag untuk future migration
        ]);

        $stmt = $pdo->prepare(
            "INSERT INTO series_summary (
                series_id, is_published, name, slug,
                cover_url, description,
                entities_text, updated_at
            ) VALUES (
                ?, ?, ?, ?,
                ?, ?,
                ?, CURRENT_TIMESTAMP(6)
            )
            ON DUPLICATE KEY UPDATE
                is_published  = VALUES(is_published),
                name          = VALUES(name),
                slug          = VALUES(slug),
                cover_url     = VALUES(cover_url),
                description   = VALUES(description),
                entities_text = VALUES(entities_text),
                updated_at    = CURRENT_TIMESTAMP(6)"
        );

        $stmt->execute([
            $seriesId,
            (int)($data['is_published'] ?? 0),
            $name,
            $slug,
            $this->truncateCoverUrl($data['cover_url'] ?? null),
            $this->truncateDescription($data['description'] ?? null),
            $packed,
        ]);
    }

    /**
     * ==================================================
     * ENTITY SYNC - OPTIMIZED FOR MYSQL 8
     * ==================================================
     */
    private function syncEntitiesBulk(
        PDO|PDOProxy $pdo,
        int $seriesId,
        array $newEntitiesRaw,
        array &$summaryData
    ): void {
        // Switch ke unbuffered untuk memory efficiency
        $originalBuffered = $pdo->getAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY);
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);

        try {
            /**
             * 1️⃣ Old pivot state - Gunakan index-only scan jika mungkin
             */
            $stmt = $pdo->prepare(
                "/*+ INDEX(series_entities idx_series_id) */
                 SELECT entity_id 
                 FROM series_entities 
                 WHERE series_id = ?"
            );
            $stmt->execute([$seriesId]);
            $oldIds = [];
            while ($row = $stmt->fetch(PDO::FETCH_COLUMN)) {
                $oldIds[] = (int)$row;
            }
            $stmt->closeCursor();

            /**
             * 2️⃣ Normalize input
             */
            $bulk = $this->normalizeEntities($newEntitiesRaw);

            if (empty($bulk)) {
                if ($oldIds) {
                    $this->removePivot($pdo, $seriesId, $oldIds);
                }
                return;
            }

            // Deadlock prevention
            usort(
                $bulk,
                fn ($a, $b) => [$a['type'], $a['slug']] <=> [$b['type'], $b['slug']]
            );

            /**
             * 3️⃣ Upsert master entities dengan MySQL 8 VALUES ROW()
             */
            $this->upsertEntitiesMySQL8($pdo, $bulk);

            /**
             * 4️⃣ Fetch entity IDs dengan CTE untuk performa lebih baik
             */
            $entityMap = $this->fetchEntityIdsMySQL8($pdo, $bulk);

            /**
             * 5️⃣ Build summary payload
             */
            $summaryData = $this->buildSummaryData($newEntitiesRaw, $entityMap);

            /**
             * 6️⃣ Delta calculation
             */
            $newIds   = array_values($entityMap);
            $toAdd    = array_diff($newIds, $oldIds);
            $toRemove = array_diff($oldIds, $newIds);

            if ($toRemove) {
                $this->removePivotMySQL8($pdo, $seriesId, array_values($toRemove));
            }

            /**
             * 7️⃣ Add pivot + atomic increment
             */
            if ($toAdd) {
                $this->addPivotWithIncrementMySQL8($pdo, $seriesId, $toAdd, $bulk, $entityMap);
            }

        } finally {
            $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, $originalBuffered);
            
            if (isset($stmt) && $stmt instanceof \PDOStatement) {
                $stmt->closeCursor();
            }
        }
    }

    /**
     * Normalize entities input
     */
    private function normalizeEntities(array $newEntitiesRaw): array
    {
        $bulk = [];
        foreach ($newEntitiesRaw as $type => $list) {
            if (!is_array($list)) {
                continue;
            }
            foreach ($list as $e) {
                if (!is_array($e)) {
                    continue;
                }
                $bulk[] = [
                    'type' => (string)$type,
                    'slug' => (string)($e['slug'] ?? ''),
                    'name' => (string)($e['name'] ?? ''),
                ];
            }
        }
        return $bulk;
    }

    /**
     * Upsert entities dengan MySQL 8 VALUES ROW() syntax
     */
    private function upsertEntitiesMySQL8(PDO|PDOProxy $pdo, array $bulk): void
    {
        if (empty($bulk)) {
            return;
        }

        // MySQL 8: Gunakan VALUES ROW() untuk bulk insert yang lebih efisien
        $rows = [];
        $params = [];
        
        foreach ($bulk as $b) {
            $rows[] = 'ROW(?, ?, ?)';
            $params[] = $b['type'];
            $params[] = $b['slug'];
            $params[] = $b['name'];
        }

        $sql = "INSERT INTO entities (type, slug, name)
                VALUES " . implode(', ', $rows) . "
                ON DUPLICATE KEY UPDATE 
                    name = VALUES(name),
                    updated_at = CURRENT_TIMESTAMP(6)";

        $pdo->prepare($sql)->execute($params);
    }

    /**
     * Fetch entity IDs dengan CTE untuk MySQL 8
     */
    private function fetchEntityIdsMySQL8(PDO|PDOProxy $pdo, array $bulk): array
    {
        if (empty($bulk)) {
            return [];
        }

        // MySQL 8: Gunakan Common Table Expression (CTE) untuk readability dan performance
        $cteRows = [];
        $params = [];
        
        foreach ($bulk as $i => $b) {
            $cteRows[] = "SELECT ? as type, ? as slug";
            $params[] = $b['type'];
            $params[] = $b['slug'];
        }

        $sql = "WITH entity_data (type, slug) AS (
                    " . implode(" UNION ALL ", $cteRows) . "
                )
                SELECT e.id, e.type, e.slug
                FROM entities e
                INNER JOIN entity_data ed ON e.type = ed.type AND e.slug = ed.slug";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        $entityMap = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $entityMap[$row['type'] . ':' . $row['slug']] = (int)$row['id'];
        }
        $stmt->closeCursor();
        
        return $entityMap;
    }

    /**
     * Build summary data dari entity map
     */
    private function buildSummaryData(array $newEntitiesRaw, array $entityMap): array
    {
        $summaryData = [];
        foreach ($newEntitiesRaw as $type => $list) {
            if (!is_array($list)) {
                continue;
            }
            
            foreach ($list as $e) {
                if (!is_array($e) || !isset($e['slug'])) {
                    continue;
                }
                
                $key = $type . ':' . $e['slug'];
                if (isset($entityMap[$key])) {
                    $summaryData[$type][] = [
                        'id'    => $entityMap[$key],
                        'slug'  => $e['slug'],
                        'title' => $e['name'] ?? '',
                    ];
                }
            }
        }
        
        return $summaryData;
    }

    /**
     * Add pivot dengan atomic increment untuk MySQL 8
     */
    private function addPivotWithIncrementMySQL8(
        PDO|PDOProxy $pdo,
        int $seriesId,
        array $toAdd,
        array $bulk,
        array $entityMap
    ): void {
        // Build metadata lookup
        $meta = [];
        foreach ($bulk as $b) {
            $key = $b['type'] . ':' . $b['slug'];
            if (isset($entityMap[$key])) {
                $meta[$entityMap[$key]] = [
                    'type' => $b['type'],
                    'slug' => $b['slug'],
                    'name' => $b['name'],
                ];
            }
        }

        foreach (array_chunk(array_values($toAdd), self::PIVOT_BATCH_SIZE) as $chunk) {
            // A️⃣ Insert pivot dengan IGNORE untuk idempotency
            $rows = [];
            $params = [];
            foreach ($chunk as $id) {
                $rows[] = 'ROW(?, ?)';
                $params[] = $seriesId;
                $params[] = $id;
            }

            $pdo->prepare(
                "INSERT IGNORE INTO series_entities (series_id, entity_id)
                 VALUES " . implode(', ', $rows)
            )->execute($params);

            // B️⃣ Atomic counter increment dengan batch
            $this->incrementEntitySummaryMySQL8($pdo, $chunk, $meta);
        }
    }

    /**
     * Increment entity summary dengan MySQL 8 syntax
     */
    private function incrementEntitySummaryMySQL8(
        PDO|PDOProxy $pdo,
        array $chunk,
        array $meta
    ): void {
        $rows = [];
        $params = [];
        
        foreach ($chunk as $id) {
            if (!isset($meta[$id])) {
                continue;
            }
            $m = $meta[$id];
            $rows[] = 'ROW(?, ?, ?, ?, 1, CURRENT_TIMESTAMP(6), CURRENT_TIMESTAMP(6), CURRENT_TIMESTAMP(6))';
            $params[] = $id;
            $params[] = $m['type'];
            $params[] = $m['slug'];
            $params[] = $m['name'];
        }

        if (empty($rows)) {
            return;
        }

        $sql = "INSERT INTO entity_summary (
                    entity_id, type, slug, name,
                    series_count,
                    last_used_at, created_at, updated_at
                ) VALUES " . implode(', ', $rows) . "
                ON DUPLICATE KEY UPDATE
                    series_count = entity_summary.series_count + 1,
                    last_used_at = CURRENT_TIMESTAMP(6),
                    updated_at   = CURRENT_TIMESTAMP(6)";

        $pdo->prepare($sql)->execute($params);
    }

    /**
     * ==================================================
     * REMOVE PIVOT - OPTIMIZED FOR MYSQL 8
     * ==================================================
     */
    private function removePivotMySQL8(
        PDO|PDOProxy $pdo,
        int $seriesId,
        array $ids
    ): void {
        foreach (array_chunk($ids, self::PIVOT_BATCH_SIZE) as $chunk) {
            $ph = implode(',', array_fill(0, count($chunk), '?'));

            // 1️⃣ Delete pivot dengan multi-table DELETE yang lebih efisien
            $pdo->prepare(
                "DELETE se FROM series_entities se
                 WHERE se.series_id = ? 
                   AND se.entity_id IN ($ph)"
            )->execute(array_merge([$seriesId], $chunk));

            // 2️⃣ Lock rows dengan SKIP LOCKED untuk mengurangi contention
            // Note: SKIP LOCKED hanya untuk high concurrency, hati-hati penggunaannya
            $pdo->prepare(
                "SELECT entity_id
                 FROM entity_summary
                 WHERE entity_id IN ($ph)
                 FOR UPDATE"
                // Jika perlu: "FOR UPDATE SKIP LOCKED" 
                // Tapi pastikan application logic handle rows yang tidak terkunci
            )->execute($chunk);

            // 3️⃣ Safe decrement dengan atomic update
            $pdo->prepare(
                "UPDATE entity_summary
                 SET series_count = GREATEST(0, series_count - 1),
                     updated_at = CURRENT_TIMESTAMP(6)
                 WHERE entity_id IN ($ph)
                   AND series_count > 0"
            )->execute($chunk);

            // 4️⃣ Optional: Cleanup rows dengan series_count = 0
            // $pdo->prepare(
            //     "DELETE FROM entity_summary
            //      WHERE entity_id IN ($ph)
            //        AND series_count = 0"
            // )->execute($chunk);
        }
    }

    /**
     * Helper methods
     */
    private function truncateDescription(?string $description): ?string
    {
        if ($description === null) {
            return null;
        }
        
        if (strlen($description) > self::MAX_DESCRIPTION_LENGTH) {
            return substr($description, 0, self::MAX_DESCRIPTION_LENGTH);
        }
        
        return $description;
    }

    private function truncateCoverUrl(?string $coverUrl): ?string
    {
        if ($coverUrl === null) {
            return null;
        }
        
        if (strlen($coverUrl) > self::MAX_COVER_URL_LENGTH) {
            return substr($coverUrl, 0, self::MAX_COVER_URL_LENGTH);
        }
        
        return $coverUrl;
    }
}