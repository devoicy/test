<?php
declare(strict_types=1);

namespace Webtoon\Models\Series;

use Database;
use PDO;
use Throwable;
use Bin;
use Webtoon\Service\Logger;

/**
 * SeriesSummaryLists v2 — Read Optimized
 * Menangani pagination via binary file dan hydration data dari DB.
 */
final class SeriesSummaryList
{
    public function __construct(
        private Database $db,
        private Bin $bin,
        private Logger $logger
    ) {}

    private function loadSeriesData(array $seriesIds): array
    {
        if (empty($seriesIds)) return [];

        // Tetap gunakan array_map intval untuk keamanan
        $safeIds = array_map('intval', $seriesIds);
        $placeholders = implode(',', array_fill(0, count($safeIds), '?'));

        $pdo = $this->db->getConnection();
        $stmt = null;

        try {
            /**
             * 🚨 FIX: Hapus alias 'st' karena chapters_count sudah ada di series_summary.
             * Tambahkan juga kolom stats lain jika dibutuhkan (views_count, rating_average).
             */
            $sql = "
                SELECT 
                    series_id, slug, name, cover_url, 
                    entities_text, 
                    chapters_count, views_count, rating_average
                FROM series_summary
                WHERE series_id IN ($placeholders)
            ";

            $stmt = $pdo->prepare($sql);
            
            // Execute dengan merge safeIds untuk WHERE IN dan ORDER BY FIELD
            $stmt->execute($safeIds);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            // ✅ BATCH UNPACK semua entities_text sekaligus
            $unpackedEntities = $this->batchUnpackEntities($results);
            
            // Index results
            $indexed = array_column($results, null, 'series_id');
            
            // Build ordered results dengan unpacked entities
            $ordered = [];
            foreach ($seriesIds as $id) {
                if (isset($indexed[$id])) {
                    $row = $indexed[$id];
                    
                    // Ambil hasil unpack dari batch
                    if (!empty($row['entities_text'])) {
                        $row['entities'] = $unpackedEntities[$row['series_id']] ?? [];
                    } else {
                        $row['entities'] = [];
                    }
                    
                    // Type casting
                    $row['series_id'] = (int)$row['series_id'];
                    $row['chapters_count'] = (int)$row['chapters_count'];
                    $row['views_count'] = (int)$row['views_count'];
                    $row['rating_average'] = (float)$row['rating_average'];
                    
                    unset($row['entities_text']);
                    $ordered[] = $row;
                }
            }
            
            return $ordered;

        } catch (Throwable $e) {
            $this->logger->error($e, 'SeriesSummaryLists|loadSeriesData');
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }

    public function execute(int $page = 1, int $perPage = 25): array
    {
        // Konstanta sesuai arsitektur bin lu
        $perFile = 2500; 
        $pagesPerFile = max(1, intdiv($perFile, $perPage));
        $fileNumber   = (int) ceil($page / $pagesPerFile);
        $relativePage = $page - (($fileNumber - 1) * $pagesPerFile);

        $dir = cacheDir('bin/series');
        $filePath = $dir . "/{$fileNumber}.bin";

        // Ambil list ID dari Binary Index
        $cache = $this->bin->readMsgPack($filePath);

        if (!$cache || !isset($cache[$relativePage])) {
            return $this->emptyResponse($page, $perPage);
        }

        $ids = $cache[$relativePage];
        $totalData = $this->bin->readMsgPack($dir . '/count.bin');
        $totalCount = $totalData['total'] ?? 0;

        return [
            'page'        => $page,
            'per_page'    => $perPage,
            'total_rows'  => $totalCount,
            'total_pages' => (int) ceil($totalCount / $perPage),
            'data'        => $this->loadSeriesData($ids),
        ];
    }

    private function emptyResponse(int $page, int $perPage): array
    {
        return [
            'page' => $page, 'per_page' => $perPage,
            'total_rows' => 0, 'total_pages' => 0, 'data' => []
        ];
    }


    /**
     * Batch unpack semua entities_text sekaligus
     * Mengurangi overhead per-call msgpack_unpack()
     */
    private function batchUnpackEntities(array $rows): array
    {
        $entities = [];
        $textsToUnpack = [];
        
        // Kumpulkan semua entities_text yang perlu di-unpack
        foreach ($rows as $row) {
            if (!empty($row['entities_text'])) {
                $textsToUnpack[$row['series_id']] = $row['entities_text'];
            }
        }
        
        // Jika tidak ada yang perlu unpack
        if (empty($textsToUnpack)) {
            return [];
        }
        
        // UNPACK SEMUA SEKALIGUS dalam loop tunggal
        foreach ($textsToUnpack as $seriesId => $packedText) {
            $unpacked = msgpack_unpack($packedText);
            $entities[$seriesId] = $unpacked['entities'] ?? [];
            
            // Free memory immediately
            unset($textsToUnpack[$seriesId]);
        }
        
        return $entities;
    }

}