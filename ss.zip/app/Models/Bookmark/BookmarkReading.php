<?php

namespace Webtoon\Models\Bookmark;

use Database;
use PDO;
use PDOException;
use Webtoon\Service\Logger;

class BookmarkReading
{

    public function __construct(
    	private Database $db,
    	private Logger $logger
    ){}

	public function execute(int $userId, int $seriesId, int $chapterId): void
	{

		$pdo = $this->db->getConnection(); 
        $stmt = null;
	    
	    try {
	        $sql = "INSERT INTO bookmarks (user_id, series_id, last_chapter_id, updated_at)
	                VALUES (:user_id, :series_id, :chapter_id, CURRENT_TIMESTAMP)
	                ON DUPLICATE KEY UPDATE 
	                    last_chapter_id = VALUES(last_chapter_id)";

	        $stmt = $pdo->prepare($sql);
			$stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
			$stmt->bindValue(':series_id', $seriesId, PDO::PARAM_INT);
			$stmt->bindValue(':chapter_id', $chapterId, PDO::PARAM_INT);
	        $stmt->execute();

	    } catch (PDOException $e) {
	        $this->logger->error($e->getMessage(), 'Models|BookmarkReading');
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }
	}

}