<?php

namespace Webtoon\Models\Bookmark;

use Database;
use PDO;
class BookmarkSeriesIdList
{

    public function __construct(private Database $db){}

    public function execute(int $userId): array
    {

        $pdo = $this->db->getConnection(); 
        $stmt = null;
        
        try {
            $sql = "SELECT series_id FROM bookmarks WHERE user_id = ? ORDER BY id DESC LIMIT 50";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$userId]);
            return $stmt->fetchAll(PDO::FETCH_COLUMN);            
        } catch (\Throwable $e) {
            error_log($e->getMessage());
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }


    }

}
