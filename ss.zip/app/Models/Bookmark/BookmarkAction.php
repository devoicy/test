<?php

namespace Webtoon\Models\Bookmark;

use Database;
use PDO;
use Swoole\Database\PDOProxy;
use Webtoon\Domains\BookmarkActionResult;

final class BookmarkAction
{
    /**
     * BookmarkAction menangani seluruh lifecycle bookmark:
     * - Toggle add / remove
     * - Menjaga konsistensi counter
     * - Aman terhadap concurrent request
     *
     * Catatan penting:
     * - Tidak menggunakan SELECT sebelum WRITE
     * - DB adalah single source of truth
     */
    public function __construct(
        private Database $db
    ) {}

    /**
     * Toggle bookmark untuk user & series.
     *
     * STRATEGI UTAMA (Delete-First Strategy):
     * 1. Coba DELETE bookmark
     *    - Jika kena row → berarti bookmark ADA → dihapus
     * 2. Jika DELETE tidak kena row
     *    - Coba INSERT bookmark
     *
     * Keuntungan strategi ini:
     * - Tidak ada TOCTOU bug
     * - Tidak perlu SELECT
     * - Aman di traffic tinggi
     *
     * @param int $userId   ID user yang melakukan aksi
     * @param int $seriesId ID series yang ditoggle
     *
     * @return BookmarkActionResult
     * - ADDED   → bookmark berhasil ditambahkan
     * - REMOVED → bookmark berhasil dihapus
     * - EXISTS  → bookmark sudah ada (race condition kalah)
     */
    public function execute(int $userId, int $seriesId): BookmarkActionResult
    {
        return $this->db->transaction(
            function (PDO|PDOProxy $pdo) use ($userId, $seriesId): BookmarkActionResult {

                /**
                 * STEP 1: DELETE FIRST
                 *
                 * Kenapa DELETE dulu?
                 * - DELETE langsung lock index target
                 * - Lebih murah dari SELECT
                 * - Aman dari race condition
                 */
                $stmt = $pdo->prepare(
                    'DELETE FROM bookmarks
                     WHERE user_id = ? AND series_id = ?'
                );
                $stmt->execute([$userId, $seriesId]);

                /**
                 * Jika DELETE berhasil:
                 * - Bookmark memang ada
                 * - Status akhir = REMOVED
                 */
                if ($stmt->rowCount() > 0) {

                    /**
                     * Kurangi bookmark_count
                     * GREATEST() mencegah nilai negatif
                     */
                    $pdo->prepare(
                        'UPDATE series_stats
                         SET bookmark_count = GREATEST(bookmark_count - 1, 0),
                         version = version + 1,
                         is_dirty = 1
                         WHERE series_id = ?'
                    )->execute([$seriesId]);

                    return BookmarkActionResult::REMOVED;
                }

                /**
                 * STEP 2: INSERT
                 *
                 * Jika DELETE tidak kena row:
                 * - Bookmark belum ada
                 * - Kita coba INSERT
                 */
                try {
                    $pdo->prepare(
                        'INSERT INTO bookmarks (user_id, series_id)
                         VALUES (?, ?)'
                    )->execute([$userId, $seriesId]);

                    /**
                     * Insert sukses → tambah counter
                     */
                    $pdo->prepare(
                        'UPDATE series_stats
                         SET bookmark_count = bookmark_count + 1,
                         version = version + 1,
                         is_dirty = 1
                         WHERE series_id = ?'
                    )->execute([$seriesId]);

                    return BookmarkActionResult::ADDED;

                } catch (\PDOException $e) {

                    /**
                     * SQLSTATE 23000 = UNIQUE constraint violation
                     *
                     * Artinya:
                     * - Request lain berhasil INSERT lebih dulu
                     * - State akhir bookmark = ADA
                     * - Counter tidak perlu diubah
                     */
                    if ($e->getCode() === '23000') {
                        return BookmarkActionResult::EXISTS;
                    }

                    /**
                     * Error lain (disk full, table corrupt, DB down)
                     * → Lempar ke atas agar transaction rollback
                     */
                    throw $e;
                }
            }
        );
    }

    /**
     * Mengecek apakah sebuah series sudah dibookmark oleh user.
     *
     * Fungsi ini:
     * - READ-ONLY
     * - Tidak dipakai dalam toggle
     * - Cocok untuk kebutuhan UI / preload state
     *
     * @param int $userId
     * @param int $seriesId
     * @return bool
     */
    public function isBookmarked(int $userId, int $seriesId): bool
    {
        $pdo = $this->db->getConnection();
        $stmt = null;
        try {
            /**
             * SELECT 1 adalah cara paling efisien
             * untuk cek keberadaan row
             */
            $stmt = $pdo->prepare(
                'SELECT 1
                 FROM bookmarks
                 WHERE user_id = ? AND series_id = ?
                 LIMIT 1'
            );
            $stmt->execute([$userId, $seriesId]);

            return $stmt->fetchColumn() !== false;

        } catch (\Throwable $e) {

            /**
             * Jika terjadi error:
             * - Jangan crash aplikasi
             * - UI cukup anggap "belum dibookmark"
             */
            error_log(sprintf(
                '[BookmarkAction::isBookmarked] user=%d series=%d error=%s',
                $userId,
                $seriesId,
                $e->getMessage()
            ));

            return false;

        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }
}
