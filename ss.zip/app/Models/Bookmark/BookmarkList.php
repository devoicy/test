<?php

namespace Webtoon\Models\Bookmark;

use Database;
use PDO;
use Webtoon\Traits\CursorTrait;

class BookmarkList
{
    use CursorTrait;

    public function __construct(private Database $db) {}

    public function execute(
        int $userId,
        ?string $cursor = null,
        int $limit = 20
    ): array {
        // Decode kursor: Sekarang kita butuh timestamp DAN id
        $decoded = $this->decodeCursor($cursor);
        $lastTimestamp = $decoded['updated_at'] ?? null;
        $lastId = $decoded['id'] ?? null;

        $cursorCondition = "";
        if ($lastTimestamp !== null && $lastId !== null) {
            // Logika: Ambil yang waktunya lebih lama, 
            // ATAU waktunya sama tapi ID-nya lebih kecil (untuk menangani waktu yang identik)
            $cursorCondition = "AND (b.updated_at < :lastTimestamp OR (b.updated_at = :lastTimestamp AND b.id < :lastId))";
        }

        $pdo = $this->db->getConnection();
        $stmt = null;
        
        try {
            $sql = "
                SELECT 
                    b.id AS bookmark_id,
                    b.user_id,
                    s.id AS series_id,
                    s.name AS series_name,
                    s.cover_url,
                    s.slug AS series_slug,
                    c.id AS chapter_id,
                    c.number AS chapter_number,
                    c.name AS chapter_name,
                    b.updated_at 
                FROM bookmarks b
                JOIN series s ON b.series_id = s.id
                LEFT JOIN chapters c ON b.last_chapter_id = c.id
                WHERE b.user_id = :userId
                {$cursorCondition}
                ORDER BY b.updated_at DESC, b.id DESC
                LIMIT :limit
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':userId', $userId, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit + 1, PDO::PARAM_INT);
            
            if ($lastTimestamp !== null && $lastId !== null) {
                $stmt->bindValue(':lastTimestamp', $lastTimestamp);
                $stmt->bindValue(':lastId', $lastId, PDO::PARAM_INT);
            }

            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $hasMore = false;
            $nextCursor = null;

            if (count($rows) > $limit) {
                $hasMore = true;
                // Buang elemen ke-21
                array_pop($rows);
                // Ambil data dari elemen terakhir yang sebenarnya (elemen ke-20)
                $lastItem = end($rows);
                $nextCursor = $this->encodeCursor([
                    'updated_at' => $lastItem['updated_at'],
                    'id' => $lastItem['bookmark_id']
                ]);
            }

            return [
                'data'     => $rows,
                'loadmore' => [
                    'next'     => $nextCursor,
                    'has_more' => $hasMore
                ]
            ];

        } catch (\Throwable $e) {
            error_log("BookmarkList Error: " . $e->getMessage());
            return ['data' => [], 'loadmore' => ['next' => null, 'has_more' => false]];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }
    }
}
