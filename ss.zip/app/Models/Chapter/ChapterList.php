<?php
declare(strict_types=1);

namespace Webtoon\Models\Chapter;

use Database;
use PDO;
use Throwable;
use Webtoon\Service\Logger;

final class ChapterList
{
    /**
     * Menggunakan Constant untuk mempermudah maintenance SQL
     */
    private const DEFAULT_LIMIT = 100;
    private const MAX_LIMIT = 100;

    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    /**
     * Developer Pro menggunakan type-hinting yang ketat dan dokumentasi yang jelas.
     * * @param int $seriesId
     * @param int $limit
     * @param bool $isAdmin
     * @return array[]
     */
    public function execute(int $seriesId, int $limit = self::DEFAULT_LIMIT, bool $isAdmin = false): array 
    {
        // 1. Sanitasi Input (Defensive Programming)
        $limit = max(1, min($limit, self::MAX_LIMIT));
        
        $pdo = $this->db->getConnection();
        
        try {
            // 2. Build Query dengan Clean Logic
            // Gunakan "1=1" agar penambahan kondisi WHERE lebih fleksibel di masa depan
            $conditions = ["series_id = :seriesId"];
            
            if (!$isAdmin) {
                $conditions[] = "is_published = 1";
            }

            $whereClause = "WHERE " . implode(" AND ", $conditions);

            $sql = "
                SELECT 
                    chapter_id, 
                    series_id, 
                    cover_url, 
                    name, 
                    number, 
                    created_at,
                    is_published,
                    COALESCE(views_count, 0) AS views
                FROM chapter_summary
                {$whereClause}
                ORDER BY number DESC
                LIMIT :limit
            ";

            $stmt = $pdo->prepare($sql);
            
            // 3. Bind Parameters (Mencegah SQL Injection)
            $stmt->bindValue(':seriesId', $seriesId, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);

            $stmt->execute();

            // 4. Fetch Strategy
            // Menggunakan FETCH_ASSOC secara eksplisit agar tidak boros memori (default PDO bisa ganda)
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        } catch (Throwable $e) {
            // 5. Contextual Logging
            // Jangan hanya pesan error, masukkan metadata yang berguna untuk debugging
            $this->logger->error($e->getMessage(), [
                'action' => 'FETCH_CHAPTER_LIST',
                'series_id' => $seriesId,
                'is_admin' => $isAdmin,
                'trace' => $e->getTraceAsString()
            ]);
            
            return [];
        } finally {
            // 6. Resource Management (Crucial for Swoole)
            // Pastikan koneksi dilepas kembali ke pool dalam kondisi apa pun
            if (isset($stmt)) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }
}