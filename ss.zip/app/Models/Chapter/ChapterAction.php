<?php

declare(strict_types=1);

namespace Webtoon\Models\Chapter;

use Database;
use PDO;
use PDOStatement;
use Swoole\Database\PDOStatementProxy;
use Throwable;
use Webtoon\Service\Logger;
use RuntimeException;
use InvalidArgumentException;

final class ChapterAction
{
    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    /**
     * @throws InvalidArgumentException
     * @throws RuntimeException
     */
    public function execute(array $data, ?int $chapterId = null): array
    {
        // Validasi & normalisasi input
        $clean = $this->validate($data);

        // Normalize chapter ID (hindari NULL ambiguity di SP)
        $chapterId = $chapterId ?? 0;

        $pdo = $this->db->getConnection(); 
        $stmt = null;
                
        try {
            $stmt = $pdo->prepare(
                "CALL sp_upsert_chapter(
                    :id, :sid, :num, :name, :pub, :cover, :uid, :cont
                )"
            );

            // Bind parameters
            $stmt->bindValue(':id', $chapterId, PDO::PARAM_INT);
            $stmt->bindValue(':sid', $clean['sid'], PDO::PARAM_INT);
            $stmt->bindValue(':num', $clean['num'], PDO::PARAM_STR);
            $stmt->bindValue(':name', $clean['name'], PDO::PARAM_STR);
            $stmt->bindValue(':pub', $clean['pub'], PDO::PARAM_INT);
            $stmt->bindValue(':uid', $clean['uid'], PDO::PARAM_INT);
            
            // Nullable parameters
            $stmt->bindValue(':cover', $clean['cover'], 
                $clean['cover'] !== null ? PDO::PARAM_STR : PDO::PARAM_NULL);
            $stmt->bindValue(':cont', $clean['cont'], 
                $clean['cont'] !== null ? PDO::PARAM_LOB : PDO::PARAM_NULL);

            // Execute
            $stmt->execute();

            // Collect all result sets
            $allResults = [];
            
            do {
                $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($resultSet)) {
                    $allResults[] = $resultSet;
                }
            } while ($stmt->nextRowset());

            // Cek apakah ada result
            if (empty($allResults)) {
                throw new RuntimeException('No result returned from stored procedure');
            }

            // Ambil result set terakhir (hasil utama)
            $finalResult = end($allResults);
            
            // Pastikan formatnya sesuai
            if (empty($finalResult)) {
                throw new RuntimeException('Empty final result from stored procedure');
            }

            // Return first row of final result set
            return $finalResult[0] ?? [];

        } catch (Throwable $e) {
            // Log dengan data yang valid
            $this->logger->error($e, 
                "ChapterAction_SP_Error|SID:{$clean['sid']}|UID:{$clean['uid']}"
            );
            
            // Re-throw untuk ditangani layer atas
            throw new RuntimeException(
                'Failed to upsert chapter: ' . $e->getMessage(),
                (int)$e->getCode(),
                $e
            );
            
        } finally {

            try {
                $stmt?->closeCursor();
            } catch (Throwable $e) {
                $this->logger->error($e, "closeCursor failed in ChapterAction");
            }

            $this->db->releaseConnection($pdo);
        }
    }

    /**
     * Validasi input mentah → data siap DB
     */
    private function validate(array $raw): array
    {
        if (empty($raw['series_id'])) {
            throw new InvalidArgumentException('Series ID wajib ada.');
        }

        $sid = (int)$raw['series_id'];
        if ($sid <= 0) {
            throw new InvalidArgumentException('Series ID tidak valid.');
        }

        if (!isset($raw['number'])) {
            throw new InvalidArgumentException('Nomor chapter wajib ada.');
        }

        // Validasi dan format number
        $num = (float)$raw['number'];
        if ($num <= 0) {
            throw new InvalidArgumentException('Nomor chapter harus positif.');
        }
        $numFormatted = number_format($num, 2, '.', '');

        // Validasi nama
        $name = trim((string)($raw['name'] ?? ''));
        if ($name === '') {
            throw new InvalidArgumentException('Nama chapter tidak boleh kosong.');
        }
        if (mb_strlen($name) > 255) {
            throw new InvalidArgumentException('Nama chapter maksimal 255 karakter.');
        }

        // Validasi user ID
        $uid = (int)($raw['created_by'] ?? 0);
        if ($uid <= 0) {
            throw new InvalidArgumentException('User ID tidak valid.');
        }

        // Validasi published status
        $pub = (int)($raw['is_published'] ?? 0);
        if (!in_array($pub, [0, 1], true)) {
            throw new InvalidArgumentException('Status published harus 0 atau 1.');
        }

        // Validasi cover URL (optional)
        $cover = isset($raw['cover_url']) ? trim((string)$raw['cover_url']) : null;
        if ($cover !== null && $cover === '') {
            $cover = null; // Convert empty string to null
        }

        // Validasi content (optional BLOB)
        $cont = $raw['content'] ?? null;
        if ($cont !== null && !is_string($cont)) {
            throw new InvalidArgumentException('Content harus berupa string/binary.');
        }

        return [
            'sid'   => $sid,
            'num'   => $numFormatted,
            'name'  => $name,
            'uid'   => $uid,
            'pub'   => $pub,
            'cover' => $cover,
            'cont'  => $cont,
        ];
    }

    /**
     * Helper untuk mendapatkan chapter ID dari result
     */
    public function extractChapterId(array $result): int
    {
        if (!isset($result['id']) || !is_numeric($result['id'])) {
            throw new RuntimeException('Invalid chapter ID in result');
        }
        
        return (int)$result['id'];
    }

    /**
     * Helper untuk mendapatkan operation type dari result
     */
    public function extractOperation(array $result): string
    {
        return $result['operation'] ?? 'unknown';
    }
}