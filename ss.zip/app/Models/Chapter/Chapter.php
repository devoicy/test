<?php

declare(strict_types=1);

namespace Webtoon\Models\Chapter;

use Database;
use PDO;
use Throwable;
use Webtoon\Service\Logger;

final class Chapter
{
    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

public function execute(int $chapterId, bool $isAdmin = false): array
{
    $pdo = $this->db->getConnection();
    $stmt = null;

    try {

        if($isAdmin) {
            $stmt = $pdo->prepare("
                SELECT 
                    c.id, 
                    c.name, 
                    c.number, 
                    c.is_published, 
                    c.cover_url,
                    ci.content -- Ini kolom BLOB-mu
                FROM chapters c
                LEFT JOIN chapter_images ci ON c.id = ci.chapter_id
                WHERE c.id = :id
                LIMIT 1
            ");
            
            $stmt->bindValue(':id', $chapterId, PDO::PARAM_INT);
            $stmt->execute();
            
            // Explicitly use FETCH_ASSOC
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$data) {
                return [];
            }

            return $data;
        } else {
            // Panggil SP - Cukup 1x Round-trip Network!
            $stmt = $pdo->prepare("CALL sp_get_chapter_reader_ultra_fast(?)");
            $stmt->execute([$chapterId]);

            // --- AMBIL DATA CHAPTER UTAMA ---

            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$row || empty($row['chapter_id'])) {
                return $this->emptyResult();
            }
            
            // Process binary content
            $images = $row['binary_content'] 
                ? $this->unpackContent($row['binary_content'])
                : [];
            
            return [
                'series' => [
                    'id' => (int)$row['series_id'],
                    'name' => $row['series_name'],
                    'slug' => $row['series_slug']
                ],
                'current' => [
                    'id' => (int)$row['chapter_id'],
                    'number' => $row['chapter_number'],
                    'name' => $row['chapter_name'],
                    'images' => $images
                ],
                'navigation' => [
                    'prev' => $row['prev_chapter_id'] ? [
                        'id' => (int)$row['prev_chapter_id'],
                        'number' => $row['prev_chapter_number']
                    ] : null,
                    'next' => $row['next_chapter_id'] ? [
                        'id' => (int)$row['next_chapter_id'],
                        'number' => $row['next_chapter_number']
                    ] : null
                ]
            ];
        }

    } catch (Throwable $e) {
        $this->logger->error($e, "READER_SP_ERROR | ID: $chapterId");
        return $this->emptyResult();
    } finally {
        if ($stmt) {
            $stmt->closeCursor();
            while ($stmt->nextRowset()); // Bersihkan semua sisa paket SP
        }
        $this->db->releaseConnection($pdo);
    }
}

    /**
     * Decode MessagePack jadi array URL gambar
     */
    private function unpackContent(?string $binary): ?array
    {
        if (!$binary) return [];
        
        try {
            
            return msgpack_unpack($binary);

        } catch (Throwable) {
            return [];
        }
    }

    private function fetchOne($pdo, string $sql, array $params): ?array
    {
        $stmt = $pdo->prepare($sql);
        foreach ($params as $key => [$val, $type]) {
            $stmt->bindValue($key, $val, $type);
        }
        $stmt->execute();
        $rows = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        $stmt->closeCursor();
        return $rows;
    }

    private function fetchAll($pdo, string $sql, array $params): array
    {
        $stmt = $pdo->prepare($sql);
        foreach ($params as $key => [$val, $type]) {
            $stmt->bindValue($key, $val, $type);
        }
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $stmt->closeCursor();
        return $rows;
    }

    private function emptyResult(): array
    {
        return [
            'series' => null, 
            'current' => null, 
            'navigation' => null
        ];
    }
}