<?php
namespace Webtoon\Models\Entity;

use Database;
use Bin;

final class Entity
{

    public function __construct(
        private Database $db,
        private Bin $bin
    ){}

    /**
     * Hitung jumlah halaman per file
     */
    private function getPagesPerFile(int $perFile, int $perPage): int
    {
        return intdiv($perFile, $perPage);
    }

    /**
     * Hitung nomor file berdasarkan halaman
     */
    private function getFileNumber(int $page, int $pagesPerFile): int
    {
        return (int) ceil($page / $pagesPerFile);
    }

    /**
     * Hitung halaman relatif dalam file
     */
    private function getRelativePage(int $page, int $fileNumber, int $pagesPerFile): int
    {
        return (int) ($page - (($fileNumber - 1) * $pagesPerFile));
    }

    public function execute(
        string $type,
        int $page = 1,
        int $perFile = 10000,
        int $perPage = 100,
    ) {

        $pagesPerFile = $this->getPagesPerFile($perFile, $perPage);
        $fileNumber   = $this->getFileNumber($page, $pagesPerFile);
        $relativePage = $this->getRelativePage($page, $fileNumber, $pagesPerFile);
        $path = cacheDir("bin/entity/list/{$type}")."/{$fileNumber}.bin";

        $cache = $this->bin->readMsgPack($path);

        if(!$cache) return [];
        $ids = $cache['data'][$relativePage] ?? [];

        $totalRows = (int)($cache['meta']['total'] ?? 0);

        $data = $this->fetchEntityByIds($ids);

        $array = [
            'entity'      => ['type' => $type, 'title' => $type],
            'page'        => $page,
            'per_page'    => $perPage,
            'total_rows'  => $totalRows,
            'total_pages' => $perPage ? (int) ceil($totalRows / $perPage) : 0,
            'data'        => $data
        ];

        return $array;

    }

    protected function fetchEntityByIds(array $ids): array
    {
        // Bersihkan input
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if (empty($ids)) return [];

        // Placeholder aman: ?,?,?
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $pdo = $this->db->getConnection();
        $stmt = null;

        try {

	        $sql = "
	            SELECT type, entity_id, slug, name, series_count
	            FROM entity_summary
	            WHERE entity_id IN ($placeholders)
	        ";

	        $stmt = $pdo->prepare($sql);
	        $stmt->execute($ids);

	        return $stmt->fetchAll();

        } catch (\Throwable $e) {
            error_log($e->getMessage());
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }
    }


}
