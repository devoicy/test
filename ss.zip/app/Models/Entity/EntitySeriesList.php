<?php
declare(strict_types=1);

namespace Webtoon\Models\Entity;

use Database;
use Bin;
use PDO;

final class EntitySeriesList
{
    public function __construct(
        private Database $db,
        private Bin $bin
    ) {}

    // =====================================================
    // PUBLIC API
    // =====================================================
    public function execute(
        int $page = 1,
        int $id,
        string $type,
        string $slug,
        int $perPage = 25
    ): array {

        if (!$type || !$id || !$slug || $page < 1) {
            return [];
        }

        // ===============================
        // 2. PAGING CALC
        // ===============================
        $pagesPerFile = 100;
        $perFile      = $perPage * $pagesPerFile;

        $fileNumber   = (int)ceil($page / $pagesPerFile);
        $relativePage = (int)(($page - 1) % $pagesPerFile) + 1;

        // ===============================
        // 3. LOAD PAGE DATA
        // ===============================
        $shard = sprintf('%02x', $id & 0xff);

        $listFile = cacheDir("bin/entity/data/{$type}/{$shard}/{$slug}")."/{$fileNumber}.bin";
        $listData = $this->bin->readMsgPack($listFile);

        if (empty($listData['data']) || empty($listData['data'][$relativePage])) {
            return [];
        }

        $seriesIds = $listData['data'][$relativePage];

        // ===============================
        // 4. COUNT
        // ===============================

        $totalRows = (int)($listData['meta']['total'] ?? 0);

        // ===============================
        // 5. FETCH SERIES
        // ===============================
        $series = $this->fetchSeriesByIds($seriesIds);
        return [
            'entity' => [
                'id'    => $id,
                'type'  => $type,
                'slug'  => $slug,
                'title' => $listData['meta']['title'],
            ],
            'page'        => $page,
            'per_page'    => $perPage,
            'total_rows'  => $totalRows,
            'total_pages' => (int)ceil($totalRows / $perPage),
            'data'        => $series,
        ];
    }

    // =====================================================
    // INDEX
    // =====================================================
    private function batchUnpackEntities(array $rows): array
    {
        $entities = [];
        $textsToUnpack = [];
        
        // Kumpulkan semua entities_text yang perlu di-unpack
        foreach ($rows as $row) {
            if (!empty($row['entities_text'])) {
                $textsToUnpack[$row['series_id']] = $row['entities_text'];
            }
        }
        
        // Jika tidak ada yang perlu unpack
        if (empty($textsToUnpack)) {
            return [];
        }
        
        // UNPACK SEMUA SEKALIGUS dalam loop tunggal
        foreach ($textsToUnpack as $seriesId => $packedText) {
            $unpacked = msgpack_unpack($packedText);
            $entities[$seriesId] = $unpacked['entities'] ?? [];
            
            // Free memory immediately
            unset($textsToUnpack[$seriesId]);
        }
        
        return $entities;
    }

    // =====================================================
    // DB FETCH
    // =====================================================
    private function fetchSeriesByIds(array $seriesIds): array
    {

        $safeIds = array_map('intval', $seriesIds);
        $placeholders = implode(',', array_fill(0, count($safeIds), '?'));

        $pdo = $this->db->getConnection();
        $stmt = null;
        try {
            $stmt = $pdo->prepare(
                "
                SELECT 
                    series_id, slug, name, cover_url, 
                    entities_text, 
                    chapters_count, views_count, rating_average
                FROM series_summary
                WHERE series_id IN ($placeholders)
                "
            );

            $stmt->execute($safeIds);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            // ✅ BATCH UNPACK semua entities_text sekaligus
            $unpackedEntities = $this->batchUnpackEntities($results);
            
            // Index results
            $indexed = array_column($results, null, 'series_id');
            
            // Build ordered results dengan unpacked entities
            $ordered = [];
            foreach ($seriesIds as $id) {
                if (isset($indexed[$id])) {
                    $row = $indexed[$id];
                    
                    // Ambil hasil unpack dari batch
                    if (!empty($row['entities_text'])) {
                        $row['entities'] = $unpackedEntities[$row['series_id']] ?? [];
                    } else {
                        $row['entities'] = [];
                    }
                    
                    // Type casting
                    $row['series_id'] = (int)$row['series_id'];
                    $row['chapters_count'] = (int)$row['chapters_count'];
                    $row['views_count'] = (int)$row['views_count'];
                    $row['rating_average'] = (float)$row['rating_average'];
                    
                    unset($row['entities_text']);
                    $ordered[] = $row;
                }
            }
            return $ordered;

        } catch (\Throwable $e) {
            error_log($e->getMessage());
            return [];

        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }
}
