<?php

namespace Webtoon\Models\Review;

use Database;
use PDO;
use Throwable;
use Swoole\Database\PDOProxy;
use Webtoon\Service\Logger;

final class ReviewAction
{
    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    public function execute(array $data)
    {
        $sid     = max(0, (int)($data['series_id'] ?? 0));
        $uid     = max(0, (int)($data['user_id'] ?? 0));
        $rating  = (int)($data['rating'] ?? 0);
        $comment = trim((string)($data['comment'] ?? ''));

        // Validasi tetep di PHP biar cepet (Fast Fail)
        if ($sid === 0 || $uid === 0 || $rating < 1 || $rating > 5) {
            return false;
        }

        $pdo = $this->db->getConnection(); 
        $stmt = null;
                
        try {
            // Panggil SP
            $stmt = $pdo->prepare("CALL sp_upsert_review(:sid, :uid, :rat, :com)");
            
            // 1. Eksekusi
            $stmt->execute([
                ':sid' => $sid,
                ':uid' => $uid,
                ':rat' => $rating,
                ':com' => $comment
            ]);

            // 2. Ambil data yang lo butuhin (Result Set Pertama)
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 3. SELESAIKAN pengambilan data utama dulu
            return $result['id'];

        } catch (Throwable $e) {
            
            $this->logger->error($e, "ReviewAction_SP_Error|SID:{$sid}|UID:{$uid}");

        }  finally {

            if ($stmt) {
                // 4. Tutup kursor aktif (memberitahu driver kita selesai dengan set yang ini)
                $stmt->closeCursor();

                // 5. BERSIHKAN sisa paket (Next Rowsets) 
                // Ini dilakukan SETELAH closeCursor untuk membuang paket status/result set lainnya
                while ($stmt->nextRowset()) {
                    // Kosongkan
                }
            }
            
            // 6. Balikin koneksi ke pool
            $this->db->releaseConnection($pdo);

        }

    }
}