<?php

namespace Webtoon\Models\Review;

// Pastikan class Database (Pool Manager) sudah di-import
use Database; 
use Webtoon\Service\Logger;

class ReviewList
{

    public function __construct
    (
        private Database $db,
        private Logger $logger
    ){}
    /**
     * Mengambil daftar review untuk suatu series, mengutamakan review milik user yang sedang login.
     *
     * @param int $seriesId ID dari series.
     * @param int|null $userId ID user yang sedang login (opsional).
     * @return array Daftar review.
     */
    public function execute(int $seriesId, ?int $userId = null)
    {
        // Tentukan nilai User ID yang akan di-bind.
        // Jika $userId adalah null (user tidak login), gunakan nilai -1.
        // Nilai -1 digunakan agar perbandingan dalam SQL menjadi FALSE/0, 
        // bukan NULL, jika sr.user_id diasumsikan selalu positif.
        $boundUserId = $userId ?? -1;
        $pdo = $this->db->getConnection();
        $stmt = null;
        
        try
        {

            $sql = "
                SELECT 
                    sr.rating,
                    sr.comment,
                    sr.total_votes,
                    sr.updated_at,

                    -- Penanda review milik user
                    -- Jika user tidak login, :user_id adalah -1, sehingga perbandingan aman menghasilkan 0/FALSE.
                    (sr.user_id = :user_id) AS is_user_review,

                    -- Data user
                    u.username,
                    up.display_name,
                    up.avatar_url

                FROM series_reviews sr
                INNER JOIN users u         ON u.id = sr.user_id
                LEFT JOIN user_profiles up ON up.user_id = sr.user_id

                WHERE sr.series_id = :series_id

                ORDER BY 
                    is_user_review DESC,       -- review user dulu
                    sr.id DESC         -- baru review lain
                LIMIT 10
            ";
            $stmt = $pdo->prepare($sql);
            
            // Melakukan binding dengan nilai yang sudah diproses ($boundUserId)
            $stmt->execute([
                ':series_id' => $seriesId,
                ':user_id'   => $boundUserId
            ]);
            
            // FETCH_ASSOC sudah di seting diconfig
            return $stmt->fetchAll();

        } catch (Throwable $e) {
            error_log('[ReviewLists][Stage1] ' . $e->getMessage());
            return [];
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo);
        }
    }

}