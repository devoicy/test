<?php

namespace Webtoon\Models\Auth;

use Database;

class UserDeleteToken
{

    private $db;

    // Type Hinting bersih yang kita bahas sebelumnya
    public function __construct(Database $db) 
    {
        $this->db = $db;

    }

	public function execute($token)
	{

		$pdo = $this->db->getConnection(); 

		try{
			$stmt = $pdo->prepare("DELETE FROM user_tokens WHERE token = ?");
			return $stmt->execute([$token]);
        } catch (\Throwable $e) {
            error_log($e->getMessage());
        } finally {
            $this->db->releaseConnection($pdo); 
        }

	}

}