<?php

namespace Webtoon\Models\Auth;

use Database; // Import class Database Pool kamu!
use PDO;
use Swoole\Database\PDOProxy;

class UserCreate
{
    private Database $db;

    // Injeksi object Database Pool saat class ini dibuat
    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    public function execute(object $userinfo, array $refreshToken): ?array
    {
        // Panggil method transaction dari class Database Pool kamu
        $result = $this->db->transaction(function (PDO|PDOProxy $pdo) use ($userinfo, $refreshToken) 
        {

            // --- 1. INSERT INTO users ---
            //$password = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);
            $password = random_int(5, 5);
                            
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password)
                VALUES (?, ?, ?)
            ");
                            
            $success = $stmt->execute([$userinfo->id, $userinfo->email, $password]);
            if (!$success) return false;
            $user_id = (int)$pdo->lastInsertId();
            if (!$user_id) return false;
            // --- 2. INSERT INTO user_profiles ---
            $stmt = $pdo->prepare("
                INSERT INTO user_profiles (user_id, display_name, avatar_url)
                VALUES (?, ?, ?)
            ");
            $success = $stmt->execute([$user_id, $userinfo->name, $userinfo->picture]);
            if (!$success) return false;
            // --- 3. INSERT INTO user_summaries ---
            $stmt = $pdo->prepare("INSERT INTO user_summaries (user_id) VALUES (?)");
            $success = $stmt->execute([$user_id]);
            if (!$success) return false;
            // --- 4. INSERT/UPDATE INTO user_tokens ---
            $stmt = $pdo->prepare("
                INSERT INTO user_tokens (user_id, token, expires_at)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE token = VALUES(token), expires_at = VALUES(expires_at)
            ");

            $success = $stmt->execute([$user_id, $refreshToken['token'], $refreshToken['expires']]);
            if (!$success) return false;

            return [
                'id' => $user_id,
                'role' => 'reader'
            ]; // Semua berhasil

        });

        return $result ? $result : null;
    }
}