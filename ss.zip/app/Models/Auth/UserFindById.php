<?php

namespace Webtoon\Models\Auth;

use Database;

class UserFindById
{

    private $db;

    // Type Hinting bersih yang kita bahas sebelumnya
    public function __construct(Database $db) 
    {
        $this->db = $db;

    }

	public function execute($userId)
    {

		$pdo = $this->db->getConnection(); 
        $stmt = null;

		try {
			$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
			$stmt->execute([$userId]);
			return $stmt->fetch();
        } catch (\Throwable $e) {
            error_log($e->getMessage());
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }

    }

}