<?php

namespace Webtoon\Models\Auth;

use Database;

class UserCreateRefreshToken
{

    private $db;

    // Type Hinting bersih yang kita bahas sebelumnya
    public function __construct(Database $db) 
    {
        $this->db = $db;

    }

    public function execute($userId, $token, $expires)
    {

        $pdo = $this->db->getConnection(); 
        
        try {

            $stmt = $pdo->prepare("
                INSERT INTO user_tokens (user_id, token, expires_at)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE token = VALUES(token), expires_at = VALUES(expires_at)
            ");

            return $stmt->execute([$userId, $token, $expires]);

        } catch (\Throwable $e) {
            error_log($e->getMessage());
        } finally {
            $this->db->releaseConnection($pdo); 
        }

    }

}