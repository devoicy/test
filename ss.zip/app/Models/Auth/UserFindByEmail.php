<?php

namespace Webtoon\Models\Auth;

use Database;

class UserFindByEmail
{

    private $db;

    // Type Hinting bersih yang kita bahas sebelumnya
    public function __construct(Database $db) 
    {
        $this->db = $db;

    }

    public function execute(string $email)
    {

        $pdo = $this->db->getConnection();
        $stmt = null;
        $users = null;

        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $users = $stmt->fetch();            
        } catch (\Throwable $e) {
            error_log($e->getMessage());
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }

        return $users;

    }

}