<?php

namespace Webtoon\Models\Auth;

use Database;

class UserGetToken
{

    private $db;

    // Type Hinting bersih yang kita bahas sebelumnya
    public function __construct(Database $db) 
    {
        $this->db = $db;

    }

    public function execute($token)
    {

        $pdo = $this->db->getConnection(); 
        $stmt = null;

        try {
            $stmt = $pdo->prepare("
                SELECT user_id, expires_at 
                FROM user_tokens 
                WHERE token = ? 
                LIMIT 1
            ");
            $stmt->execute([$token]);
            return $stmt->fetch(\PDO::FETCH_ASSOC);
        } catch (\Throwable $e) {
            error_log($e->getMessage());
        } finally {
            if($stmt) {
                $stmt->closeCursor();
            }
            $this->db->releaseConnection($pdo); 
        }

    }
    

}