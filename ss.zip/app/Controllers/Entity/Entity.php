<?php

namespace Webtoon\Controllers\Entity;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Entity\Entity as Model;
use Twig\Environment; // Import class Twig
use Webtoon\Config;

final class Entity
{
    
    public function __construct(
    	private Model $entity,
    	private Environment $twig,
        private readonly Config $config
    ){}

    public function execute(Request $request, Response $response, array $args)
    {
        $config = $this->config->get('site');
        $page = max(1, (int)($request->get['page'] ?? 1));
        $path = parse_url($request->server['request_uri'], PHP_URL_PATH);

        $series = $this->entity->execute(
            page: $page,
            type: str_replace('/', '', $path)
        );

        if(!isset($series['data'])) {
            $response->status(404);
            return $this->twig->render('error.html', [
                'code'=>404,
                'path' => $path,
                'title' => '404',
                'message'=>'Not found'
            ]);
        }

        $series['site_url'] = $config['url'];
        $series['site_title'] = $config['title'];
        $series['site_page'] = $page;
        $series['url'] = $config['url'] . $path;

        return $this->twig->render('entity.html', $series);
    }

}