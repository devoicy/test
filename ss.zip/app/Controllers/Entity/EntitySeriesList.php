<?php

namespace Webtoon\Controllers\Entity;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Entity\EntitySeriesList as Model;
use Twig\Environment; // Import class Twig
use Webtoon\Config;

final class EntitySeriesList
{
    
    public function __construct(
    	private Model $entitySeriesList,
    	private Environment $twig,
        private Config $config
    ){}

    public function execute(Request $request, Response $response, array $args)
    {
        $config = $this->config->get('site');
        $page = max(1, (int)($request->get['page'] ?? 1));
        $path = parse_url($request->server['request_uri'], PHP_URL_PATH);

        $series = $this->entitySeriesList->execute(
            page: $page,
            id: $args['entityId'],
            type: $args['entityType'],
            slug: $args['entitySlug']
        );

        if(!isset($series['data'])) {
            $response->status(404);
            return $this->twig->render('error.html', [
                'code'=>404,
                'path' => $path,
                'title' => '404',
                'message'=>'Not found'
            ]);
        }

        $series['site_url'] = $config['url'];
        $series['site_title'] = $config['title'];
        $series['url'] = $config['url'] . $path; // URL absolut halaman ini
        return $this->twig->render('listsbyentity.html', $series);
    }

}