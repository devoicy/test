<?php

namespace Webtoon\Controllers\Bookmark;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Twig\Environment as TwigEnvironment; // Import class Twig

final class Bookmark
{

    public function __construct(private TwigEnvironment $twig){}

    public function execute(Request $request, Response $response, array $args)
    {
    	return $this->twig->render('bookmark.html', []);
    }

}