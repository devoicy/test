<?php

namespace Webtoon\Controllers\Bookmark;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Bookmark\BookmarkSeriesIdList as Model;
use Webtoon\Service\eJWT;
use Webtoon\ApiResponse;

final class BookmarkSeriesIdList
{
    public function __construct(
        private Model $bookmarkSeriesIdList,
        private eJWT $jwt,
        private ApiResponse $apiResponse
    ) {}

    public function execute(Request $request, Response $response, array $args)
    {
        // Defensive: cookie mungkin tidak ada
        $token = $request->cookie['xtoon'] ?? null;

        if (!$token) {
            return $this->apiResponse->message($response, 'Unauthorized', 401);
        }

        $user = $this->jwt->getPayload($token);

        // Defensive: payload wajib object + punya id
        if (!$user || !isset($user->id)) {
            return $this->apiResponse->message($response, 'Invalid session', 401);
        }

        $series = $this->bookmarkSeriesIdList->execute((int) $user->id);

        return $this->apiResponse->data($response, $series);
    }
}
