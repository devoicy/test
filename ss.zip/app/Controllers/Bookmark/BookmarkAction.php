<?php

namespace Webtoon\Controllers\Bookmark;

use App;
use Webtoon\Models\Bookmark\BookmarkAction as Model;
use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Service\eJWT;
use Webtoon\ApiResponse;
use Webtoon\Domains\BookmarkActionResult;

class BookmarkAction
{

    public function __construct(
        private Model $bookmarkAction,
        private eJWT $jwt,
        private ApiResponse $apiResponse
    ){}

    /**
     * POST /api/favorites/toggle
     * Body: { "seriesId": 123 }
     */
    public function execute(Request $request, Response $response)
    {
        // Defensive: cookie mungkin tidak ada
        $token = $request->cookie['xtoon'] ?? null;
        $series = $request->rawContent() ? json_decode($request->rawContent())->seriesId : null;

        if (!$token) {
            return $this->apiResponse->message($response, 'Unauthorized', 401);
        }

        $user = $this->jwt->getPayload($token);

        // Defensive: payload wajib object + punya id
        if (!$user || !isset($user->id)) {
            return $this->apiResponse->message($response, 'Invalid session', 401);
        }

        if (!$series) {
            return $this->apiResponse->message($response, 'Missing', 400);
        }

        // --- ANTI SPAM (THROTTLING) ---
        $key = "book:{$user->id}";
        $now = time();
        $limit = 10; 
        $last = App::$spamTable->get($key);

        if ($last && ($now - $last['last_action']) < $limit) {
            $sisa = $limit - ($now - $last['last_action']);
            return $this->apiResponse->message($response, "Slow down! Please wait {$sisa} seconds.", 429);
        }

        $result = $this->bookmarkAction->execute((int)$user->id, (int)$series);

        // Update spam table
        App::$spamTable->set($key, [
            'last_action' => $now,
            'count' => ($last['count'] ?? 0) + 1
        ]);

        return match ($result) {
            BookmarkActionResult::ADDED =>
                $this->apiResponse->message($response, 'Bookmark added'),
            BookmarkActionResult::REMOVED =>
                $this->apiResponse->message($response, 'Bookmark removed'),
            BookmarkActionResult::EXISTS =>
                $this->apiResponse->message($response, 'Already bookmarked'),
        };
    }


}
