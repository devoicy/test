<?php
// SeriesSearch.php
namespace Webtoon\Controllers\Series;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\ApiResponse;
use Webtoon\Models\Series\SeriesSearch as Model;

class SeriesSearch
{

    public function __construct(
        private Model $seriesSearch, private ApiResponse $apiResponse
    )
    {}

    public function execute(Request $request, Response $response, array $args)
    {

        $id = (int) $args['seriesId'] ?? 0;
        $slug = $args['seriesSlug'] ?? 0;
        $keyword = substr(str_replace('-', ' ', $slug), 0, 20);
        $series = $this->seriesSearch->execute($keyword,[$id]);

        if(!$series) return $this->apiResponse->message($response, '404 Not Found');

        return $this->apiResponse->data($response, $series);

    }

}