<?php
// SeriesSummaryDetail.php
namespace Webtoon\Controllers\Series;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Series\SeriesId as Model;
use Twig\Environment as TwigEnvironment;

class SeriesId
{


    // Tambahkan TwigEnvironment sebagai argumen
    public function __construct(
        private Model $seriesId,
        private TwigEnvironment $twig
    )
    {}

    public function execute(Request $request, Response $response, array $args)
    {

    	$id = (int)$args['id'] ?? '';
        $path = strtok($request->server['request_uri'], '?') ?: '/';
        
        $data = $this->seriesId->execute($id);

        if(!$data) {
            $response->status(404);
            return $this->twig->render('error.html', [
                'code'    => 404,
                'path'    => $path,
                'title'   => 'Not Found',
                'message' => 'The requested series ID is invalid.'
            ]);
        }

        $response->status(301);
        $response->header('Location', "/title/{$id}/{$data['slug']}");
        return "";
    }

}