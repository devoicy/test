<?php
// SeriesSummaryDetail.php
namespace Webtoon\Controllers\Series;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Series\SeriesSummaryById as Model;
use Twig\Environment as TwigEnvironment; // Import class Twig
use Webtoon\Config;

class SeriesSummaryDetail
{


    // Tambahkan TwigEnvironment sebagai argumen
    public function __construct(
        private Model $seriesSummaryById, 
        private TwigEnvironment $twig,
        private Config $config
    )
    {}

    public function execute(Request $request, Response $response, array $args)
    {

        $config = $this->config->get('site');

        // 1. Ambil path di awal
        $path = strtok($request->server['request_uri'], '?') ?: '/';
        
        $id = $args['id'] ?? '';
        $slug = $args['slug'] ?? '';

        // 2. Validasi ID
        if(!ctype_digit((string)$id)) {
            $response->status(404);
            return $this->twig->render('error.html', [
                'code'    => 404,
                'path'    => $path,
                'title'   => 'Invalid ID',
                'message' => 'The requested series ID is invalid.'
            ]);
        };

        // 3. Ambil data dari Model
        $data = $this->seriesSummaryById->execute($id);

        // 4. Handle Not Found
        if(!$data) {
            $response->status(404);
            return $this->twig->render('error.html', [
                'code'    => 404,
                'path'    => $path,
                'title'   => 'Not Found',
                'message' => 'Series not found in database.'
            ]);
        }

        // 5. 🔥 Canonical Redirect (Sangat Bagus!)
        if($data['slug'] !== $slug) {
            $response->status(301);
            $response->header('Location', "/title/{$id}/{$data['slug']}");
            return ""; // Swoole end response
        }

        // 6. Setup Extra Data
        $data['site_url'] = $config['url'];
        $data['site_title'] = $config['title'];
        $data['url'] = $config['url'] . $path; // URL absolut halaman ini
        $data['meta'] = $this->generateMeta($data);

        // 7. 
        if($data['is_published'] !== 1) {
            $response->status(503);
            return $this->twig->render('error.html', [
                'code'    => 503,
                'path'    => $path,
                'title'   => 'Not Published',
                'message' => 'Series is currently in draft mode or restricted to internal users only.'
            ]);
        }

        return $this->twig->render('series.html', $data);
    }

    public function generateMeta(array $series): array
    {
        $name  = (string)($series['name'] ?? '');
        $desc  = (string)($series['description'] ?? '');
        $cover = (string)($series['cover_url'] ?? '');
        $url   = (string)($series['url'] ?? '');
        $baseUrl = rtrim($series['site_url'] ?? '', '/');

        $descClean = strip_tags(html_entity_decode($desc, ENT_QUOTES, 'UTF-8'));
        $entities = $series['entities'] ?? [];

        $authors = $genres = $themes = $types = [];
        foreach (['author', 'genre', 'theme', 'type'] as $key) {
            if (!empty($entities[$key])) {
                foreach ($entities[$key] as $e) {
                    if (!empty($e['title'])) ${$key . 's'}[] = $e['title'];
                }
            }
        }

        $allGenres = array_merge($genres, $themes);
        
        // --- META TITLE (Optimized for Click Through Rate) ---
        $metaTitle = $name;
        if ($allGenres) $metaTitle .= " - " . implode(', ', array_slice($allGenres, 0, 3));
        $metaTitle .= " | " . ($series['site_title'] ?? 'OhMyComics');

        // --- SMART DESCRIPTION ---
        $typeStr = $types ? implode(', ', $types) : 'Manga';
        $authorStr = $authors ? ' by ' . implode(', ', $authors) : '';
        $genreStr = $allGenres ? ' genres: ' . implode(', ', array_slice($allGenres, 0, 5)) : '';
        
        $intro = "Read {$name} {$typeStr}{$authorStr}.{$genreStr} ";
        $snippet = mb_substr($descClean, 0, 160);
        $metaDesc = mb_strimwidth($intro . $snippet, 0, 155, '...');

        // --- KEYWORDS (Priority order) ---
        $keywords = array_unique(array_merge(
            [$name, "Read $name", "{$name} English"],
            $authors,
            $allGenres,
            $types,
            ['Manga', 'Manhwa', 'Online Read']
        ));

        // --- JSON-LD (Ditingkatkan ke CreativeWorkSeries) ---

        $breadcrumb = [
            "@context" => "https://schema.org",
            "@type" => "BreadcrumbList",
            "itemListElement" => [
                [
                    "@type" => "ListItem",
                    "position" => 1,
                    "name" => "Home",
                    "item" => $baseUrl
                ],
                [
                    "@type" => "ListItem",
                    "position" => 2,
                    "name" => $types[0] ?? "Manga",
                    "item" => $baseUrl . "/title"
                ],
                [
                    "@type" => "ListItem",
                    "position" => 3,
                    "name" => $name,
                    "item" => $url
                ]
            ]
        ];

        $jsonLd = [
            "@context" => "https://schema.org",
            "@type" => "CreativeWorkSeries", // Lebih tepat untuk Webtoon dibanding Book
            "name" => $name,
            "description" => $metaDesc,
            "image" => $cover,
            "url" => $url,
            "genre" => $allGenres,
            "author" => array_map(fn($a) => ["@type" => "Person", "name" => $a], $authors),
            "about" => array_map(fn($g) => ["@type" => "Thing", "name" => $g], $allGenres)
        ];

        $jsonLdFinal = [$jsonLd, $breadcrumb];

        return [
            'title'       => $metaTitle,
            'description' => $metaDesc,
            'keywords'    => implode(', ', $keywords),
            'cover'       => $cover,
            'jsonld'      => json_encode($jsonLdFinal, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            // Tambahan untuk OG Tag di Template
            'og_type'     => 'video.other', // Atau 'article'
        ];
    }
}