<?php

namespace Webtoon\Controllers\Series;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Series\SeriesDiscovery as SeriesDiscoveryModel;
use Webtoon\Models\Series\SeriesSummaryList;
use Webtoon\Service\Router\ResponseDTO;
use Webtoon\ApiResponse;
use Twig\Environment; // Import class Twig

class SeriesDiscovery
{

    // Tambahkan TwigEnvironment sebagai argumen 
    public function __construct(
        protected readonly SeriesDiscoveryModel $seriesDiscoveryModel,
        protected readonly SeriesSummaryList $seriesSummaryLists,
        protected readonly ApiResponse $apiResponse,
        protected readonly Environment $twig
    )
    {}

    public function execute(Request $request, Response $response, array $args): ResponseDTO
    {

        $series = $this->seriesSummaryLists->execute(1);
        $series['title'] = 'Series';

        $data = $this->twig->render('home.html', $series);

        return ResponseDTO::html($data);

    }

    public function tren(Request $request, Response $response, array $args): ResponseDTO
    {
        $data = $this->apiResponse->data($response, $this->seriesDiscoveryModel->getTrending());
        return ResponseDTO::json($data);
    }

    public function top(Request $request, Response $response, array $args): ResponseDTO
    {
        $data = $this->apiResponse->data($response, $this->seriesDiscoveryModel->getTopRated());
        return ResponseDTO::json($data);
    }

}