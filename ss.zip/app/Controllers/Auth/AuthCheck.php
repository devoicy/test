<?php
namespace Webtoon\Controllers\Auth;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\ApiResponse;
use Webtoon\Service\eJWT;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
class AuthCheck
{

	protected $apiResponse;
	protected $jwt;

	public function __construct(ApiResponse $apiResponse, eJWT $jwt) 
	{
		$this->apiResponse = $apiResponse;
		$this->jwt = $jwt;
	}

    public function execute(Request $request, Response $response)
    {

    	$cookie = $request->cookie['xtoon'] ?? null;

    	if (!$cookie) {
    		return $this->apiResponse->message($response, 'UNAUTHORIZED', 401);
    	}

    	try {

    		$this->jwt->verifyAccessToken($cookie);
    		return $this->apiResponse->message($response, 'VALID', 200);

    	} catch (\Firebase\JWT\ExpiredException $e) {

            return $this->apiResponse->message($response, 'TOKEN_EXPIRED', 401);

        } catch (\Throwable $e) {

            return $this->apiResponse->message($response, 'INVALID_TOKEN', 401);

        }

    }

}
