<?php

namespace Webtoon\Controllers\Auth;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Auth\UserDeleteToken;
use Webtoon\Service\Cookie;
use Webtoon\ApiResponse;

class Signout
{

    public function __construct
    (
        private Cookie $cookie,
        private UserDeleteToken $userDeleteToken,
        private ApiResponse $apiResponse
    )
    {}

    public function execute(Request $request, Response $response)
    {

		$cookieToken = $request->cookie['xtoon'] ?? null;

    	if ($cookieToken) {
    		$this->userDeleteToken->execute($cookieToken);
			$this->cookie->clearRefresh($response);
        }

        return $this->apiResponse->message($response, 'ok', 200);

    }
}
