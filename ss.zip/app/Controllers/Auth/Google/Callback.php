<?php

namespace Webtoon\Controllers\Auth\Google;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Controllers\Auth\Google\Base;
use Webtoon\Models\Auth\UserCreate;
use Webtoon\Models\Auth\UserFindByEmail;
use Webtoon\Models\Auth\UserCreateRefreshToken;
use Webtoon\Service\Cookie;
use Webtoon\Service\eJWT;
use Twig\Environment as TwigEnvironment;
use Google\Client as GoogleClient;
use Google_Service_Oauth2;

class Callback extends Base
{
    protected $jwt;
    protected $userCreate; // Tambahkan properti untuk model
    protected $userFindByEmail; // Tambahkan properti untuk model
    protected $userCreateRefreshToken;
    protected $cookie;

    public function __construct
    (
        eJWT $jwt,
        Cookie $cookie,
        UserCreate $userCreate, 
        UserFindByEmail $userFindByEmail, 
        UserCreateRefreshToken $userCreateRefreshToken
    )
    {
        parent::__construct();
        $this->jwt = $jwt;
        $this->userCreate = $userCreate;
        $this->userFindByEmail = $userFindByEmail;
        $this->userCreateRefreshToken = $userCreateRefreshToken;
        $this->cookie = $cookie;

    }

    /**
     * Google OAuth Callback
     */
    public function execute(Request $request, Response $response)
    {
        // -------------------------
        // 1. Ambil 'code'
        // -------------------------
        $code = $request->get['code'] ?? null;

        if (!$code) {
            throw new \Exception('No code provided');
        }

        // -------------------------
        // 2. Setup Google Client
        // -------------------------
        $client = new GoogleClient();
        $client->setClientId($this->google['client_id']);
        $client->setClientSecret($this->google['client_secret']);
        $client->setRedirectUri($this->google['redirect']);

        // -------------------------
        // 3. Fetch Google Token
        // -------------------------
        try {
            $token = $client->fetchAccessTokenWithAuthCode($code);
        } catch (\Throwable $e) {
            throw new \Exception($e->getMessage());
        }

        if (isset($token['error'])) {
            $msg = $token['error_description'] ?? $token['error'];
            throw new \Exception($msg);
        }

        // -------------------------
        // 4. Get User Info
        // -------------------------
        try {
            $client->setAccessToken($token['access_token']);
            $oauth2 = new Google_Service_Oauth2($client);
            $userinfo = $oauth2->userinfo->get();
        } catch (\Throwable $e) {
            throw new \Exception($e->getMessage());
        }

        if (empty($userinfo->email)) {
            throw new \Exception('Google no email');
        }

        // -------------------------
        // 5. Proses User
        // -------------------------
        $user = $this->userFindByEmail->execute($userinfo->email);
        $refresh = $this->jwt->createRefreshToken();

        if (!$user) {
            // Create new user
            $user = $this->userCreate->execute($userinfo, $refresh);
            if (!$user) {
                throw new \Exception('Failed to create user');
            }
        } else {
            // Update refresh token
            if (!$this->userCreateRefreshToken->execute($user['id'], $refresh['token'], $refresh['expires'])) {
                throw new \Exception('Failed to update refresh token');
            }
        }

        // -------------------------
        // 6. Set Cookie Refresh 
        // -------------------------
        $key = $this->jwt->createAccessToken([
            'key' => $refresh['token'],
            'id' => $user['id'],
            'role' => $user['role']
        ]);

        $this->cookie->setRefresh($response, $key, $refresh['expires']);

        // -------------------------
        // 7. Redirect (Frontend UX)
        // -------------------------
        $response->status(302);
        $response->header('Location', '/auth/success');
        $response->end();
        return;
    }
}
