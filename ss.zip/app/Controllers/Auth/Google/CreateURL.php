<?php

namespace Webtoon\Controllers\Auth\Google;

use Swoole\Http\Request;
use Swoole\Http\Response;

class CreateURL extends Base
{

    public function execute(Request $request, Response $response)
    {
        $client = new \Google\Client();
        $client->setClientId($this->google['client_id']);
        $client->setClientSecret($this->google['client_secret']);
        $client->setRedirectUri($this->google['redirect']);
        $client->addScope(['email', 'profile']);
        $client->setAccessType('offline');
        $client->setPrompt('none');

        $authUrl = $client->createAuthUrl();
        // redirect ke halaman sukses
        $response->status(302);
        $response->header('Location', $authUrl);
        $response->end();
        return;
    }
}
