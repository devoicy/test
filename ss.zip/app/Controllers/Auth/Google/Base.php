<?php

namespace Webtoon\Controllers\Auth\Google;

class Base
{
    protected array $google;

    public function __construct()
    {
        $this->google = [
            'client_id'     => '791537039426-n2rl5ae104q29ngjjn67fk59v8bftsc8.apps.googleusercontent.com',
            'client_secret' => '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',
            'redirect'      => 'http://localhost:8022/callback'
        ];
    }
}
