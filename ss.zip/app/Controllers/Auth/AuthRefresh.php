<?php
namespace Webtoon\Controllers\Auth;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\ApiResponse;
use Webtoon\Service\eJWT;
class AuthRefresh
{

	protected $apiResponse;
	protected $jwt;

	public function __construct(ApiResponse $apiResponse, eJWT $jwt) 
	{
		$this->apiResponse = $apiResponse;
		$this->jwt = $jwt;
	}

    public function execute(Request $request, Response $response)
    {

    	return $this->apiResponse->message($response, 'ok', 200);

    }

}
/*

        $refresh = $this->jwt->createRefreshToken();

        // B. Simpan/Overwrite Refresh Token baru di DB (menghapus yang lama)
        try {
            $success = $this->userCreateRefreshToken->execute(
                $user['id'],
                $refresh['token'],
                $refresh['expires']
            );
            if (!$success) {
                throw new \RuntimeException("Failed to save new refresh token.");
            }
        } catch (Throwable $e) {
            return $this->unauthorized(
                $res,
                'Server error',
                'Failed to persist new session token: ' . $e->getMessage()
            );
        }


        // C. Buat Access Token baru
        $newAccessTokenPayload = [
            'key'  => $refresh['token'], 
            'id'   => $user['id'],
            'role' => $user['role'],
        ];
        $access = $this->jwt->createAccessToken($newAccessTokenPayload);

        // D. Set cookie baru ke client
        $this->cookie->setRefresh( 
            $res, 
            $access, 
            $refresh['expires']
        );

        // E. Lanjutkan ke proses berikutnya
        try {
            // 1. Verifikasi Access Token yang BARU DIBUAT (Zero Trust Check)
            $verifiedPayload = $this->jwt->verifyAccessToken($access); 

            // 2. Attach hasil VERIFIKASI ke Request
            return $this->attachPayloadAndNext(
                $req, 
                $res, 
                $args, 
                $next, 
                $verifiedPayload // <<< Menggunakan hasil verifikasi
            );
        } catch (Throwable $e) {
            // Jika verifikasi token yang baru dibuat gagal, ini adalah kegagalan sistem SERIUS.
            return $this->unauthorized(
                $res,
                'Authentication failed',
                'CRITICAL: Failed verifying reissued access token (' . $e->getMessage() . ')'
            );
        }
        */