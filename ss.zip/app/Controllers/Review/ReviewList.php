<?php

namespace Webtoon\Controllers\Review;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Review\ReviewList as Model;
use Webtoon\Service\eJWT;
use Webtoon\ApiResponse;

final class ReviewList
{
	public function __construct(
		private Model $reviewLists,
		private eJWT $jwt,
		private ApiResponse $apiResponse
	) {}

	public function execute(Request $request, Response $response, array $args)
	{
	    $userId = null;
	    $token = $request->cookie['xtoon'] ?? null;

	    if ($token) {
	        try {
	            // Pastikan getPayload mengembalikan object/array yang punya ID
	            $payload = $this->jwt->getPayload($token);
	            $userId = $payload->id ?? null;
	        } catch (\Throwable $e) {
	            // Jika token sampah/expired, biarkan userId null (anggap tamu)
	            $userId = null; 
	        }
	    }

	    $seriesId = (int) ($args['seriesId'] ?? 0);
	    
	    if ($seriesId <= 0) {
	        return $this->apiResponse->error($response, 'Invalid Series', 400);
	    }

	    // Eksekusi ke Model
	    $reviews = $this->reviewLists->execute($seriesId, $userId);

	    return $this->apiResponse->data($response, $reviews);
	}
}