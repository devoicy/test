<?php

namespace Webtoon\Controllers\Review;

use App;
use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Review\ReviewAction as Model;
use Webtoon\Service\eJWT;
use Webtoon\ApiResponse;

final class ReviewAction
{
    public function __construct(
        private Model $reviewAction,
        private eJWT $jwt,
        private ApiResponse $apiResponse
    ) {}

    public function execute(Request $request, Response $response, array $args)
    {
        $userId = null;
        $token = $request->cookie['xtoon'] ?? null;

        if ($token) {
            try {
                $payload = $this->jwt->getPayload($token);
                $userId = $payload->id ?? null;
            } catch (\Throwable $e) {
                $userId = null; 
            }
        }

        // --- PROTEKSI: WAJIB LOGIN ---
        if (!$userId) {
            return $this->apiResponse->message($response, 'Please login to post a review.', 401);
        }

        $req = json_decode($request->rawContent());
        $commentText = $req->comment ?? '';

        // --- VALIDASI INPUT ---
        if (empty($commentText) || mb_strlen($commentText) < 3) {
            return $this->apiResponse->message($response, 'Your comment is too short. Minimum 3 characters required.', 400);
        }

        if (!isset($req->rating) || (int)$req->rating < 1 || (int)$req->rating > 5) {
            return $this->apiResponse->message($response, 'Please provide a rating between 1 and 5 stars.', 400);
        }

        // --- ANTI SPAM (THROTTLING) ---
        $key = "rev:{$userId}";
        $now = time();
        $limit = 30; 
        $last = App::$spamTable->get($key);

        if ($last && ($now - $last['last_action']) < $limit) {
            $sisa = $limit - ($now - $last['last_action']);
            return $this->apiResponse->message($response, "Slow down! You can post another review in {$sisa} seconds.", 429);
        }

        // Persiapan data
        $data = [
            'user_id'   => (int) $userId,
            'series_id' => (int) $req->series_id,
            'rating'    => (int) $req->rating,
            'comment'   => htmlentities($commentText)
        ];

        // Eksekusi Model
        $result = $this->reviewAction->execute($data);

        if ($result === false) {
            return $this->apiResponse->message($response, 'Something went wrong. Please try again later.', 500);
        }

        // Update spam table
        App::$spamTable->set($key, [
            'last_action' => $now,
            'count' => ($last['count'] ?? 0) + 1
        ]);

        return $this->apiResponse->data($response, [
            'message' => 'Your review has been posted successfully!',
            'data'    => $data
        ]);
    }
}