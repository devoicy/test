<?php
namespace Webtoon\Controllers\Chapter;

use Webtoon\Models\Chapter\ChapterList as Model;
use Webtoon\ApiResponse;
use Swoole\Http\Request;
use Swoole\Http\Response;

final class ChapterList
{
    public function __construct(
        private Model $chapterList,
        private ApiResponse $apiResponse
    ) {}

    public function execute(Request $request, Response $response, array $args)
    {
        $seriesId = (int)($args['seriesId'] ?? 0);

        if ($seriesId <= 0) {
            return $this->apiResponse->message(
                $response,
                'Invalid series ID',
                400
            );
        }

        $limit = (int)($request->get['limit'] ?? 100);
        $limit = max(1, min($limit, 100));

        $chapters = $this->chapterList->execute($seriesId, $limit);

        return $this->apiResponse->data($response, $chapters, 200);
    }
}

