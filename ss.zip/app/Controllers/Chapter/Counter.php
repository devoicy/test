<?php

namespace Webtoon\Controllers\Chapter;

use App;
use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Bookmark\BookmarkReading as Model;
use Webtoon\Service\eJWT;

class Counter
{
    public function __construct(
        private Model $history,
        private eJWT $jwt
    ){}

    public function execute(Request $request, Response $response)
    {
        $reff = $request->header['referer'] ?? '';
        if (!$reff) {
            return $response->end('no_referer');
        }

        $data = $this->getData($reff);
        
        // Perbaikan sintaks isset
        if ($data && isset($data['seriesId'], $data['chapterId'])) {
            $chapterId = $data['chapterId'];
            $seriesId = $data['seriesId'];
            
            // Swoole Table: Atomic Increment (Sangat Cepat)
            // Pastikan key $chapterId sudah ada di table init
            App::$viewBuffer->incr((string)$chapterId, 'count', 1);

            $token = $request->cookie['xtoon'] ?? null;
            if ($token) {
                $user = $this->jwt->getPayload($token);
                if ($user && isset($user->id)) {
                    // Update bookmark/history hanya untuk user yang login
                    $this->history->execute((int)$user->id, $seriesId, $chapterId);
                }
            }
        }

        $response->header('Content-Type', 'text/plain');
        $response->end('ok');
    }

    // Perbaikan return type hint ke ?array
    public function getData(string $url): ?array 
    {
        $parsedUrl = parse_url($url);
        if (!isset($parsedUrl['path'])) {
            return null;
        }

        $pathParts = explode('/', trim($parsedUrl['path'], '/'));

        // Pastikan index yang diakses ada untuk menghindari Notice
        if (count($pathParts) >= 5) {
            $seriesId = $pathParts[1];
            $chapterId = $pathParts[4];

            if (is_numeric($seriesId) && is_numeric($chapterId)) {
                return [
                    'seriesId' => (int) $seriesId,
                    'chapterId' => (int) $chapterId
                ];
            }
        }

        return null;
    }
}