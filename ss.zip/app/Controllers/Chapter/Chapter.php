<?php
namespace Webtoon\Controllers\Chapter;

use Webtoon\Models\Chapter\Chapter as Model;
use Webtoon\ApiResponse;
use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Service\Slugify;
use Twig\Environment as TwigEnvironment;
use Webtoon\Config;

final class Chapter
{
    public function __construct(
        private Model $chapter,
        private ApiResponse $apiResponse,
        private Slugify $slug,
        private TwigEnvironment $twig,
        private Config $config
    ) {}

public function execute(Request $request, Response $response, array $args)
{

    $config = $this->config->get('site');

    $path = strtok($request->server['request_uri'], '?') ?: '/';

    $seriesId   = $args['seriesId'] ?? null;
    $seriesSlug = $args['seriesSlug'] ?? null;
    $chapterId  = $args['chapterId'] ?? null;
    $chapterNum = $args['chapterNum'] ?? null;

    // 1. Validasi awal (Fast Fail)
    if(!$seriesId || !$chapterId || !ctype_digit((string)$chapterId)) {
        $response->status(404);
        return $this->twig->render('error.html', [
            'code' => 404, 'path' => $path, 'title' => 'Not Found',
            'message' => 'Invalid Chapter or Series ID.'
        ]);
    }
    
    // 2. Ambil data dari Model
    $chapter = $this->chapter->execute($chapterId);

    if(!isset($chapter['series'])) {
        $response->status(404);
        return $this->twig->render('error.html', [
            'code' => 404, 'path' => $path,
            'title' => 'Chapter Not Found',
            'message' => 'Chapter Not Found.'
        ]);
    }

    // 3. 🔥 SMART CANONICAL CHECK
    // Ambil data asli dari DB buat dibandingin
    $dbSeriesId   = $chapter['series']['id'];
    $dbSeriesSlug = $chapter['series']['slug'];
    $dbChapterNum = $chapter['current']['number'];

    // Kita cek apakah URL saat ini sudah sesuai dengan "Kebenaran" di Database
    if (
        (int)$seriesId   !== (int)$dbSeriesId || 
        (string)$seriesSlug !== (string)$dbSeriesSlug ||
        (string)$chapterNum !== (string)$dbChapterNum
    ) {
        $response->status(301);
        $response->header('Location', "/title/{$dbSeriesId}/{$dbSeriesSlug}/chapter/{$chapterId}/{$dbChapterNum}");
        return ""; 
    }
    $chapter['image'] = "{$chapter['current']['images']['url']}/{$chapter['current']['images']['dir']}/{$chapter['current']['images']['files'][0]}";
    $chapter['current']['images'] = json_encode($chapter['current']['images']);
    // Setup Extra Data
    $chapter['site_url'] = $config['url'];
    $chapter['site_title'] = $config['title'];
    $chapter['url'] = $config['url'] . $path; // URL absolut halaman ini
    // 4. Setup Meta (Bisa pake generateMeta yang tadi atau kirim mentah dulu)
    // Jangan lupa tambahin navigasi next/prev buat di template
    return $this->twig->render('chapter.html', $chapter);
}
}

