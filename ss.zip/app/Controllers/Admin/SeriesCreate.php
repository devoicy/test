<?php
declare(strict_types=1);

namespace Webtoon\Controllers\Admin;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Service\{Slugify, eJWT};
use Webtoon\ApiResponse;
use Webtoon\Models\Series\SeriesCreate as ModelSeriesCreate;
use Twig\Environment;

final class SeriesCreate
{
    private array $allowedEntities;

    public function __construct(
        private Slugify $slug,
        private eJWT $jwt,
        private ApiResponse $apiResponse,
        private ModelSeriesCreate $create,
        private Environment $twig
    ) {
        $this->allowedEntities = [
            'alternative-title', 'artist', 'author', 'character', 'demographic',
            'end-date', 'genre', 'group', 'language', 'parody', 'publisher',
            'release-date', 'serialization-site', 'status', 'tag', 'theme',
            'translation', 'type',
        ];
    }

    public function get(Request $request, Response $response): string
    {
        // Whitelist yang ditampilkan di UI
        $excluded = [
            'alternative-title', 'demographic', 'end-date', 'language', 
            'parody', 'release-date', 'serialization-site', 'theme'
        ];
        
        $entities = array_values(array_diff($this->allowedEntities, $excluded));

        return $this->twig->render('Admin/series_create.html', [
            'entities' => $entities
        ]);
    }

    public function post(Request $request, Response $response)
    {
        // 1. Auth Defense
        $token = $request->cookie['xtoon'] ?? null;
        if (!$token || !($user = $this->jwt->getPayload($token)) || !isset($user->id)) {
            return $this->apiResponse->message($response, 'Unauthorized', 401);
        }

        $postData = $request->post ?? [];

        // 2. Strict Input Validation
        $name = trim((string)($postData['name'] ?? ''));
        $coverUrl = trim((string)($postData['cover_url'] ?? ''));
        
        if (empty($name)) {
            return $this->apiResponse->message($response, 'Name is required', 400);
        }

        // Validasi URL Cover (Mencegah SSRF atau XSS via URL)
        if (!empty($coverUrl) && !filter_var($coverUrl, FILTER_VALIDATE_URL)) {
            return $this->apiResponse->message($response, 'Invalid cover URL format', 400);
        }

        // Published status: Pastikan hanya 0 atau 1
        $isPublished = ((int)($postData['is_published'] ?? 0)) === 1 ? 1 : 0;

        // 3. Sanitasi & Struktur Data
        $result = [
            'name'         => htmlspecialchars($name, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'slug'         => $this->slug->execute($name),
            'description'  => htmlspecialchars(trim((string)($postData['description'] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'cover_url'    => $coverUrl, 
            'is_published' => $isPublished,
            'updated_by'   => (int)$user->id,
            'created_by'   => (int)$user->id,
            'entities'     => []
        ];

        // 4. Entity Defense (Whitelist & Limit Processing)
        $rawEntities = $postData['entities'] ?? [];
        if (is_array($rawEntities)) {
            foreach ($rawEntities as $type => $values) {
                // Shield 1: Whitelist Type
                if (!in_array($type, $this->allowedEntities, true)) continue;

                $rawValue = is_array($values) ? ($values[0] ?? '') : $values;
                
                // Shield 2: Limit string length untuk mencegah ReDoS atau Memory Spam
                $cleanString = substr((string)$rawValue, 0, 250); 
                
                $items = array_filter(array_map('trim', explode(',', $cleanString)));

                foreach ($items as $item) {
                    // Shield 3: Max 50 items per entity type untuk keamanan performa
                    if (count($result['entities'][$type] ?? []) > 50) break;

                    $result['entities'][$type][] = [
                        'type' => $type,
                        'name' => htmlspecialchars($item, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
                        'slug' => $this->slug->execute($item)
                    ];
                }
            }
        }

        // 5. Execution with Error Handling
        try {
            $created = $this->create->execute($result);
            if ($created) {
                return $this->apiResponse->message($response, 'Series created successfully', 201);
            }
            return $this->apiResponse->message($response, 'Database error: Failed to save', 500);
        } catch (\Throwable $e) {
            // Log error di sini jika perlu
            return $this->apiResponse->message($response, 'Internal Server Error', 500);
        }
    }
}