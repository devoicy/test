<?php
declare(strict_types=1);

namespace Webtoon\Controllers\Admin;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Series\SeriesSummaryById;
use Webtoon\Models\Chapter\{Chapter, ChapterAction};
use Webtoon\Service\eJWT;
use Webtoon\ApiResponse;
use Twig\Environment;

final class ChapterEdit
{
    public function __construct(
        private SeriesSummaryById $series,
        private Chapter $chapter,
        private ChapterAction $chapterAction,
        private eJWT $jwt,
        private ApiResponse $apiResponse,
        private Environment $twig
    ) {}

    public function get(Request $request, Response $response, array $args)
    {

        $series = $this->series->execute((int)$args['seriesId']);
        $chapter = $this->chapter->execute((int)$args['chapterId'], true);

        return $this->twig->render('Admin/chapter_edit.html', [
            'series' => $series,
            'chapter' => $chapter
        ]);

    }

    public function post(Request $request, Response $response, array $args)
    {

        $seriesId = (int)($args['seriesId'] ?? 0);
        $chapterId = (int)($args['chapterId'] ?? 0);

        // 1. Auth Defense
        $token = $request->cookie['xtoon'] ?? null;
        if (!$token || !($user = $this->jwt->getPayload($token)) || !isset($user->id)) {
            return $this->apiResponse->message($response, 'Unauthorized', 401);
        }

        $postData = $request->post ?? [];

        // 2. JSON Integrity Check (Crucial!)
        $jsonRaw = (string)($postData['content'] ?? '[]');
        
        // Decode untuk memastikan format validmsgpack_pack(json_decode('
        $decoded = json_decode($jsonRaw, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return $this->apiResponse->message($response, 'Invalid JSON format in content field', 400);
        }

        // Opsional: Pastikan isinya array, bukan object atau string tunggal
        if (!is_array($decoded)) {
            return $this->apiResponse->message($response, 'Content must be a JSON Array', 400);
        }

        // 3. Re-encode untuk standarisasi (minified & safe)
        $cleanJson = msgpack_pack($decoded);

        // 4. Data Preparation
        $name = trim((string)($postData['name'] ?? ''));
        $number = filter_var($postData['number'] ?? 0, FILTER_VALIDATE_FLOAT);

        $result = [
            'series_id'    => $seriesId,
            'cover_url'    => trim((string)($postData['cover_url'] ?? '')),
            'name'         => htmlspecialchars($name, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'content'      => $cleanJson, 
            'number'       => $number,
            'updated_by'   => (int)$user->id,
            'created_by'   => (int)$user->id,
            'is_published' => ((int)($postData['is_published'] ?? 0)) === 1 ? 1 : 0
        ];

        // 5. Execution
        try {
            $created = $this->chapterAction->execute($result, $chapterId);
            if ($created) {
                $response->status(302);
                $response->header('Location', "/admin/series/{$seriesId}/chapter");
                return $response->end();
            }
            return $this->apiResponse->message($response, 'Failed to save chapter', 500);
        } catch (\Throwable $e) {
            return $this->apiResponse->message($response, 'Database error: ' . $e->getMessage(), 500);
        }

    }


}