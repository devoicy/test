<?php
declare(strict_types=1);

namespace Webtoon\Controllers\Admin;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Service\{Slugify, eJWT};
use Webtoon\ApiResponse;
use Webtoon\Models\Series\SeriesCreate as ModelSeriesUpdate; // Gunakan Update, bukan Create
use Webtoon\Models\Series\SeriesSummaryById as ModelSeriesSummaryById;
use Twig\Environment;

final class SeriesEdit
{
    private array $allowedEntities;

    public function __construct(
        private Slugify $slug,
        private eJWT $jwt,
        private ApiResponse $apiResponse,
        private ModelSeriesUpdate $update, // Nama model disesuaikan untuk konteks Edit
        private ModelSeriesSummaryById $series,
        private Environment $twig
    ) {
        $this->allowedEntities = [
            'alternative-title', 'artist', 'author', 'character', 'demographic',
            'end-date', 'genre', 'group', 'language', 'parody', 'publisher',
            'release-date', 'serialization-site', 'status', 'tag', 'theme',
            'translation', 'type',
        ];
    }

    public function get(Request $request, Response $response, array $args): string
    {
        $id = (int)($args['id'] ?? 0);
        if ($id <= 0) {
            return $this->apiResponse->message($response, 'Invalid ID', 400);
        }

        $data = $this->series->execute($id);
        if (!$data) {
            return $this->apiResponse->message($response, 'Series not found', 404);
        }

        // Whitelist yang ditampilkan di UI (Form Fields)
        $excluded = [
            'alternative-title', 'demographic', 'end-date', 'language', 
            'parody', 'release-date', 'serialization-site', 'theme'
        ];
        
        $formEntities = array_values(array_diff($this->allowedEntities, $excluded));

        // Render ke Twig dengan data series asli + daftar field entitas yang tersedia
        return $this->twig->render('Admin/series_edit.html', [
            's' => $data, // Gunakan prefix 's' agar tidak bentrok di template
            'available_entities' => $formEntities
        ]);
    }

    public function post(Request $request, Response $response, array $args)
    {
        // 1. Auth Defense
        $token = $request->cookie['xtoon'] ?? null;
        if (!$token || !($user = $this->jwt->getPayload($token)) || !isset($user->id)) {
            return $this->apiResponse->message($response, 'Unauthorized', 401);
        }

        $id = (int)($args['id'] ?? 0);
        $postData = $request->post ?? [];

        // 2. Strict Input Validation
        $name = trim((string)($postData['name'] ?? ''));
        if (empty($name)) {
            return $this->apiResponse->message($response, 'Name is required', 400);
        }

        $coverUrl = trim((string)($postData['cover_url'] ?? ''));
        if (!empty($coverUrl) && !filter_var($coverUrl, FILTER_VALIDATE_URL)) {
            return $this->apiResponse->message($response, 'Invalid cover URL format', 400);
        }

        $isPublished = ((int)($postData['is_published'] ?? 0)) === 1 ? 1 : 0;

        // 3. Sanitasi & Struktur Data (Konstruksi Result)
        $result = [
            'name'         => htmlspecialchars($name, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'slug'         => $this->slug->execute($name),
            'description'  => htmlspecialchars(trim((string)($postData['description'] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'cover_url'    => $coverUrl, 
            'is_published' => $isPublished,
            'updated_by'   => (int)$user->id,
            'entities'     => []
        ];

        // 4. Entity Defense (Processing Tags/Genres)
        $rawEntities = $postData['entities'] ?? [];
        if (is_array($rawEntities)) {
            foreach ($rawEntities as $type => $values) {
                if (!in_array($type, $this->allowedEntities, true)) continue;

                // Ambil nilai pertama (Swoole post format support)
                $rawValue = is_array($values) ? ($values[0] ?? '') : $values;
                $cleanString = substr((string)$rawValue, 0, 500); 
                
                $items = array_filter(array_map('trim', explode(',', $cleanString)));

                foreach ($items as $item) {
                    if (count($result['entities'][$type] ?? []) >= 30) break; // Limit per type

                    $result['entities'][$type][] = [
                        'type' => $type,
                        'name' => htmlspecialchars($item, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
                        'slug' => $this->slug->execute($item)
                    ];
                }
            }
        }

        // 5. Execution with Update Model
        try {
            $updated = $this->update->execute($result, $id);
            if ($updated) {
                return $this->apiResponse->message($response, 'Series updated successfully', 200);
            }
            return $this->apiResponse->message($response, 'No changes made or update failed', 400);
        } catch (\Throwable $e) {
            error_log($e->getMessage());
            return $this->apiResponse->message($response, 'Internal Server Error', 500);
        }
    }
}