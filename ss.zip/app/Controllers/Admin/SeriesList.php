<?php

namespace Webtoon\Controllers\Admin;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Series\SeriesList as ModelSeriesList;
use Webtoon\Service\eJWT;
use Twig\Environment;

class SeriesList
{

    public function __construct(
        private ModelSeriesList $modelSeriesList,
        private eJWT $eJWT,
        private Environment $twig
    ){}

    public function execute(Request $request, Response $response)
    {

        $key = $request->get['i'] ?? null;
        $lists = $this->modelSeriesList->execute($key);

        return $this->twig->render('Admin/series_list.html', $lists);

    }


}