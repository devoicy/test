<?php

namespace Webtoon\Controllers\Admin;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Models\Chapter\ChapterList as ModelChapterList;
use Webtoon\Service\eJWT;
use Twig\Environment;

class ChapterList
{

    public function __construct(
        private ModelChapterList $list,
        private eJWT $eJWT,
        private Environment $twig
    ){}

    public function execute(Request $request, Response $response, array $args)
    {

        $key = (int)$args['id'] ?? null;
        $lists = $this->list->execute(seriesId: $key, isAdmin: true);
        return $this->twig->render('Admin/chapter_list.html', [
            'id' => $key,
            'data' => $lists]);

    }


}