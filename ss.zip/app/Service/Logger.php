<?php

declare(strict_types=1);

namespace Webtoon\Service;

use Swoole\Coroutine;
use Swoole\Coroutine\System;
use Swoole\Timer;
use Throwable;

/**
 * High-performance Logger for Swoole
 *
 * - 1 instance per worker
 * - Threshold-based flush
 * - Coroutine-safe file IO
 * - Minimal overhead per request (O(1))
 */
final class Logger
{
    private const FLUSH_THRESHOLD = 500;
    private const FLUSH_INTERVAL  = 3000; // ms

    private string $baseDir;
    private array $buffer = [];
    private int $currentCount = 0; // 🔥 O(1) counter
    private ?int $timerId = null;

    public int $workerId = 0;

    // log flags
    public bool $enableDebug = false;
    public bool $enableInfo  = true;
    public bool $enableError = true;

    public function __construct(?string $baseDir = null)
    {
        $this->baseDir = $baseDir
            ?? dirname(__DIR__, 2) . '/cache/logs';
    }

    /* =========================
     * PUBLIC API
     * ========================= */

    public function info(string $message): void
    {
        if (!$this->enableInfo) {
            return;
        }

        $time = date('H:i:s');
        $line = "[$time] INFO: $message\n";

        $this->buffer['info'][] = $line;
        $this->currentCount++;

        if ($this->enableDebug) {
            fwrite(
                STDOUT,
                "\e[32m[W{$this->workerId}] $line\e[0m"
            );
        }

        $this->handleFlushDecision();
    }

    public function error(Throwable $e, ?string $context = null): void
    {
        if (!$this->enableError) {
            return;
        }

        $time = date('H:i:s');

        $line = sprintf(
            "[%s] ERROR: %s in %s:%d - %s\n",
            $time,
            $context ?? 'Unhandled Exception',
            $e->getFile(),
            $e->getLine(),
            $e->getMessage()
        );

        // console (colored)
        fwrite(
            STDERR,
            "\e[31m[W{$this->workerId}] $line\e[0m"
        );

        // file (plain text)
        $this->buffer['error'][] = $line;
        $this->currentCount++;

        $this->handleFlushDecision();
    }

    /* =========================
     * FLUSH CONTROL
     * ========================= */

    private function handleFlushDecision(): void
    {
        // 🚀 FAST PATH: threshold reached
        if ($this->currentCount >= self::FLUSH_THRESHOLD) {
            $this->flush();
            return;
        }

        // 🛟 SAFETY NET: timer-based flush
        $this->ensureTimer();
    }

    private function ensureTimer(): void
    {
        if ($this->timerId !== null) {
            return;
        }

        $this->timerId = Timer::tick(
            self::FLUSH_INTERVAL,
            fn () => $this->flush()
        );
    }

    public function flush(): void
    {
        if ($this->currentCount === 0) {
            return;
        }

        $buffer = $this->buffer;

        // reset FIRST (important)
        $this->buffer = [];
        $this->currentCount = 0;

        $date = date('Y-m-d');

        foreach ($buffer as $type => $entries) {
            $path = sprintf(
                '%s/%s/%s_w%d.log',
                $this->baseDir,
                $type,
                $date,
                $this->workerId
            );

            $this->writeFile(
                $path,
                implode('', $entries)
            );
        }
    }

    private function writeFile(string $path, string $content): void
    {
        $dir = dirname($path);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        if (Coroutine::getCid() > 0) {
            System::writeFile($path, $content, FILE_APPEND);
        } else {
            file_put_contents(
                $path,
                $content,
                FILE_APPEND | LOCK_EX
            );
        }
    }

    /* =========================
     * LIFECYCLE
     * ========================= */

    public function shutdown(): void
    {
        $this->flush();

        $this->info('Logger shutdown');
        if ($this->timerId !== null) {
            Timer::clear($this->timerId);
            $this->timerId = null;
        }
    }
}
