<?php

namespace Webtoon\Service; // Pindahkan ke namespace Service
// use Firebase\JWT\JWT; // Jika Firebase JWT ada di root namespace
// use Firebase\JWT\Key;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

final class eJWT
{
    private string $secretKey;
    private int $accessExpire;    
    private int $refreshExpireSeconds; // Diubah namanya untuk kejelasan

    /**
     * Secret key dan expiry harus di-inject dari Config.
     */
    public function __construct(string $secret, int $accessSeconds, int $refreshSeconds) {
        // ✅ Ambil dari Config/Container
        $this->secretKey = $secret; 
        $this->accessExpire = $accessSeconds;
        $this->refreshExpireSeconds = $refreshSeconds;
    }

    /**
     * Buat access token
     * @param array $dataPayload (Payload kustom seperti 'key', 'id', 'role')
     * @return string JWT
     */
    public function createAccessToken(array $dataPayload): string {
        $iat = time();
        $payload = [
            'iat' => $iat,
            'exp' => $iat + $this->accessExpire, // ✅ Menggunakan waktu dari Config
            'jti' => bin2hex(random_bytes(16))  // JWT ID unik
        ];
        
        $data = array_merge($payload, $dataPayload);
        
        return JWT::encode($data, $this->secretKey, 'HS256');
    }

    /**
     * Verifikasi access token
     * @param string $token
     * @return object|null Payload jika valid, null jika gagal
     */
    public function verifyAccessToken(string $token): ?object {
        try {
            // 1. Coba decode dan verifikasi (Jika expired, ini akan melempar ExpiredException)
            return JWT::decode($token, new Key($this->secretKey, 'HS256'));
            
        } catch (\Firebase\JWT\ExpiredException $e) {
            // 2. TANGKAP dan LEMPAR KEMBALI: Ini adalah sinyal yang kita inginkan
            error_log("[JWT Info] Token expired: " . $e->getMessage());
            throw $e; // 👈 Biarkan ExpiredException dilempar keluar
            
        } catch (\Firebase\JWT\SignatureInvalidException $e) {
            // 3. TANGKAP dan LOG: Ini adalah masalah keamanan atau malformed. 
            // Ubah menjadi Exception umum agar tidak disangka Expired.
            error_log("[JWT SECURITY ALERT] Invalid signature: " . $e->getMessage());
            throw new \RuntimeException("Invalid signature or tampered token.");
            
        } catch (\Throwable $e) {
            // 4. TANGKAP Exception lain (Malformed, NotBefore, dll.)
            error_log("[JWT Error] Token malformed or general failure: " . $e->getMessage());
            // Lempar kembali sebagai RuntimeException agar kode pemanggil tahu ini bukan Expired
            throw new \RuntimeException("General token failure: " . $e->getMessage()); 
        }
    }

    /**
     * Buat data untuk Refresh Token (key/hash dan expire time)
     * @return array
     */
    public function createRefreshToken(): array {
        $refreshTime = time() + $this->refreshExpireSeconds;
        
        return [
            'token' => bin2hex(random_bytes(32)), // Opaque string/hash
            // ✅ Menggunakan waktu dari Config dan memformatnya untuk DB
            'expires' => date('Y-m-d H:i:s', $refreshTime) 
        ];
    }

    public function decodeWithoutVerify(string $jwt): ?object
    {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) {
            return null;
        }

        $decoded = base64_decode($parts[1], true);
        if ($decoded === false) {
             return null;
        }
        
        $payload = json_decode($decoded);
        
        return is_object($payload) ? $payload : null;
    }

    public function getPayloadFromExpired(string $token): ?object 
    {
        try {
            // Kita decode lagi tapi kasih "leeway" (toleransi waktu) yang sangat besar
            // agar library tidak melempar ExpiredException lagi.
            \Firebase\JWT\JWT::$leeway = 9999999999; 
            $payload = \Firebase\JWT\JWT::decode($token, new \Firebase\JWT\Key($this->secretKey, 'HS256'));
            \Firebase\JWT\JWT::$leeway = 0; // Reset kembali ke normal
            return $payload;
        } catch (\Throwable) {
            return null;
        }
    }

    public function getPayload(string $token): ?object
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return null;
        }

        $decoded = base64_decode($parts[1]);
        if ($decoded === null) {
            return null;
        }

        try {
            return json_decode($decoded, false, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return null;
        }
    }


}

