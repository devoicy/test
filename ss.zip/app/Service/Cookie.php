<?php
namespace Webtoon\Service;

use Swoole\Http\Response;

class Cookie
{
    private string $path = '/';
    private string $sameSite = 'Lax';
    private bool $secure;

    public function __construct(bool $secure = false)
    {
        $this->secure = $secure;
    }

    public function setRefresh(
        Response $res,
        string $token,
        string $expiresDatetime
    ): void {
        $res->cookie(
            'xtoon',                     // name
            $token,                      // value
            strtotime($expiresDatetime), // expires
            $this->path,                 // path
            '',                           // domain
            $this->secure,               // secure
            true,                         // httponly
            $this->sameSite              // samesite
        );
    }

    public function clearRefresh(Response $res): void
    {

        $res->cookie(
            'xtoon',                     // name
            '',                      // value
            time() - 3600, // expires
            $this->path,                 // path
            '',                           // domain
            $this->secure,               // secure
            true,                         // httponly
            $this->sameSite              // samesite
        );
        
    }
}
