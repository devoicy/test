<?php

namespace Webtoon\Service;

use App;
use Database;
use PDO;
use Webtoon\Service\Logger;

final class WorkerManager 
{
    public function __construct(
        private Database $db,
        private Logger $logger
    ) {}

    public function startAllTasks()
    {
        // 1. TASK UTAMA: Sync Stats & Views (Tiap 60 Detik)
        \Swoole\Timer::tick(60000, function() {
            static $isRunning = false;
            if ($isRunning) return;

            \Swoole\Coroutine\go(function() use (&$isRunning) {
                $isRunning = true;
            	$start = microtime(true);
                $this->logger->info("[Worker0] Starting Sync Cycle");

                try {
                    $this->flushViewBuffer();
                    (new SyncStatsTask($this->db))->series();
                    (new SyncStatsTask($this->db))->chapter();

                    $duration = round(microtime(true) - $start, 4);
                    $this->logger->info("[Worker0] Sync Completed in {$duration}s");
                } catch (\Throwable $e) {
                    $this->logger->error($e, "Sync Cycle Error");
                } finally {
                    $isRunning = false;
                }
            });
        });

        // 2. TASK PEMELIHARAAN: Cleanup Tables (Tiap 5 Menit)
        // Kita pisahkan timernya agar tidak mengganggu ritme sync yang cepat
        \Swoole\Timer::tick(300000, function() {
            \Swoole\Coroutine\go(function() {
                $this->cleanUpTables();
            });
        });
    }

    /**
     * Membersihkan Cache dan Spam Table yang sudah expired di RAM
     */
    private function cleanUpTables()
    {
        $now = time();
        $cacheCleaned = 0;
        $spamCleaned = 0;

        // Bersihkan Cache Table
        // Swoole\Table aman untuk dihapus saat iterasi
        foreach (App::$cacheTable as $key => $row) {
            if ($row['expire_at'] < $now) {
                App::$cacheTable->del($key);
                $cacheCleaned++;
            }
        }
        
        // Bersihkan Spam Table (Hapus jika tidak aktif > 1 jam)
        foreach (App::$spamTable as $key => $row) {
            if (($now - $row['last_action']) > 3600) {
                App::$spamTable->del($key);
                $spamCleaned++;
            }
        }

        if ($cacheCleaned > 0 || $spamCleaned > 0) {
            $message = sprintf(
                "[Worker0] Cleanup: %d expired cache & %d idle spam records removed at %s\n",
                $cacheCleaned,
                $spamCleaned,
                date('H:i:s')
            );
            $this->logger->info($message);
        }
    }

    private function flushViewBuffer()
    {
        $buffer = App::$viewBuffer;
        $snapshot = [];
        $chapterIds = [];

        // 1. Ambil data dari RAM tanpa Lock
        foreach ($buffer as $id => $row) {
            if ($row['count'] > 0) {
                $snapshot[$id] = $row['count'];
                $chapterIds[] = $id;
            }
        }

        if (empty($chapterIds)) return;

        // 2. Transaksi Database
        $this->db->transaction(function ($pdo) use ($snapshot, $chapterIds, $buffer) {
            // Batch Select mapping
            $placeholders = implode(',', array_fill(0, count($chapterIds), '?'));
            $stmtMap = $pdo->prepare("SELECT id, series_id FROM chapters WHERE id IN ($placeholders)");
            $stmtMap->execute($chapterIds);
            $mappings = $stmtMap->fetchAll(PDO::FETCH_KEY_PAIR);

            $stmtChapter = $pdo->prepare("UPDATE chapter_stats SET views_count = views_count + ?, is_dirty = 1, version = version + 1 WHERE chapter_id = ?");
            $seriesAggregator = [];

            foreach ($mappings as $chapterId => $seriesId) {
                $views = $snapshot[$chapterId] ?? 0;
                if ($views <= 0) continue;

                // Update Chapter
                $stmtChapter->execute([$views, $chapterId]);
                
                // Agregasi Series
                $seriesAggregator[$seriesId] = ($seriesAggregator[$seriesId] ?? 0) + $views;

                // ATOMIC SUBTRACT: Kurangi hanya sebanyak yang sudah di-sync ke DB
                $buffer->incr($chapterId, 'count', -$views);
                
                // Cleanup jika sudah nol
                $current = $buffer->get($chapterId);
                if ($current && $current['count'] <= 0) {
                    $buffer->del($chapterId);
                }
            }

            // 3. Bulk Update Series (Upsert)
            if (!empty($seriesAggregator)) {
                $this->bulkUpdateSeries($pdo, $seriesAggregator);
            }
        });
    }

    private function bulkUpdateSeries($pdo, array $aggregator)
    {
        $rows = [];
        $values = [];
        foreach ($aggregator as $id => $val) {
            $rows[] = "(?, ?, 1, 1)";
            $values[] = $id;
            $values[] = $val;
        }

        $sql = "INSERT INTO series_stats (series_id, views_count, version, is_dirty) 
                VALUES " . implode(',', $rows) . " 
                ON DUPLICATE KEY UPDATE 
                views_count = views_count + VALUES(views_count), 
                version = version + 1, 
                is_dirty = 1";
        
        $pdo->prepare($sql)->execute($values);
    }
}