<?php

namespace Webtoon\Service;

final class Slugify
{
    public function execute(string $input): string
    {
        $slug = trim(mb_strtolower($input, 'UTF-8'));

        static $transliterator = null;
        static $nonAlnum = '/[^a-z0-9]+/i';
        static $multiDash = '/-+/';

        if ($transliterator === null && class_exists('\Transliterator')) {
            $t = \Transliterator::create('Any-Latin; Latin-ASCII');
            $transliterator = $t instanceof \Transliterator ? $t : false;
        }

        if ($transliterator) {
            $slug = $transliterator->transliterate($slug);
        }

        $slug = preg_replace($nonAlnum, '-', $slug) ?? '';
        $slug = preg_replace($multiDash, '-', $slug) ?? '';

        $slug = trim($slug, '-');

        // SEO length limit
        $slug = mb_substr($slug, 0, 75, 'UTF-8');
        $slug = rtrim($slug, '-');

        return $slug !== '' ? $slug : 'n-a';
    }
}