<?php

namespace Webtoon\Service;

use Database;
use PDO;
use Generator;
use Swoole\Database\PDOProxy;
use Swoole\Database\PDOStatementProxy;
use RuntimeException;

final class SyncStatsTask
{
    private readonly int $batchSize;

    public function __construct(
        private Database $db,
        int $batchSize = 100
    ) {
        $this->batchSize = $batchSize;
    }

    /**
     * SYNC SERIES STATS
     * Memindahkan akumulasi data dari series_stats ke series_summary.
     */
    public function series(): array
    {
        $config = new SyncConfig(
            statsTable: 'series_stats',
            summaryTable: 'series_summary',
            idColumn: 'series_id',
            columns: ['bookmark_count', 'views_count', 'comments_count', 'chapters_count', 'rating_count', 'rating_total']
        );
        return $this->syncTable($config);
    }

    /**
     * SYNC CHAPTER STATS
     * Memindahkan data views, comments, likes ke chapter_summary via UPDATE.
     */
    public function chapter(): array
    {
        $config = new SyncConfig(
            statsTable: 'chapter_stats',
            summaryTable: 'chapter_summary',
            idColumn: 'chapter_id',
            columns: ['views_count', 'comments_count', 'likes_count'] 
        );
        return $this->syncTable($config);
    }

    /**
     * CORE SYNC LOGIC
     * Menggunakan strategi UPDATE murni untuk menghindari error default value pada MySQL Strict Mode.
     */
    private function syncTable(SyncConfig $config): array
    {
        $processed = 0;
        $errors = [];

        try {
            $result = $this->db->transaction(function (PDO|PDOProxy $pdo) use ($config, &$processed, &$errors) {
                
                // 1. Fetch dirty rows (is_dirty = 1)
                $selectColumns = array_merge([$config->idColumn, 'version'], $config->columns);
                $stmt = $pdo->prepare("
                    SELECT " . implode(', ', $selectColumns) . "
                    FROM {$config->statsTable}
                    WHERE is_dirty = 1
                    LIMIT {$this->batchSize}
                ");
                $stmt->execute();

                $dirtyData = $this->fetchGenerator($stmt);

                // 2. Prepare Update Statement untuk Summary Table
                $setClause = implode(', ', array_map(fn($col) => "$col = :$col", $config->columns));
                $syncStmt = $pdo->prepare("
                    UPDATE {$config->summaryTable} 
                    SET $setClause 
                    WHERE {$config->idColumn} = :id_val
                ");

                // 3. Prepare Reset Statement untuk Stats Table (Optimistic Locking)
                $resetStmt = $pdo->prepare("
                    UPDATE {$config->statsTable}
                    SET is_dirty = 0
                    WHERE {$config->idColumn} = :id_val AND version = :v
                ");

                foreach ($dirtyData as $row) {
                    $idValue = $row[$config->idColumn];
                    try {
                        // Bind data kolom stats
                        $syncParams = [":id_val" => $idValue];
                        foreach ($config->columns as $col) {
                            $syncParams[":$col"] = $row[$col];
                        }
                        
                        // Execute Sync ke Summary
                        $syncStmt->execute($syncParams);

                        // Reset flag is_dirty di Stats jika version cocok
                        $resetStmt->execute([
                            ':id_val' => $idValue,
                            ':v'      => $row['version']
                        ]);

                        $processed++;
                    } catch (\Throwable $e) {
                        $errorMessage = "Sync failed for {$config->idColumn} #{$idValue}";
                        $errors[] = $errorMessage . ": " . $e->getMessage();
                        
                        // LOG ERROR KE DATABASE
                        $this->db->logError($e, $errorMessage);
                    }
                }
                return true;
            });

            if (!$result) {
                throw new RuntimeException("DB Transaction failed for {$config->statsTable}");
            }

            return ['success' => true, 'processed' => $processed, 'errors' => $errors];

        } catch (\Throwable $e) {
            $this->db->logError($e, "Critical error in SyncStatsTask for table {$config->statsTable}");
            return ['success' => false, 'processed' => $processed, 'errors' => [$e->getMessage()]];
        }
    }

    /**
     * Generator untuk fetch data secara stream (Memory efficient)
     */
    private function fetchGenerator(\PDOStatement|PDOStatementProxy $stmt): \Generator
    {
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            yield $row;
        }
    }
}

/**
 * Data Transfer Object untuk konfigurasi sinkronisasi
 */
readonly class SyncConfig
{
    public function __construct(
        public string $statsTable,
        public string $summaryTable,
        public string $idColumn,
        public array $columns
    ) {}
}