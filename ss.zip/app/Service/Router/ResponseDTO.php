<?php

declare(strict_types=1);

namespace Webtoon\Service\Router;

/**
 * PSR-7 like response abstraction
 */
final class ResponseDTO
{
    private int $statusCode = 200;
    private array $headers = [];
    private string $body = '';
    
    public static function json(array $data, int $status = 200): self
    {
        $response = new self();
        $response->statusCode = $status;
        $response->headers['Content-Type'] = 'application/json';
        $response->body = json_encode($data, JSON_UNESCAPED_UNICODE);
        return $response;
    }
    
    public static function html(string $html, int $status = 200): self
    {
        $response = new self();
        $response->statusCode = $status;
        $response->headers['Content-Type'] = 'text/html; charset=utf-8';
        $response->body = $html;
        return $response;
    }
    
    public static function redirect(string $url, int $status = 302): self
    {
        $response = new self();
        $response->statusCode = $status;
        $response->headers['Location'] = $url;
        return $response;
    }
    
    public function getStatusCode(): int
    {
        return $this->statusCode;
    }
    
    public function getHeaders(): array
    {
        return $this->headers;
    }
    
    public function getBody(): string
    {
        return $this->body;
    }
    
    public function withHeader(string $name, string $value): self
    {
        $clone = clone $this;
        $clone->headers[$name] = $value;
        return $clone;
    }
    
    public function withBody(string $body): self
    {
        $clone = clone $this;
        $clone->body = $body;
        return $clone;
    }
}