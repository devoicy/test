<?php

declare(strict_types=1);

namespace Webtoon\Service\Router;

use DI\Container;
use DI\ContainerBuilder;
use FastRoute\Dispatcher;
use FastRoute\RouteCollector;
use Swoole\Http\Request as SwooleRequest;
use Swoole\Http\Response as SwooleResponse;
use Webtoon\Service\Logger;
use Webtoon\Service\Router\RequestContext;
use Webtoon\Service\Router\ResponseDTO;
use JsonException;
use Throwable;

use function FastRoute\simpleDispatcher;
use function FastRoute\cachedDispatcher;

/**
 * Production-grade HTTP Router untuk Swoole
 * 
 * Fitur utama:
 * - Zero race conditions (Swoole-aware architecture)
 * - Full request isolation (prototype controllers/middleware)
 * - Route caching untuk cold start optimization
 * - PSR-compatible response abstraction
 * - Environment-aware configuration (dev/prod)
 * 
 * NOTE: Router HARUS di-initialize di onWorkerStart, bukan di onRequest
 * 
 * @package Webtoon\Service\Router
 */
final class Router
{
    /** @var Dispatcher|null FastRoute dispatcher instance */
    private ?Dispatcher $dispatcher = null;
    
    /** @var Container|null PHP-DI container instance */
    private ?Container $container = null;
    
    /** @var array Cache untuk route definitions sebelum di-compile */
    private array $routeCache = [];
    
    /** @var bool Flag untuk mencegah modifikasi routes setelah initialization */
    private bool $routesLocked = false;
    
    /** @var bool Flag untuk menandai router sudah di-initialize */
    private bool $initialized = false;
    
    /** @var array Service definitions untuk DI container */
    private array $serviceDefinitions;
    
    /** @var string Path ke route cache file (jika enabled) */
    private readonly string $cacheFile;
    
    /** @var bool Environment flag - true untuk production, false untuk development */
    private bool $isProduction;
    
    /** @var bool Enable DI container compilation untuk production */
    private bool $enableContainerCompilation;
    
    /** @var bool Enable route caching untuk cold start optimization */
    private bool $enableRouteCaching;

    /**
     * Router constructor
     * 
     * @param array $serviceDefinitions Service definitions untuk DI container
     * @param string|null $cacheDir Directory untuk cache files (routes dan container)
     * @param array $options Konfigurasi environment:
     *                      - 'environment' => 'production'|'development' (default: auto-detect)
     *                      - 'enable_container_compilation' => bool (default: true di production)
     *                      - 'enable_route_caching' => bool (default: true di production)
     */
    public function __construct(
        array $serviceDefinitions = [], 
        ?string $cacheDir = null,
        array $options = []
    ) {
        $this->serviceDefinitions = $serviceDefinitions;
        
        // Determine environment dari options atau auto-detect
        $this->determineEnvironment($options);
        
        // Setup route cache untuk cold start optimization
        $this->setupCacheFile($cacheDir);
        
        // Set optimization flags berdasarkan environment
        $this->setOptimizationFlags($options);
        
        // Log environment configuration
        $this->logConfiguration();
    }

    /**
     * Initialize router - HARUS dipanggil di onWorkerStart
     * 
     * Method ini melakukan:
     * 1. Build DI container dengan environment-aware settings
     * 2. Build route dispatcher dengan optional caching
     * 3. Lock routes untuk mencegah runtime modification
     * 
     * @throws \LogicException Jika dipanggil setelah initialization
     */
    public function initialize(): void
    {
        // Prevent double initialization
        if ($this->initialized) {
            throw new \LogicException('Router already initialized');
        }

        // Build components
        $this->buildContainer();
        $this->buildDispatcher();
        
        // Lock routes untuk mencegah runtime modification
        $this->routesLocked = true;
        $this->initialized = true;
        
        // Log successful initialization
        error_log(sprintf(
            'Router initialized (Environment: %s, Route Cache: %s, DI Compilation: %s)',
            $this->isProduction ? 'production' : 'development',
            $this->enableRouteCaching ? 'enabled' : 'disabled',
            $this->enableContainerCompilation ? 'enabled' : 'disabled'
        ));
    }

    /**
     * Build PHP-DI container dengan environment-aware configuration
     * 
     * Configuration per environment:
     * - Development: Autowiring enabled, compilation disabled untuk hot-reload
     * - Production: Autowiring enabled, compilation enabled untuk performance
     * 
     * @throws \DI\DependencyException Jika container build gagal
     */
    private function buildContainer(): void
    {
        $containerBuilder = new ContainerBuilder();
        
        // Configure berdasarkan environment
        $this->configureContainerBuilder($containerBuilder);
        
        // Merge semua definitions
        $definitions = array_merge(
            $this->getBaseDefinitions(),
            $this->serviceDefinitions,
            $this->getPrototypeDefinitions() // Semua stateful objects sebagai prototype
        );
        
        $containerBuilder->addDefinitions($definitions);
        $this->container = $containerBuilder->build();
        
        // Setup legacy compatibility (akan di-deprecate di versi 2.0)
        $this->setupLegacyCompatibility();
    }

    /**
     * Configure container builder berdasarkan environment
     * 
     * @param ContainerBuilder $containerBuilder
     */
    private function configureContainerBuilder(ContainerBuilder $containerBuilder): void
    {
        // Enable autowiring untuk semua environment (developer experience)
        $containerBuilder->useAutowiring(true);
        
        // Enable PHP 8 attributes untuk semua environment
        $containerBuilder->useAttributes(true);
        
        // Configure compilation hanya untuk production
        if ($this->enableContainerCompilation && $this->isProduction) {
            $this->enableContainerCompilation($containerBuilder);
        } else {
            error_log('DI Container compilation: DISABLED (development mode)');
        }
    }

    /**
     * Enable DI container compilation untuk production
     * 
     * @param ContainerBuilder $containerBuilder
     */
    private function enableContainerCompilation(ContainerBuilder $containerBuilder): void
    {
        if (!defined('CACHE_PATH')) {
            error_log('WARNING: CACHE_PATH not defined, DI compilation disabled');
            return;
        }
        
        $diCacheDir = CACHE_PATH . '/di';
        
        // Ensure cache directory exists
        if (!is_dir($diCacheDir) && !mkdir($diCacheDir, 0755, true)) {
            error_log("ERROR: Cannot create DI cache directory: {$diCacheDir}");
            return;
        }
        
        // Enable compilation
        $containerBuilder->enableCompilation($diCacheDir);
        $containerBuilder->writeProxiesToFile(true, $diCacheDir . '/proxies');
        
        error_log("DI Container compilation: ENABLED ({$diCacheDir})");
    }

    /**
     * Base service definitions dengan interface contracts
     * 
     * @return array Base definitions untuk DI container
     */
    private function getBaseDefinitions(): array
    {
        return [
            // Response abstractions
            ResponseDTO::class => \DI\create(ResponseDTO::class),
            
            // RequestContext harus dibuat manual per request (prototype)
            RequestContext::class => \DI\factory(function() {
                throw new \LogicException(
                    'RequestContext harus dibuat via createRequestContext()'
                );
            }),
            
            // Interface bindings contoh (uncomment jika diperlukan):
            // \Twig\Loader\LoaderInterface::class => \DI\get(\Twig\Loader\FilesystemLoader::class),
            // MiddlewareInterface::class => \DI\autowire(),
        ];
    }

    /**
     * Semua stateful objects HARUS prototype untuk isolasi request
     * 
     * Return array kosong karena semua definitions sudah di-handle oleh AppBootstrap
     * Gunakan method ini untuk menambahkan prototype definitions tambahan jika diperlukan
     * 
     * @return array Prototype definitions
     */
    private function getPrototypeDefinitions(): array
    {
        return [
            // Tambahkan prototype definitions di sini jika diperlukan
            // Contoh: SomePrototypeService::class => \DI\prototype(\DI\create(SomePrototypeService::class)),
        ];
    }

    /**
     * Build dispatcher dengan FastRoute + environment-aware caching
     * 
     * Configuration:
     * - Development: No caching untuk hot-reload routes
     * - Production: File caching untuk cold start optimization
     */
    private function buildDispatcher(): void
    {
        // Jika caching di-disable, gunakan simpleDispatcher
        if (!$this->enableRouteCaching || !$this->cacheFile || !$this->isProduction) {
            error_log('Route caching: DISABLED - using simpleDispatcher');
            
            $this->dispatcher = simpleDispatcher(
                function (RouteCollector $r) {
                    foreach ($this->routeCache as $route) {
                        $routeData = isset($route['middleware']) 
                            ? ['handler' => $route['handler'], 'middleware' => $route['middleware']]
                            : $route['handler'];
                        
                        $r->addRoute($route['method'], $route['path'], $routeData);
                    }
                }
            );
            return;
        }
        
        // Jika caching enabled, gunakan cachedDispatcher dengan cacheFile
        error_log("Route caching: ENABLED ({$this->cacheFile})");
        
        $this->dispatcher = cachedDispatcher(
            function (RouteCollector $r) {
                foreach ($this->routeCache as $route) {
                    $routeData = isset($route['middleware']) 
                        ? ['handler' => $route['handler'], 'middleware' => $route['middleware']]
                        : $route['handler'];
                    
                    $r->addRoute($route['method'], $route['path'], $routeData);
                }
            },
            [
                'cacheFile' => $this->cacheFile,
                'cacheDisabled' => false,
            ]
        );
    }

    /**
     * Add route dengan pre-initialization check
     * 
     * @param string $method HTTP method (GET, POST, etc.)
     * @param string $path Route path
     * @param array $handler [ClassName, methodName]
     * @param array $middleware Array of middleware class names
     * @return self Untuk method chaining
     * @throws \LogicException Jika routes sudah di-lock
     */
    private function addRoute(string $method, string $path, array $handler, array $middleware = []): self
    {
        $this->assertRoutesUnlocked();
        
        $this->routeCache[] = [
            'method' => strtoupper($method),
            'path' => $path,
            'handler' => $handler,
            'middleware' => $middleware
        ];
        
        return $this;
    }

    /**
     * Register GET route
     * 
     * @param string $path Route path
     * @param array $handler [ClassName, methodName]
     * @param array $middleware Array of middleware class names
     * @return self Untuk method chaining
     */
    public function get(string $path, array $handler, array $middleware = []): self
    {
        return $this->addRoute('GET', $path, $handler, $middleware);
    }

    /**
     * Register POST route
     * 
     * @param string $path Route path
     * @param array $handler [ClassName, methodName]
     * @param array $middleware Array of middleware class names
     * @return self Untuk method chaining
     */
    public function post(string $path, array $handler, array $middleware = []): self
    {
        return $this->addRoute('POST', $path, $handler, $middleware);
    }

    /**
     * Register PUT route
     * 
     * @param string $path Route path
     * @param array $handler [ClassName, methodName]
     * @param array $middleware Array of middleware class names
     * @return self Untuk method chaining
     */
    public function put(string $path, array $handler, array $middleware = []): self
    {
        return $this->addRoute('PUT', $path, $handler, $middleware);
    }

    /**
     * Register DELETE route
     * 
     * @param string $path Route path
     * @param array $handler [ClassName, methodName]
     * @param array $middleware Array of middleware class names
     * @return self Untuk method chaining
     */
    public function delete(string $path, array $handler, array $middleware = []): self
    {
        return $this->addRoute('DELETE', $path, $handler, $middleware);
    }

    /**
     * Handle HTTP request - Main entry point untuk request handling
     * 
     * Method ini:
     * 1. Validasi router sudah initialized
     * 2. Normalize URI
     * 3. Dispatch ke route handler
     * 4. Handle response atau errors
     * 
     * @param SwooleRequest $request Swoole HTTP request
     * @param SwooleResponse $response Swoole HTTP response
     */
    public function handle(SwooleRequest $request, SwooleResponse $response): void
    {
        // 🚨 Strict validation - router HARUS sudah initialized
        if (!$this->initialized) {
            $this->sendServiceUnavailable($response);
            return;
        }

        $httpMethod = $request->server['request_method'] ?? 'GET';
        $uri = $this->normalizeUri($request->server['request_uri'] ?? '/');

        $routeInfo = $this->dispatcher->dispatch($httpMethod, $uri);

        // Handle berdasarkan dispatch result
        match ($routeInfo[0]) {
            Dispatcher::NOT_FOUND => $this->handleNotFound($request, $response),
            Dispatcher::METHOD_NOT_ALLOWED => $this->handleMethodNotAllowed($routeInfo[1], $response),
            Dispatcher::FOUND => $this->handleFoundRoute($routeInfo, $request, $response),
        };
    }

    /**
     * Handle found route dengan full isolation
     * 
     * @param array $routeInfo Route information dari FastRoute
     * @param SwooleRequest $request Swoole HTTP request
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function handleFoundRoute(array $routeInfo, SwooleRequest $request, SwooleResponse $response): void
    {
        $handler = $routeInfo[1];
        $vars = $routeInfo[2];
        
        $context = $this->createRequestContext($request, $response, $vars);
        
        // Handle dengan atau tanpa middleware
        if (is_array($handler) && isset($handler['middleware'])) {
            $this->handleWithMiddleware($handler, $context);
        } else {
            $this->executeHandler($handler, $context);
        }
    }

    /**
     * Handle request dengan middleware chain
     * 
     * Flow:
     * 1. Build middleware pipeline dari belakang ke depan
     * 2. Setiap middleware menerima $next handler
     * 3. Controller adalah handler terakhir
     * 4. Result dari pipeline di-handle oleh router
     * 
     * @param array $handler Route handler dengan middleware
     * @param RequestContext $context Request context
     */
    private function handleWithMiddleware(array $handler, RequestContext $context): void
    {
        try {
            [$className, $method] = $handler['handler'];
            
            // Simpan params dari context
            $routeParams = $context->params;
            
            // Final handler untuk controller (paling dalam di pipeline)
            $controllerHandler = function ($req, $res) use ($className, $method, $routeParams) {
                $controller = $this->container->make($className); // Prototype
                return $controller->$method($req, $res, $routeParams);
            };

            // Parse middleware array
            $middlewares = is_array($handler['middleware']) 
                ? $handler['middleware'] 
                : (isset($handler['middleware']) ? [$handler['middleware']] : []);
            
            // Build pipeline dari belakang ke depan
            $pipeline = $controllerHandler;
            
            foreach (array_reverse($middlewares) as $middlewareClass) {
                $next = $pipeline;
                
                $pipeline = function ($req, $res) use ($middlewareClass, $next) {
                    $middleware = $this->container->get($middlewareClass);
                    
                    // Support untuk __invoke() dan handle() method
                    if (is_callable($middleware)) {
                        return $middleware($req, $res, $next);
                    }
                    
                    if (method_exists($middleware, 'handle')) {
                        return $middleware->handle($req, $res, $next);
                    }
                    
                    // Fallback: langsung ke next handler
                    return $next($req, $res);
                };
            }
            
            // Jalankan pipeline
            $result = $pipeline($context->request, $context->response);
            
            // Handle result dari pipeline (bisa dari middleware atau controller)
            $this->handleResponse($result, $context->response);
            
        } catch (Throwable $e) {
            $this->handleError($e, $context);
        }
    }

    /**
     * Execute controller handler tanpa middleware
     * 
     * @param array $handler Route handler [ClassName, methodName]
     * @param RequestContext $context Request context
     */
    private function executeHandler(array $handler, RequestContext $context): void
    {
        try {
            [$className, $method] = $handler;
            
            // 🚨 CONTROLLER PROTOTYPE: make() bukan get()
            $controller = $this->container->make($className);
            
            // Panggil controller dengan standardized interface
            $result = $controller->$method($context->request, $context->response, $context->params);
            
            $this->handleResponse($result, $context->response);
        } catch (Throwable $e) {
            $this->handleError($e, $context);
        }
    }

    /**
     * 404 Not Found dengan intelligent content negotiation
     * 
     * Method ini:
     * 1. Cek Accept header client
     * 2. Return JSON response untuk API clients
     * 3. Return HTML response untuk web browsers
     * 4. Fallback ke plain text
     * 
     * @param SwooleRequest $request Swoole HTTP request
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function handleNotFound(SwooleRequest $request, SwooleResponse $response): void
    {
        $accept = $request->header['accept'] ?? 'text/html';
        
        // JSON response untuk API clients
        if (str_contains($accept, 'application/json')) {
            $response->status(404);
            $response->header('Content-Type', 'application/json');
            $response->end(json_encode([
                'error' => 'Not Found',
                'path' => $request->server['request_uri'] ?? '/'
            ]));
            return;
        }
        
        // HTML fallback untuk web browsers
        try {
            $twig = $this->container?->get(\Twig\Environment::class);
            if ($twig) {
                $response->status(404);
                $response->header('Content-Type', 'text/html; charset=utf-8');
                $response->end($twig->render('error.html', [
                    'code' => 404,
                    'path' => $request->server['request_uri'] ?? '/',
                    'title' => '404 Not Found'
                ]));
                return;
            }
        } catch (Throwable) {
            // Fall through jika template tidak tersedia
        }
        
        // Plain text fallback
        $response->status(404);
        $response->end('Not Found');
    }

    /**
     * 405 Method Not Allowed dengan dynamic Allow header
     * 
     * @param array $allowedMethods Array of allowed HTTP methods
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function handleMethodNotAllowed(array $allowedMethods, SwooleResponse $response): void
    {
        $response->status(405);
        $response->header('Allow', implode(', ', $allowedMethods));
        
        $response->header('Content-Type', 'application/json');
        $response->end(json_encode([
            'error' => 'Method Not Allowed',
            'allowed' => $allowedMethods
        ]));
    }

    /**
     * 503 Service Unavailable (router not initialized)
     * 
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function sendServiceUnavailable(SwooleResponse $response): void
    {
        $response->status(503);
        $response->header('Retry-After', '2');
        $response->header('Content-Type', 'application/json');
        
        $response->end(json_encode([
            'error' => 'Service Unavailable',
            'message' => 'Router not initialized'
        ]));
        
        error_log('CRITICAL: Router accessed before initialization');
    }

    /**
     * Response handling dengan PSR-like abstraction
     * 
     * Support untuk berbagai return types:
     * 1. ResponseDTO object (PSR-like)
     * 2. Array (auto-convert to JSON)
     * 3. String HTML content
     * 4. Plain string
     * 5. Other types (converted to string)
     * 
     * @param mixed $result Result dari controller/middleware
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function handleResponse(mixed $result, SwooleResponse $response): void
    {
        if ($result === null) {
            return; // Controller sudah handle response sendiri
        }
        
        // Jika controller return ResponseDTO, gunakan abstraction
        if ($result instanceof ResponseDTO) {
            $this->sendResponseDTO($result, $response);
            return;
        }
        
        // Auto-detection untuk backward compatibility
        match (true) {
            is_array($result) => $this->sendJson($result, $response),
            is_string($result) && $this->isHtml($result) => 
                $this->sendHtml($result, $response),
            is_string($result) => $response->end($result),
            default => $response->end((string)$result)
        };
    }

    /**
     * Send JSON response dengan safe encoding dan compression
     * 
     * @param array $data Data array untuk di-encode ke JSON
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function sendJson(array $data, SwooleResponse $response): void
    {
        try {
            $json = json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
            
            // Gzip compression jika client support dan data cukup besar
            if (extension_loaded('zlib') && strlen($json) > 1024) {
                $compressed = gzencode($json, 6);
                if ($compressed !== false) {
                    $response->header('Content-Encoding', 'gzip');
                    $json = $compressed;
                }
            }
            
            $response->header('Content-Type', 'application/json; charset=utf-8');
            $response->end($json);
            
        } catch (JsonException $e) {
            $this->handleJsonError($e, $response);
        }
    }

    /**
     * Send HTML response
     * 
     * @param string $html HTML content
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function sendHtml(string $html, SwooleResponse $response): void
    {
        $response->header('Content-Type', 'text/html; charset=utf-8');
        $response->end($html);
    }

    /**
     * Send PSR-like ResponseDTO
     * 
     * @param ResponseDTO $responseDto Response DTO object
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function sendResponseDTO(ResponseDTO $responseDto, SwooleResponse $response): void
    {
        $response->status($responseDto->getStatusCode());
        
        foreach ($responseDto->getHeaders() as $name => $values) {
            foreach ((array)$values as $value) {
                $response->header($name, $value);
            }
        }
        
        $response->end($responseDto->getBody());
    }

    /**
     * Error handling dengan proper logging
     * 
     * @param Throwable $e Exception yang terjadi
     * @param RequestContext $context Request context
     */
    private function handleError(Throwable $e, RequestContext $context): void
    {
        try {
            // Log error dengan context information
            $logger = $this->container?->get(Logger::class);
            $logger?->error($e, json_encode([
                'uri' => $context->request->server['request_uri'] ?? '/',
                'method' => $context->request->server['request_method'] ?? 'GET',
                'params' => $context->params
            ]));
            
            // Send client-friendly error response
            $this->sendErrorResponse($e, $context->response);
            
        } catch (Throwable $inner) {
            // Last resort jika error handling sendiri error
            $context->response->status(500);
            $context->response->end('Internal Server Error');
            error_log('Router error handling failed: ' . $inner->getMessage());
        }
    }

    /**
     * Create isolated request context untuk setiap request
     * 
     * @param SwooleRequest $request Swoole HTTP request
     * @param SwooleResponse $response Swoole HTTP response
     * @param array $params Route parameters
     * @return RequestContext Request context object
     */
    private function createRequestContext(SwooleRequest $request, SwooleResponse $response, array $params): RequestContext
    {
        return new RequestContext($request, $response, $params);
    }

    /**
     * Determine environment dari options atau auto-detect
     * 
     * @param array $options Konfigurasi options
     */
    private function determineEnvironment(array $options): void
    {
        // Priority: 1. Manual option, 2. Environment variable, 3. Auto-detect
        if (isset($options['environment'])) {
            $this->isProduction = $options['environment'] === 'production';
        } elseif (getenv('APP_ENV') !== false) {
            $this->isProduction = getenv('APP_ENV') === 'production';
        } else {
            // Auto-detect: production jika bukan CLI atau ada specific flags
            $this->isProduction = PHP_SAPI !== 'cli' || 
                                 (defined('APP_PRODUCTION') && APP_PRODUCTION === true);
        }
    }

    /**
     * Setup cache file untuk route caching
     * 
     * @param string|null $cacheDir Cache directory
     */
    private function setupCacheFile(?string $cacheDir): void
    {
        if ($cacheDir && is_writable($cacheDir)) {
            $this->cacheFile = rtrim($cacheDir, '/') . '/routes.cache';
        } else {
            $this->cacheFile = '';
            if ($cacheDir) {
                error_log("WARNING: Cache directory not writable: {$cacheDir}");
            }
        }
    }

    /**
     * Set optimization flags berdasarkan environment
     * 
     * @param array $options Konfigurasi options
     */
    private function setOptimizationFlags(array $options): void
    {
        // Priority: 1. Manual option, 2. Environment-based default
        $this->enableContainerCompilation = $options['enable_container_compilation'] 
            ?? ($this->isProduction && $this->cacheFile !== '');
            
        $this->enableRouteCaching = $options['enable_route_caching'] 
            ?? ($this->isProduction && $this->cacheFile !== '');
    }

    /**
     * Log router configuration
     */
    private function logConfiguration(): void
    {
        error_log(sprintf(
            'Router configured: Environment=%s, DI Compilation=%s, Route Caching=%s',
            $this->isProduction ? 'production' : 'development',
            $this->enableContainerCompilation ? 'enabled' : 'disabled',
            $this->enableRouteCaching ? 'enabled' : 'disabled'
        ));
    }

    /**
     * Check if running in production environment
     * 
     * @return bool True jika production, false jika development
     */
    public function isProduction(): bool
    {
        return $this->isProduction;
    }

    /**
     * Normalize URI untuk konsistensi routing
     * 
     * @param string $uri Raw URI
     * @return string Normalized URI
     */
    private function normalizeUri(string $uri): string
    {
        $uri = strstr($uri, '?', true) ?: $uri;
        $uri = rawurldecode($uri);
        
        // Remove duplicate slashes
        $uri = preg_replace('#/+#', '/', $uri);
        
        return $uri ?: '/';
    }

    /**
     * Detect HTML content dari string
     * 
     * @param string $content Content string
     * @return bool True jika content HTML
     */
    private function isHtml(string $content): bool
    {
        return str_starts_with(trim($content), '<!DOCTYPE') 
            || str_starts_with(trim($content), '<html')
            || str_contains($content, '<body');
    }

    /**
     * Setup legacy compatibility (akan di-deprecate di versi 2.0)
     */
    private function setupLegacyCompatibility(): void
    {
        if (class_exists('App')) {
            \App::$container = $this->container;
        }
    }

    /**
     * JSON encoding error handler
     * 
     * @param JsonException $e JSON encoding exception
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function handleJsonError(JsonException $e, SwooleResponse $response): void
    {
        $response->status(500);
        $response->header('Content-Type', 'application/json');
        
        $response->end(json_encode([
            'error' => 'Internal Server Error',
            'message' => 'Failed to encode response'
        ]));
    }

    /**
     * Client-friendly error response berdasarkan environment
     * 
     * Development: Detailed error dengan stack trace
     * Production: Generic error message tanpa details
     * 
     * @param Throwable $e Exception
     * @param SwooleResponse $response Swoole HTTP response
     */
    private function sendErrorResponse(Throwable $e, SwooleResponse $response): void
    {
        if (!$this->isProduction) {
            // Development: detailed error dengan stack trace
            $response->status(500);
            $response->header('Content-Type', 'text/plain');
            $response->end(sprintf(
                "Error: %s\nFile: %s:%d\nTrace:\n%s",
                $e->getMessage(),
                $e->getFile(),
                $e->getLine(),
                $e->getTraceAsString()
            ));
            return;
        }
        
        // Production: generic error tanpa details
        try {
            $twig = $this->container?->get(\Twig\Environment::class);
            if ($twig) {
                $response->status(500);
                $response->header('Content-Type', 'text/html; charset=utf-8');
                $response->end($twig->render('error.html', [
                    'code' => 500,
                    'title' => 'Internal Server Error',
                    'message' => 'Something went wrong. Our team has been notified.'
                ]));
                return;
            }
        } catch (Throwable) {
            // Fall through jika template error
        }
        
        // Fallback ke plain text
        $response->status(500);
        $response->end('Internal Server Error');
    }

    /**
     * Assert routes belum di-lock (untuk mencegah runtime modification)
     * 
     * @throws \LogicException Jika routes sudah di-lock
     */
    private function assertRoutesUnlocked(): void
    {
        if ($this->routesLocked) {
            throw new \LogicException(
                'Routes cannot be modified after initialization. ' .
                'Add all routes before calling initialize() in onWorkerStart.'
            );
        }
    }

    /**
     * Get container instance untuk testing atau advanced usage
     * 
     * @return Container|null DI Container instance
     */
    public function getContainer(): ?Container
    {
        return $this->container;
    }

    /**
     * Check if router is initialized
     * 
     * @return bool True jika sudah initialized
     */
    public function isInitialized(): bool
    {
        return $this->initialized;
    }

    /**
     * Get route cache file path
     * 
     * @return string Cache file path atau empty string
     */
    public function getCacheFile(): string
    {
        return $this->cacheFile;
    }

    /**
     * Get environment configuration untuk debugging
     * 
     * @return array Environment configuration
     */
    public function getConfiguration(): array
    {
        return [
            'environment' => $this->isProduction ? 'production' : 'development',
            'container_compilation' => $this->enableContainerCompilation,
            'route_caching' => $this->enableRouteCaching,
            'cache_file' => $this->cacheFile,
            'initialized' => $this->initialized,
            'routes_locked' => $this->routesLocked,
        ];
    }
}