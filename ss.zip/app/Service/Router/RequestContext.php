<?php

declare(strict_types=1);

namespace Webtoon\Service\Router;

use Swoole\Http\Request;
use Swoole\Http\Response;

/**
 * Immutable request context untuk isolasi request
 */
final readonly class RequestContext
{
    public function __construct(
        public Request $request,
        public Response $response,
        public array $params
    ) {}
    
    public function getQuery(string $key, mixed $default = null): mixed
    {
        return $this->request->get[$key] ?? $default;
    }
    
    public function getPost(string $key, mixed $default = null): mixed
    {
        return $this->request->post[$key] ?? $default;
    }
    
    public function getHeader(string $key, mixed $default = null): mixed
    {
        return $this->request->header[strtolower($key)] ?? $default;
    }
    
    public function getParam(string $key, mixed $default = null): mixed
    {
        return $this->params[$key] ?? $default;
    }
    
    public function getMethod(): string
    {
        return $this->request->server['request_method'] ?? 'GET';
    }
    
    public function getUri(): string
    {
        return $this->request->server['request_uri'] ?? '/';
    }
    
    public function acceptsJson(): bool
    {
        $accept = $this->getHeader('accept', '');
        return str_contains($accept, 'application/json');
    }
    
    public function acceptsHtml(): bool
    {
        $accept = $this->getHeader('accept', '');
        return str_contains($accept, 'text/html');
    }
}