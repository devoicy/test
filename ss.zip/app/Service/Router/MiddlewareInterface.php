<?php

declare(strict_types=1);

namespace Webtoon\Service\Router;

use Swoole\Http\Request;
use Swoole\Http\Response;

interface MiddlewareInterface
{
    /**
     * Process HTTP request
     * 
     * @param Request $request
     * @param Response $response
     * @param callable $next Next middleware/handler
     * @return mixed
     */
    public function handle(Request $request, Response $response, array $args, callable $next): mixed;
}