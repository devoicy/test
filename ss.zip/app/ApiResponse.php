<?php

namespace Webtoon;

use Swoole\Http\Response;
// app/ApiResponse.php
/*
200 OK: Request berhasil.
201 Created: Berhasil membuat data baru (POST).
400 Bad Request: Kesalahan input dari sisi client.
401 Unauthorized: User belum login/token tidak valid.
403 Forbidden: User sudah login tapi tidak punya hak akses.
404 Not Found: Resource tidak ditemukan.
500 Internal Server Error: Ada bug/error di sisi server.
*/
class ApiResponse {
    public function data(Response $response, mixed $data, int $code = 200, mixed $pagination = null): array {

        $response->status($code);

        if(!$pagination) return [
            'status' => $code,
            'data' => $data
        ];

        return [
            'status' => $code,
            'data' => $data,
            'pagination' => $pagination
        ];
    }

    public function message(Response $response, string $message, int $code = 200): array {

        $response->status($code);

        return [
            'status' => $code,
            'message' => $message
        ];
    }
}