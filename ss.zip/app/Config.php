<?php

namespace Webtoon;

class Config
{
    private array $data = []; // ❌ Hapus static
    
    // ✅ Ganti constructor menjadi public untuk instansiasi DI
    public function __construct() {} 

    /**
     * Memuat file konfigurasi ke memori (Non-Static).
     */
    public function load(string $path)
    {
        if (empty($this->data)) {
            $this->data = require $path;
        }
    }

    /**
     * Mengambil nilai konfigurasi (Non-Static).
     */
    public function get(string $key, $default = null): mixed
    {
        $keys = explode('.', $key);
        $temp = $this->data; // Ambil dari $this->data
        
        // ... (Logika eksplorasi array tetap sama) ...
        foreach ($keys as $k) {
            if (is_array($temp) && array_key_exists($k, $temp)) { // Pengecekan lebih aman
                $temp = $temp[$k];
            } else {
                return $default;
            }
        }
        return $temp;
    }
}