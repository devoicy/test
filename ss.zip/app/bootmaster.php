<?php
use App;


// ---------------- SHARED MEMORY ----------------
$cacheTable = new \Swoole\Table(1024); // Pastikan ukuran cukup
$cacheTable->column('data', \Swoole\Table::TYPE_STRING, 65535); // Data size (64KB)
$cacheTable->column('expire_at', \Swoole\Table::TYPE_INT);
$cacheTable->column('type', \Swoole\Table::TYPE_STRING, 50); // Tambahkan kolom ini
$cacheTable->create(); // 🔥 INI PENTING! 🔥

App::$cacheTable = $cacheTable;

// 2048 baris cuma makan RAM sekitar puluhan KB (Irit banget!)
$spamTable = new \Swoole\Table(2048);
$spamTable->column('last_action', \Swoole\Table::TYPE_INT); // Simpan timestamp
$spamTable->column('count', \Swoole\Table::TYPE_INT);       // Bisa buat hitung berapa kali dia nyoba spam
$spamTable->create();

App::$spamTable = $spamTable;

$viewBuffer = new Swoole\Table(1024 * 50); // Muat 50rb series
$viewBuffer->column('count', \Swoole\Table::TYPE_INT);
$viewBuffer->create();

App::$viewBuffer = $viewBuffer;