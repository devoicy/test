<?php

namespace Webtoon\Middleware;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Closure;
use Webtoon\Models\Auth\UserFindById;
use Webtoon\Models\Auth\UserGetToken;
use Webtoon\Models\Auth\UserDeleteToken;
use Webtoon\Models\Auth\UserCreateRefreshToken;
use Webtoon\Service\Cookie;
use Webtoon\Service\eJWT;
use Webtoon\ApiResponse;

use Throwable; 

final class Door
{
    // Konstan untuk nama atribut dan cookie
    private const AUTH_PAYLOAD_KEY = 'xtoon_payload'; 
    private const COOKIE_NAME = 'xtoon';

    // ... (Constructor tetap sama, bagus) ...
    public function __construct(
        private readonly eJWT $jwt, 
        private readonly UserFindById $userFindById,
        private readonly UserGetToken $userGetToken,
        private readonly UserDeleteToken $userDeleteToken,
        private readonly UserCreateRefreshToken $userCreateRefreshToken,
        private readonly Cookie $cookie,
        private readonly ApiResponse $apiResponse
    ) {}

    // ==================================================
    // ENTRY POINT
    // ==================================================
    public function __invoke(
        Request $req,
        Response $res,
        Closure $next
    ): mixed {

        // ... (Logika get token & unauthorized tetap sama) ...
        $token = $this->getTokenFromCookie($req);
        if (!$token) {
            return $this->unauthorized(
                $res,
                'Authentication required',
                'Missing auth cookie'
            );
        }

        // 1️⃣ Coba verifikasi Access Token
        try {
            $payload = $this->jwt->verifyAccessToken($token);
            // Access Token valid, lanjutkan
            return $this->attachPayloadAndNext($req, $res, $next, $payload);
        } catch (\Firebase\JWT\ExpiredException $e) {
            // 2️⃣ TANGKAP: Expired Token! Ini adalah sinyal untuk lanjut ke Refresh Flow.
            // TIDAK ADA error_log di sini karena sudah di-log di eJWT
            // Ambil payload yang SUDAH TERVERIFIKASI signature-nya lewat eJWT
            $payload = $this->jwt->getPayloadFromExpired($token);
            
            if (!$payload) {
                return $this->unauthorized($res, 'Invalid session', 'Fail to extract payload');
            }
            return $this->handleRefreshFlow($req, $res, $next, $token);

        } catch (\Throwable $e) {
            // 3️⃣ TANGKAP: Gagal Verifikasi, Signature Invalid, atau Token Malformed (Runtime Exception)
            // Jika sampai sini, token sudah pasti rusak, dan BUKAN hanya expired.
            return $this->unauthorized(
                $res,
                'Invalid session',
                'Token verification failed (Signature Invalid/Malformed)'
            );
        }

    }

    // ==================================================
    // TOKEN HELPERS
    // ==================================================
    private function getTokenFromCookie(Request $req): ?string
    {
        return $req->cookie[self::COOKIE_NAME] ?? null;
    }

    /**
     * Melampirkan payload user ke objek Request sebelum menjalankan handler.
     * Menggunakan $req->get sebagai WORKAROUND untuk 'attributes' di Swoole murni.
     */
    private function attachPayloadAndNext(
        Request $req,
        Response $res,
        Closure $next,
        object $payload
    ): mixed {
        // 🚨 PURE SWOOLE WORKAROUND: Melampirkan payload ke array 'get'.
        $req->get[self::AUTH_PAYLOAD_KEY] = $payload; 
        
        return $next($req, $res);
    }

    // ==================================================
    // REFRESH FLOW (Logika tetap aman dan solid)
    // ==================================================
    private function handleRefreshFlow(
        Request $req,
        Response $res,
        Closure $next,
        string $expiredToken
    ): mixed {
        // ... (Logika decode, get stored token, cek expire, find user) ...
        $payload = $this->decodeWithoutVerify($expiredToken);
        if (!$payload || empty($payload->key)) {
            return $this->unauthorized(
                $res,
                'Invalid session',
                'Malformed JWT payload after expiration'
            );
        }

        $stored = $this->userGetToken->execute($payload->key);
        if (!$stored) {
            return $this->unauthorized(
                $res,
                'Session not found',
                'Refresh token ID not found in database'
            );
        }

        if (strtotime($stored['expires_at']) < time()) {
            $this->userDeleteToken->execute($payload->key); 
            return $this->unauthorized(
                $res,
                'Session expired',
                'Refresh token expired'
            );
        }

        $user = $this->userFindById->execute($stored['user_id']);
        if (!$user) {
            $this->userDeleteToken->execute($payload->key); 
            return $this->unauthorized(
                $res,
                'Invalid session',
                'User not found for given session'
            );
        }
        
        // Token Rotation: Token lama dijamin akan di-overwrite oleh issueNewTokens
        return $this->issueNewTokens($req, $res, $next, $user);
    }

    // ==================================================
    // TOKEN REISSUE (Logika tetap aman dan solid)
    // ==================================================
    private function issueNewTokens(
        Request $req,
        Response $res,
        Closure $next,
        array $user
    ): mixed {
        // A. Buat Refresh Token baru
        $refresh = $this->jwt->createRefreshToken();

        // B. Simpan/Overwrite Refresh Token baru di DB (menghapus yang lama)
        try {
            $success = $this->userCreateRefreshToken->execute(
                $user['id'],
                $refresh['token'],
                $refresh['expires']
            );
            if (!$success) {
                throw new \RuntimeException("Failed to save new refresh token.");
            }
        } catch (Throwable $e) {
            return $this->unauthorized(
                $res,
                'Server error',
                'Failed to persist new session token: ' . $e->getMessage()
            );
        }


        // C. Buat Access Token baru
        $newAccessTokenPayload = [
            'key'  => $refresh['token'], 
            'id'   => $user['id'],
            'role' => $user['role'],
        ];
        $access = $this->jwt->createAccessToken($newAccessTokenPayload);

        // D. Set cookie baru ke client
        $this->cookie->setRefresh( 
            $res, 
            $access, 
            $refresh['expires']
        );

        // E. Lanjutkan ke proses berikutnya
        try {
            // 1. Verifikasi Access Token yang BARU DIBUAT (Zero Trust Check)
            $verifiedPayload = $this->jwt->verifyAccessToken($access); 

            // 2. Attach hasil VERIFIKASI ke Request
            return $this->attachPayloadAndNext(
                $req, 
                $res, 
                $next, 
                $verifiedPayload // <<< Menggunakan hasil verifikasi
            );
        } catch (Throwable $e) {
            // Jika verifikasi token yang baru dibuat gagal, ini adalah kegagalan sistem SERIUS.
            return $this->unauthorized(
                $res,
                'Authentication failed',
                'CRITICAL: Failed verifying reissued access token (' . $e->getMessage() . ')'
            );
        }
    }

    // ... (decodeWithoutVerify dan unauthorized tetap sama, bagus) ...
    private function decodeWithoutVerify(string $jwt): ?object
    {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) {
            return null;
        }

        $decoded = base64_decode($parts[1], true);
        if ($decoded === false) {
             return null;
        }
        
        $payload = json_decode($decoded);
        
        return is_object($payload) ? $payload : null;
    }

    private function unauthorized(
        Response $res,
        string $clientMessage,
        string $logMessage
    ) { 
        

        //error_log('[AUTH] ' . $logMessage);
        
        return $this->apiResponse->message($res, $clientMessage, 401);
    }
}