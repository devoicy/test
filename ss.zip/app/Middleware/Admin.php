<?php

namespace Webtoon\Middleware; // Sesuaikan namespace

use Swoole\Http\Request;
use Swoole\Http\Response;
use Closure;

class Admin
{

    // __invoke() adalah method yang akan dipanggil oleh Router kamu
    public function __invoke(Request $req, Response $res, Closure $next): mixed
    {
        $payload = $req->get['xtoon_payload'] ?? null;
//var_dump($payload);
        if ($payload?->role === 'admin') { 
            // PERBAIKAN KRUSIAL: Tambahkan 'return'
            return $next($req, $res); 
        }

        // Gagal Otorisasi (403)
        $res->status(403);
        $res->end(error('Forbidden. Requires administrator access.'));
        return null;
    }
}