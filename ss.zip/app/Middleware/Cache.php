<?php
declare(strict_types=1);

namespace Webtoon\Middleware;

use Swoole\Http\Request;
use Swoole\Http\Response;
use Webtoon\Config;
use Closure;
use App;

class Cache {

    private bool $isCacheEnabled;
    private string $cacheDriver;

    public function __construct(
        private Config $config
    ) {
        $this->isCacheEnabled = $config->get('site.cache') ?? false;
        $this->cacheDriver = $config->get('site.system') ?? 'apcu';
    }

    public function __invoke(Request $req, Response $res, Closure $next)
    {
        $method = $req->server['request_method'] ?? 'GET';
        $path   = $req->server['request_uri']    ?? '/';
        $query  = $req->server['query_string']   ?? '';
        
        // 1. Cek kondisi caching
        if ($method !== 'GET' || !$this->isCacheEnabled) {
            return $next($req, $res);
        }

        // 2. Cek path yang harus di-skip
        foreach (['/admin', '/callback', '/api/a', '/status'] as $skip) {
            if (str_starts_with($path, $skip)) {
                return $next($req, $res);
            }
        }
        
        // 3. Buat cache key
        $key = hash('crc32b', ($path . '?' . $query));
        
        // 5. Cache MISS - eksekusi controller
        $result = $next($req, $res);
        
        // 6. Jika controller mengembalikan null atau false, skip caching
        if ($result === null || $result === false) {
            return $result;
        }
        
        // 7. Konversi hasil controller ke string untuk caching
        $output = $this->convertToString($result);
        
        // 8. Tentukan content type
        $contentType = $this->determineContentType($result);
        
        // 9. Store ke cache
        $ttl = 300; // 5 menit
        
        if ($this->cacheDriver === 'swoole') {
            $cacheTable = App::$cacheTable ?? null;
            if ($cacheTable) {
                $cacheTable->set($key, [
                    'data'      => $output,
                    'expire_at' => time() + $ttl,
                    'type'      => $contentType
                ]);
            }
        } else {
            $data = [
                'data'  => $output,
                'type'  => $contentType,
            ];
            apcu_store($key, $data, $ttl);
        }
        
        // 10. Set headers
        $res->header('Content-Type', $contentType);
        $res->header('X-Cache', 'MISS');
        
        // 11. Kirim response (biar router yang handle, atau kita kirim langsung)
        // Karena controller return data, bukan langsung kirim
        return $result;
    }
    
    /**
     * Konversi hasil controller ke string untuk caching
     */
    private function convertToString(mixed $data): string
    {
        if (is_array($data) || is_object($data)) {
            return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }
        
        if (is_string($data)) {
            return $data;
        }
        
        if (is_numeric($data)) {
            return (string)$data;
        }
        
        if (is_bool($data)) {
            return $data ? 'true' : 'false';
        }
        
        return '';
    }
    
    /**
     * Tentukan Content-Type berdasarkan tipe data
     */
    private function determineContentType(mixed $data): string
    {
        if (is_array($data) || is_object($data)) {
            return 'application/json';
        }
        
        if (is_string($data)) {
            // Cek apakah string mengandung HTML
            if (str_starts_with(trim($data), '<!DOCTYPE') || 
                str_starts_with(trim($data), '<html') ||
                str_contains($data, '<body>')) {
                return 'text/html; charset=utf-8';
            }
        }
        
        return 'text/plain; charset=utf-8';
    }
}