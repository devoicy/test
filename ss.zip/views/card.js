<script>
/********************
 * CONFIG VARIABLES *
 ********************/
const DB_NAME = 'MyDB';
const DB_VERSION = 1;
const LIMIT = 25; // jumlah item per page
const STORE_NAME = 'files';
const FILE_ID = 'largeFile';
const FILE_URL = 'a.bin'; // ganti URL
const ONE_DAY = 24 * 60 * 60 * 1000; // 1 hari dalam ms

let db;
let currentResults = [];
let currentPage = 1;
let totalPages = 1;

/********************
 * DOM ELEMENTS *
 ********************/
const input = document.getElementById('searchInput');
const ul = document.getElementById('results');
const pageContainer = document.getElementById('pagination');

/********************
 * OPEN INDEXEDDB *
 ********************/
const openRequest = indexedDB.open(DB_NAME, DB_VERSION);
openRequest.onupgradeneeded = e => {
  db = e.target.result;
  if(!db.objectStoreNames.contains(STORE_NAME)) {
    db.createObjectStore(STORE_NAME, { keyPath: 'id' });
  }
};
openRequest.onsuccess = e => {
  db = e.target.result;
  checkAndUpdateFile().then(() => loadAllData());
};

/***** Helper Functions *****/
async function getFileBlob(id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const getRequest = store.get(id);
    getRequest.onsuccess = () => resolve(getRequest.result?.data || null);
    getRequest.onerror = err => reject(err);
  });
}

async function getSeriesData() {
  const blob = await getFileBlob(FILE_ID);
  if(!blob) return null;
  const bytes = new Uint8Array(await blob.arrayBuffer());
  return msgpack.decode(bytes);
}

function saveFileBlob(blob) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put({ id: FILE_ID, data: blob, lastUpdated: Date.now() });
    tx.oncomplete = () => resolve();
    tx.onerror = err => reject(err);
  });
}

async function fetchAndStoreFile() {
  const response = await fetch(FILE_URL);
  const bytes = new Uint8Array(await response.arrayBuffer());
  const blob = new Blob([bytes]);
  await saveFileBlob(blob);
}

async function checkAndUpdateFile() {
  const blob = await getFileBlob(FILE_ID);
  if(!blob) {
    await fetchAndStoreFile();
  } else {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const record = await new Promise((resolve, reject) => {
      const req = store.get(FILE_ID);
      req.onsuccess = () => resolve(req.result);
      req.onerror = err => reject(err);
    });
    if(!record.lastUpdated || (Date.now() - record.lastUpdated) > ONE_DAY) {
      await fetchAndStoreFile();
    }
  }
}

/********************
 * SEARCH & PAGINATION
 ********************/
input.addEventListener('keydown', async e => {
  if(e.key !== 'Enter') return;
  const query = e.target.value.trim().toLowerCase();

  const series = await getSeriesData();
  if(!series) return;

  if(query === '') {
    // Jika input kosong, tampilkan semua
    currentResults = series;
  } else {
    // Filter berdasarkan keyword
    currentResults = series.filter(item => item.title && item.title.toLowerCase().includes(query));
  }

  currentPage = 1;
  totalPages = Math.ceil(currentResults.length / LIMIT);

  renderPage(currentPage);
  renderPagination();
});

// Fungsi load semua data awal
async function loadAllData() {
  const series = await getSeriesData();
  if(!series) return;

  currentResults = series;
  currentPage = 1;
  totalPages = Math.ceil(currentResults.length / LIMIT);

  renderPage(currentPage);
  renderPagination();
}

// Render page tertentu
function renderPage(page) {
  ul.innerHTML = '';
  if(currentResults.length === 0) {
    ul.innerHTML = '<li>No results found</li>';
    pageContainer.innerHTML = '';
    return;
  }

  const start = (page - 1) * LIMIT;
  const slice = currentResults.slice(start, start + LIMIT);

  slice.forEach((num, idx) => {
    const li = document.createElement('a');
    li.setAttribute('class', 'lzLinkCard');
    li.innerHTML = `
      <div class="lzCard lzCard9x16">
        <div class="lzCardThumbnail">
          <img data-lazy-src="${num.cover_image}" alt="${num.title}" class="lazyload">
        </div>
        <div class="lzCardBadgeStack lzCardBadgeStack-TopLeft" aria-hidden="true">
          <span class="lzBadgeRed svg" icon="eye-outline"></span>
        </div>
        <div class="lzCardBody">
          <div class="lzCardRankingMeta">
            <div class="lzCardRanking">${start + idx + 1}</div>
            <div class="lzCardBodyBadgeStack"><span class="lzBadgeEvent">NEW</span></div>
          </div>
          <p class="lzCardTitle">${num.title}</p>
          <p class="lzCardMeta">Author 2</p>
          <div class="lzCardFooter">
            <div class="lzCardMeta">Romance</div>
            <div class="lzCardMeta">2 Eps free</div>
          </div>
        </div>
      </div>
    `;
    ul.appendChild(li);
  });
}

// Modern pagination with ellipses
function renderPagination() {
  pageContainer.innerHTML = '';
  if(totalPages <= 1) return;

  const createButton = (text, page) => {
    const btn = document.createElement('button');
    btn.textContent = text;
    if(page === currentPage) btn.disabled = true;
    btn.addEventListener('click', () => {
      currentPage = page;
      renderPage(currentPage);
      renderPagination();
    });
    return btn;
  };

  const prevBtn = createButton('Prev', currentPage - 1);
  prevBtn.disabled = currentPage === 1;
  pageContainer.appendChild(prevBtn);

  const delta = 2;
  const pages = [];
  for(let i = 1; i <= totalPages; i++) {
    if(i === 1 || i === totalPages || (i >= currentPage - delta && i <= currentPage + delta)) {
      pages.push(i);
    } else if(pages[pages.length-1] !== '...') {
      pages.push('...');
    }
  }

  pages.forEach(p => {
    if(p === '...') {
      const span = document.createElement('span');
      span.textContent = '…';
      span.classList.add('ellipsis');
      pageContainer.appendChild(span);
    } else {
      pageContainer.appendChild(createButton(p, p));
    }
  });

  const nextBtn = createButton('Next', currentPage + 1);
  nextBtn.disabled = currentPage === totalPages;
  pageContainer.appendChild(nextBtn);

  // Jump to page
  const jumpInput = document.createElement('input');
  jumpInput.type = 'number';
  jumpInput.min = 1;
  jumpInput.max = totalPages;
  jumpInput.placeholder = 'Page';
  jumpInput.style.width = '60px';
  jumpInput.addEventListener('keydown', e => {
    if(e.key === 'Enter') {
      let page = parseInt(jumpInput.value);
      if(!isNaN(page)) {
        page = Math.max(1, Math.min(totalPages, page));
        currentPage = page;
        renderPage(currentPage);
        renderPagination();
      }
    }
  });
  pageContainer.appendChild(jumpInput);
}

// Load semua data saat awal load
document.addEventListener('DOMContentLoaded', loadAllData);
</script>
